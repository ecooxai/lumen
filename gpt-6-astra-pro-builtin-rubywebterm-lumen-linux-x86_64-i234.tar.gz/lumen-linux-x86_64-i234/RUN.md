# Tested Linux development executable

This is the exact x86_64 Lumen234 executable that passed the recorded gates. It has not been stripped, relinked or patched. External runtime libraries and ICU data are required; this package is not a standalone portable application.

Read BUILD-RUN.md and RUNTIME.json first. The recorded host-specific dependency prefix is displayed as PROJECT in the document; the actual executable's ELF/RUNPATH bytes are unchanged. Use a compatible source/dependency checkout and explicitly configure its runtime paths. The source package and recoverable reviewed public Git bundle are available at https://ecooxai.github.io/lumen/.

For example, from this extracted package, after supplying a compatible dependency checkout:

    LUMEN_SOURCE=/absolute/path/to/compatible/lumen-source
    lumen_v8_prefix="$LUMEN_SOURCE/build/codex-deps/v8/bottle/v8/15.6.75.8"
    lumen_wgpu_prefix="$LUMEN_SOURCE/build/codex-deps/wgpu"
    export LUMEN_ICU_DATA="$lumen_v8_prefix/libexec/icudtl.dat"
    export LD_LIBRARY_PATH="$lumen_v8_prefix/libexec:$lumen_v8_prefix/lib:$lumen_wgpu_prefix/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    sha256sum -c SHA256SUMS
    ./lumen "$PWD/demo.html"

The demo runs in the browser opening it. Opening this file in Lumen exercises Lumen; another browser shows that browser's live API values. The authored demo is outside WPT scoring. Full WPT and Chromium parity are not claimed.
