export const brokenC = ;
