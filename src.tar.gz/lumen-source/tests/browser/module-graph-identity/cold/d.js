export const brokenD = ;
