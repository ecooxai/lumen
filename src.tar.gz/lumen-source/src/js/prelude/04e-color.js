/*@shared color.js*/
