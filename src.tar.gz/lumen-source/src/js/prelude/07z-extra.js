
// ---- extra interfaces: rarer node/event types, media helpers ----
/* A processing instruction's attributes (declarative partial updates) live in its data as name="value" pairs
   separated by whitespace; data that is not entirely such pairs has none. Names are case-sensitive; values are
   escaped as an element's attribute values serialize. Changing one rewrites the data. */
const piRefs = { amp: '&', quot: '"', apos: "'", lt: '<', gt: '>', nbsp: ' ' };
const piParse = d => {
    const out = [], re = /[\t\n\f\r ]*([^\t\n\f\r \/=>"']+)=(?:"([^"]*)"|'([^']*)')(?=[\t\n\f\r ]|$)/y;
    let i = 0;
    while (i < d.length) {
        if (/^[\t\n\f\r ]*$/.test(d.slice(i))) break;
        re.lastIndex = i;
        const m = re.exec(d);
        if (!m) return [];
        const v = (m[2] ?? m[3]).replace(/&(?:#[xX]([0-9a-fA-F]+)|#([0-9]+)|([a-zA-Z]+));/g, (x, h, dec, nm) =>
            h ? String.fromCodePoint(Math.min(parseInt(h, 16), 0x10ffff)) : dec ? String.fromCodePoint(Math.min(+dec, 0x10ffff)) : piRefs[nm] ?? x);
        if (!out.some(a => a[0] === m[1])) out.push([m[1], v]);
        i = re.lastIndex;
    }
    return out;
};
const piSet = (pi, list) => { pi.data = list.map(([k, v]) => `${k}="${v.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/ /g, '&nbsp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')}"`).join(' '); };
const piName = (op, n) => {
    n = String(n);
    if (!validAttrName(n)) throw new DOMException(`Failed to execute '${op}' on 'ProcessingInstruction': '${n}' is not a valid attribute name.`, 'InvalidCharacterError');
    return n;
};
class ProcessingInstruction extends CharacterData {
    get target() { return N.name(this); }
    hasAttributes() { return piParse(this.data).length > 0; }
    getAttributeNames() { return piParse(this.data).map(a => a[0]); }
    getAttribute(n) { n = String(n); const a = piParse(this.data).find(a => a[0] === n); return a ? a[1] : null; }
    hasAttribute(n) { n = String(n); return piParse(this.data).some(a => a[0] === n); }
    setAttribute(n, v) {
        n = piName('setAttribute', n); v = String(v);
        const list = piParse(this.data), a = list.find(a => a[0] === n);
        if (a) a[1] = v; else list.push([n, v]);
        piSet(this, list);
    }
    removeAttribute(n) {
        n = String(n);
        const list = piParse(this.data), i = list.findIndex(a => a[0] === n);
        if (i >= 0) { list.splice(i, 1); piSet(this, list); }
    }
    toggleAttribute(n, force = undefined) {
        n = piName('toggleAttribute', n);
        const has = this.hasAttribute(n);
        if (has && force !== true) { this.removeAttribute(n); return false; }
        if (!has && force !== false) { this.setAttribute(n, ''); return true; }
        return has;
    }
}
const copyInit = (ev, init, keys) => { if (init) for (const k of keys) if (k in init) ev[k] = init[k]; };
class TouchEvent extends UIEvent {
    constructor(t, i = {}) {
        super(t, i);
        this.touches = i.touches || []; this.targetTouches = i.targetTouches || []; this.changedTouches = i.changedTouches || [];
        this.altKey = this.ctrlKey = this.metaKey = this.shiftKey = false;
        copyInit(this, i, ['altKey', 'ctrlKey', 'metaKey', 'shiftKey']);
    }
}
class CompositionEvent extends UIEvent { constructor(t, i = {}) { super(t, i); this.data = i.data || ''; } }
class ClipboardItem {
    constructor(items, o = {}) { this._i = items || {}; this.presentationStyle = o.presentationStyle || 'unspecified'; }
    get types() { return Object.keys(this._i); }
    async getType(t) { if (!(t in this._i)) throw new DOMException('type not found', 'NotFoundError'); const v = await this._i[t]; return v instanceof Blob ? v : new Blob([String(v)], { type: t }); }
    static supports(t) { return /^(text\/plain|text\/html|image\/png)$/.test(t); }
}
class BeforeUnloadEvent extends Event { constructor() { illegal(); } get returnValue() { return this.__rv ?? ''; } set returnValue(v) { def(this, '__rv', String(v)); } }
class TextEvent extends UIEvent {
    constructor() { illegal(); }
    get data() { return this.__data ?? ''; }
    initTextEvent(type, bubbles = false, cancelable = false, view = null, data = 'undefined') { this.initEvent(type, bubbles, cancelable); def(this, '__view', view); def(this, '__data', String(data)); }
}
class DeviceOrientationEvent extends Event {
    constructor(t, i = {}) { super(t, i); this.alpha = i.alpha ?? null; this.beta = i.beta ?? null; this.gamma = i.gamma ?? null; this.absolute = !!i.absolute; }
    static requestPermission() { return Promise.resolve('granted'); }
}
class DeviceMotionEvent extends Event {
    constructor(t, i = {}) { super(t, i); this.acceleration = i.acceleration ?? null; this.accelerationIncludingGravity = i.accelerationIncludingGravity ?? null; this.rotationRate = i.rotationRate ?? null; this.interval = i.interval ?? 0; }
    static requestPermission() { return Promise.resolve('granted'); }
}
class ClipboardEvent extends Event { constructor(t, i = {}) { super(t, i); this.clipboardData = i.clipboardData || null; } }
class DragEvent extends MouseEvent { constructor(t, i = {}) { super(t, i); this.dataTransfer = i.dataTransfer || null; } }
class StorageEvent extends Event {
    constructor(t, i = {}) {
        super(t, i);
        this.key = i.key ?? null; this.oldValue = i.oldValue ?? null; this.newValue = i.newValue ?? null;
        this.url = i.url || ''; this.storageArea = i.storageArea || null;
    }
}
class PromiseRejectionEvent extends Event { constructor(t, i = {}) { super(t, i); this.promise = i.promise; this.reason = i.reason; } }
class SubmitEvent extends Event { constructor(t, i = {}) { super(t, i); this.submitter = i.submitter || null; } }

class IdleDeadline {}
class TimeRanges {
    constructor(r = []) { this._r = r; }
    get length() { return this._r.length; }
    start(i) { if (!(i < this._r.length)) throw new DOMException('Index out of range', 'IndexSizeError'); return this._r[i][0]; }
    end(i) { if (!(i < this._r.length)) throw new DOMException('Index out of range', 'IndexSizeError'); return this._r[i][1]; }
}
class MediaError { constructor(code, message = '') { this.code = code; this.message = message; } }
Object.assign(MediaError, { MEDIA_ERR_ABORTED: 1, MEDIA_ERR_NETWORK: 2, MEDIA_ERR_DECODE: 3, MEDIA_ERR_SRC_NOT_SUPPORTED: 4 });

// ---- Media Source Extensions (fragmented MP4) ----
class SourceBufferList extends EventTarget {
    constructor() { super(); this._l = []; }
    get length() { return this._l.length; }
    item(i) { return this._l[i] ?? null; }
    [Symbol.iterator]() { return this._l[Symbol.iterator](); }
    _sync() { for (let i = 0; i < 32; i++) delete this[i]; this._l.forEach((b, i) => Object.defineProperty(this, i, { value: b, configurable: true, enumerable: true })); }
}
class SourceBuffer extends EventTarget {
    constructor(ms, idx, mime) {
        super();
        Object.assign(this, { _ms: ms, _i: idx, _mime: mime, updating: false, mode: 'segments', timestampOffset: 0, appendWindowStart: 0, appendWindowEnd: Infinity });
    }
    get buffered() { return this._ms._id ? mediaRanges(N.mediaBuffered(this._ms._id, this._i)) : new TimeRanges([]); }
    _op(fn) {
        if (this._ms.readyState === 'closed') throw new DOMException('MediaSource is closed', 'InvalidStateError');
        if (this.updating) throw new DOMException('SourceBuffer is updating', 'InvalidStateError');
        if (this._ms.readyState === 'ended') { this._ms.readyState = 'open'; this._ms.dispatchEvent(new Event('sourceopen')); }
        this.updating = true; this.dispatchEvent(new Event('updatestart'));
        setTimeout(() => {
            if (!this.updating) return;
            const ok = fn();
            this.updating = false;
            if (ok === false) { this.dispatchEvent(new Event('error')); this._ms.endOfStream('decode'); }
            else this.dispatchEvent(new Event('update'));
            this.dispatchEvent(new Event('updateend'));
        }, 0);
    }
    appendBuffer(data) {
        const copy = data instanceof ArrayBuffer ? data.slice(0) : new Uint8Array(data.buffer, data.byteOffset, data.byteLength).slice();
        this._op(() => N.mediaAppend(this._ms._id, this._i, copy));
    }
    remove(s, e) { this._op(() => { N.mediaRemove(this._ms._id, this._i, +s, +e); }); }
    abort() { if (this.updating) { this.updating = false; this.dispatchEvent(new Event('abort')); this.dispatchEvent(new Event('updateend')); } }
    changeType(t) { this._mime = String(t); }
}
class MediaSource extends EventTarget {
    constructor() { super(); this.readyState = 'closed'; this._dur = NaN; this._id = 0; this.sourceBuffers = new SourceBufferList(); this.activeSourceBuffers = this.sourceBuffers; }
    static isTypeSupported(t) { return N.mediaCanPlay(String(t), true) > 0; }
    static get canConstructInDedicatedWorker() { return false; }
    get duration() { return this._dur; }
    set duration(v) { this._dur = +v; if (this._id) N.mediaSetDuration(this._id, this._dur); }
    addSourceBuffer(t) {
        if (this.readyState !== 'open') throw new DOMException('MediaSource is not open', 'InvalidStateError');
        if (!MediaSource.isTypeSupported(t)) throw new DOMException('Unsupported type: ' + t, 'NotSupportedError');
        const i = N.mediaAddBuffer(this._id, String(t));
        if (i < 0) throw new DOMException('Too many SourceBuffers', 'QuotaExceededError');
        const sb = new SourceBuffer(this, i, String(t));
        this.sourceBuffers._l.push(sb); this.sourceBuffers._sync();
        return sb;
    }
    removeSourceBuffer(sb) { const l = this.sourceBuffers._l, k = l.indexOf(sb); if (k >= 0) { l.splice(k, 1); this.sourceBuffers._sync(); } }
    endOfStream(err) {
        if (this.readyState !== 'open') return;
        this.readyState = 'ended';
        if (!err) {
            let end = 0;
            for (const sb of this.sourceBuffers._l) { const b = sb.buffered; if (b.length) end = Math.max(end, b.end(b.length - 1)); }
            if (end > 0 && !(end <= this._dur)) this.duration = end;
            N.mediaEos(this._id);
        }
        setTimeout(() => this.dispatchEvent(new Event('sourceended')), 0);
    }
    setLiveSeekableRange() {}
    clearLiveSeekableRange() {}
    _attach(el, id) {
        this._el = el; this._id = id;
        if (!Number.isNaN(this._dur)) N.mediaSetDuration(id, this._dur);
        setTimeout(() => { this.readyState = 'open'; this.dispatchEvent(new Event('sourceopen')); }, 0);
    }
}
Promise.resolve().then(() => document.addEventListener('DOMContentLoaded', () => {
    for (const el of document.querySelectorAll('video, audio'))
        if (!el.__mp && (el.getAttribute('src') || el.querySelector('source[src]'))) { el.load(); if (el.autoplay) el.play(); }
}));
