/* CSS Typed OM style values (numeric math, keywords, unparsed values, transforms): page and workers. */
const TOM = Symbol('tom');
const tomIllegal = () => { throw new TypeError('Illegal constructor'); };
const tomData = v => { if (!v || !Object.prototype.hasOwnProperty.call(v, '_tom')) throw new TypeError('Illegal invocation'); return v._tom; };
const tomInit = (o, d) => Object.defineProperty(o, '_tom', { value: d, writable: true });
const TOM_UNITS = {
    number: ['', 1], percent: ['percent', 1],
    em: ['length'], rem: ['length'], ex: ['length'], rex: ['length'], ch: ['length'], rch: ['length'], ic: ['length'], ric: ['length'], cap: ['length'], rcap: ['length'], lh: ['length'], rlh: ['length'],
    vw: ['length'], vh: ['length'], vi: ['length'], vb: ['length'], vmin: ['length'], vmax: ['length'],
    svw: ['length'], svh: ['length'], svi: ['length'], svb: ['length'], svmin: ['length'], svmax: ['length'],
    lvw: ['length'], lvh: ['length'], lvi: ['length'], lvb: ['length'], lvmin: ['length'], lvmax: ['length'],
    dvw: ['length'], dvh: ['length'], dvi: ['length'], dvb: ['length'], dvmin: ['length'], dvmax: ['length'],
    cqw: ['length'], cqh: ['length'], cqi: ['length'], cqb: ['length'], cqmin: ['length'], cqmax: ['length'],
    px: ['length', 1], cm: ['length', 96 / 2.54], mm: ['length', 96 / 25.4], q: ['length', 96 / 101.6], in: ['length', 96], pt: ['length', 4 / 3], pc: ['length', 16],
    deg: ['angle', 1], grad: ['angle', 0.9], rad: ['angle', 180 / Math.PI], turn: ['angle', 360],
    s: ['time', 1], ms: ['time', 0.001], hz: ['frequency', 1], khz: ['frequency', 1000],
    dpi: ['resolution', 1 / 96], dpcm: ['resolution', 2.54 / 96], dppx: ['resolution', 1], x: ['resolution', 1], fr: ['flex', 1],
};
const TOM_BASE = ['length', 'angle', 'time', 'frequency', 'resolution', 'flex', 'percent'];
const tomUnit = u => { u = String(u).toLowerCase(); if (u === '%') u = 'percent'; if (!Object.prototype.hasOwnProperty.call(TOM_UNITS, u)) throw new TypeError(`Invalid unit: ${u}`); return u; };
const tomCat = u => TOM_UNITS[u.toLowerCase()][0];
const tomNum = (v, what = 'value') => { v = Number(v); if (!Number.isFinite(v) && !Number.isNaN(v) && Math.abs(v) !== Infinity) throw new TypeError(`Invalid ${what}`); return v; };
/* a numeric type: { length: 1, ... , percentHint } */
const tomTypeOf = v => {
    const d = tomData(v);
    if (d.k === 'unit') { const c = tomCat(d.unit); return c ? { [c]: 1 } : {}; }
    if (d.k === 'negate') return tomTypeOf(d.v);
    if (d.k === 'invert') { const t = tomTypeOf(d.v), r = {}; for (const k in t) r[k] = k === 'percentHint' ? t[k] : -t[k]; return r; }
    let t = null;
    for (const x of d.vals) { const u = tomTypeOf(x); t = t === null ? u : d.k === 'product' ? tomMulType(t, u) : tomAddType(t, u); if (!t) throw new TypeError('Incompatible types'); }
    return t;
};
const tomKeys = t => Object.keys(t).filter(k => k !== 'percentHint' && t[k]);
const tomAddType = (a, b) => {
    const ka = tomKeys(a), kb = tomKeys(b), same = ka.length === kb.length && ka.every(k => a[k] === b[k]);
    if (a.percentHint && b.percentHint && a.percentHint !== b.percentHint) return null;
    if (same) return Object.assign({}, a, a.percentHint || b.percentHint ? { percentHint: a.percentHint || b.percentHint } : {});
    const pa = ka.length === 1 && ka[0] === 'percent' && a.percent === 1, pb = kb.length === 1 && kb[0] === 'percent' && b.percent === 1;
    if (pa && kb.length === 1 && b[kb[0]] === 1 && kb[0] !== 'percent') return Object.assign({}, b, { percentHint: kb[0] });
    if (pb && ka.length === 1 && a[ka[0]] === 1 && ka[0] !== 'percent') return Object.assign({}, a, { percentHint: ka[0] });
    return null;
};
const tomMulType = (a, b) => { if (a.percentHint && b.percentHint && a.percentHint !== b.percentHint) return null; const r = {}; for (const k of new SSet([...tomKeys(a), ...tomKeys(b)])) { const e = (a[k] || 0) + (b[k] || 0); if (e) r[k] = e; } if (a.percentHint || b.percentHint) r.percentHint = a.percentHint || b.percentHint; return r; };
const tomRect = v => { if (v instanceof CSSNumericValue) return v; if (typeof v === 'number') return new CSSUnitValue(v, 'number'); if (typeof v === 'string' || typeof v === 'boolean') { const n = Number(v); if (Number.isFinite(n)) return new CSSUnitValue(n, 'number'); } throw new TypeError('Not a numeric value'); };   /* WebIDL (double or CSSNumericValue) */
const tomMath = (k, vals) => { const o = Object.create(({ sum: CSSMathSum, product: CSSMathProduct, min: CSSMathMin, max: CSSMathMax })[k].prototype); tomInit(o, { k, vals }); tomTypeOf(o); return o; };
const tomConv = (v, unit) => {   /* value of unit value v in unit, or null */
    const d = tomData(v); if (d.k !== 'unit') return null;
    if (d.unit === unit) return d.value;
    const a = TOM_UNITS[d.unit.toLowerCase()], b = TOM_UNITS[unit.toLowerCase()];
    return a[0] && a[0] === b[0] && a[1] && b[1] ? d.value * a[1] / b[1] : null;
};
const tomSer = (v, nested) => {
    const d = tomData(v);
    if (d.k === 'unit') return d.unit === 'number' ? tomNumStr(d.value) : tomNumStr(d.value) + (d.unit === 'percent' ? '%' : d.unit);
    const o = nested ? '(' : 'calc(';
    if (d.k === 'min' || d.k === 'max') return d.k + '(' + d.vals.map(x => tomSer(x, true).replace(/^\((.*)\)$/s, (m, i) => tomData(x).k === 'sum' || tomData(x).k === 'product' ? 'calc(' + i + ')' : m)).join(', ') + ')';
    if (d.k === 'clamp') return 'clamp(' + [d.lo, d.v, d.hi].map(x => tomSer(x, false)).join(', ') + ')';
    if (d.k === 'negate') return o + '-' + tomSer(d.v, true) + ')';
    if (d.k === 'invert') return o + '1 / ' + tomSer(d.v, true) + ')';
    let s = o + tomSer(d.vals[0], true);
    for (const x of d.vals.slice(1)) {
        const xd = tomData(x);
        if (d.k === 'sum') s += xd.k === 'negate' ? ' - ' + tomSer(xd.v, true) : ' + ' + tomSer(x, true);
        else s += xd.k === 'invert' ? ' / ' + tomSer(xd.v, true) : ' * ' + tomSer(x, true);
    }
    return s + ')';
};
const tomNumStr = n => { if (Number.isInteger(n)) return String(n); const r = +n.toPrecision(6); return String(r); };
const tomEq = (a, b) => {
    const x = tomData(a), y = tomData(b);
    if (x.k !== y.k) return false;
    if (x.k === 'unit') return x.unit === y.unit && x.value === y.value;
    if (x.k === 'negate' || x.k === 'invert') return tomEq(x.v, y.v);
    if (x.k === 'clamp') return tomEq(x.lo, y.lo) && tomEq(x.v, y.v) && tomEq(x.hi, y.hi);
    return x.vals.length === y.vals.length && x.vals.every((v, i) => tomEq(v, y.vals[i]));
};
/* sum of unit values grouped by unit, or null when v holds something else */
const tomSumMap = v => {
    const d = tomData(v);
    if (d.k === 'unit') return new SMap([[d.unit, d.value]]);
    if (d.k === 'negate') { const m = tomSumMap(d.v); if (m) for (const [k, x] of m) m.set(k, -x); return m; }
    if (d.k === 'sum') { const r = new SMap(); for (const x of d.vals) { const m = tomSumMap(x); if (!m) return null; for (const [k, y] of m) r.set(k, (r.get(k) || 0) + y); } return r; }
    if (d.k === 'product') {
        let r = new SMap([['number', 1]]);
        for (const x of d.vals) {
            const xd = tomData(x); let m;
            if (xd.k === 'invert') { m = tomSumMap(xd.v); if (!m || m.size !== 1) return null; const [[k, y]] = m; if (k !== 'number') return null; m = new SMap([['number', 1 / y]]); }
            else m = tomSumMap(x);
            if (!m) return null;
            const n = new SMap();
            for (const [k1, a] of r) for (const [k2, b] of m) { if (k1 !== 'number' && k2 !== 'number') return null; const k = k1 === 'number' ? k2 : k1; n.set(k, (n.get(k) || 0) + a * b); }
            r = n;
        }
        return r;
    }
    return null;
};

class CSSStyleValue {
    constructor(k) { if (k !== TOM) tomIllegal(); }
    toString() { const d = tomData(this); return d.k ? tomSer(this, false) : d.text; }
    static parse(prop, text) { return tomParseProp(prop, text, false)[0]; }
    static parseAll(prop, text) { return tomParseProp(prop, text, true); }
}
class CSSNumericValue extends CSSStyleValue {
    constructor(k) { if (k !== TOM) tomIllegal(); super(TOM); }
    add(...vs) { return tomCombine('sum', [this, ...vs.map(tomRect)]); }
    sub(...vs) { return tomCombine('sum', [this, ...vs.map(v => tomRect(v).negate())]); }
    mul(...vs) { return tomCombine('product', [this, ...vs.map(tomRect)]); }
    div(...vs) { return tomCombine('product', [this, ...vs.map(v => { v = tomRect(v); const d = tomData(v); if (d.k === 'unit' && d.unit === 'number' && d.value === 0) throw new RangeError('Division by zero'); return d.k === 'unit' && d.unit === 'number' ? new CSSUnitValue(1 / d.value, 'number') : v.invert(); })]); }
    min(...vs) { return tomCombine('min', [this, ...vs.map(tomRect)]); }
    max(...vs) { return tomCombine('max', [this, ...vs.map(tomRect)]); }
    negate() { const d = tomData(this); if (d.k === 'unit') return new CSSUnitValue(-d.value, d.unit); if (d.k === 'negate') return d.v; return new CSSMathNegate(this); }
    invert() { const d = tomData(this); if (d.k === 'unit' && d.unit === 'number') { if (d.value === 0) throw new RangeError('Division by zero'); return new CSSUnitValue(1 / d.value, 'number'); } if (d.k === 'invert') return d.v; return new CSSMathInvert(this); }
    equals(...vs) { return vs.every(v => v instanceof CSSNumericValue && tomEq(this, v)); }
    to(unit) {
        unit = tomUnit(unit);
        const m = tomSumMap(this); if (!m) throw new TypeError('Cannot convert value');
        let total = 0;
        for (const [k, x] of m) { const c = tomConv(new CSSUnitValue(x, k), unit); if (c === null) throw new TypeError(`Cannot convert to ${unit}`); total += c; }
        return new CSSUnitValue(total, unit);
    }
    toSum(...units) {
        units = units.map(tomUnit);
        const m = tomSumMap(this); if (!m) throw new TypeError('Cannot convert value to a sum');
        if (!units.length) {
            const out = new SMap();
            for (const [k, x] of m) { const c = TOM_UNITS[k.toLowerCase()]; const canon = c[0] === 'length' && c[1] ? 'px' : c[0] === 'angle' ? 'deg' : c[0] === 'time' ? 's' : c[0] === 'frequency' ? 'Hz' : c[0] === 'resolution' && c[1] ? 'dppx' : k; const y = tomConv(new CSSUnitValue(x, k), canon); out.set(canon, (out.get(canon) || 0) + (y ?? x)); }
            const vals = [...out].sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0).map(([k, x]) => new CSSUnitValue(x, k));
            return tomMath('sum', vals);
        }
        const acc = units.map(() => 0);
        for (const [k, x] of m) { let ok = false; for (let i = 0; i < units.length && !ok; i++) { const c = tomConv(new CSSUnitValue(x, k), units[i]); if (c !== null) { acc[i] += c; ok = true; } } if (!ok) throw new TypeError('Cannot convert to the given units'); }
        return tomMath('sum', units.map((u, i) => new CSSUnitValue(acc[i], u)));
    }
    type() { const t = tomTypeOf(this), r = {}; for (const k of TOM_BASE) if (t[k]) r[k] = t[k]; if (t.percentHint) r.percentHint = t.percentHint; return r; }
    static parse(text) {
        const toks = tomTokens(String(text)); let i = 0;
        const skip = () => { while (toks[i] && toks[i].t === 'ws') i++; };
        skip();
        const v = tomExprAtom(toks, () => i, n => { i = n; }, true);
        skip();
        if (!v || i < toks.length) throw new DOMException(`Failed to parse '${text}' as a numeric value`, 'SyntaxError');
        return v;
    }
}
const tomCombine = (k, vals) => {
    const ds = vals.map(tomData);
    if (ds.every(d => d.k === 'unit')) {
        if (k === 'sum' && ds.every(d => d.unit === ds[0].unit)) return new CSSUnitValue(ds.reduce((s, d) => s + d.value, 0), ds[0].unit);
        if ((k === 'min' || k === 'max') && ds.every(d => d.unit === ds[0].unit)) return new CSSUnitValue(Math[k](...ds.map(d => d.value)), ds[0].unit);
        if (k === 'product' && ds.filter(d => d.unit !== 'number').length <= 1) return new CSSUnitValue(ds.reduce((s, d) => s * d.value, 1), (ds.find(d => d.unit !== 'number') || ds[0]).unit);
    }
    return tomMath(k, vals);
};
class CSSUnitValue extends CSSNumericValue {
    constructor(value, unit) { super(TOM); if (arguments.length < 2) throw new TypeError('2 arguments required'); tomInit(this, { k: 'unit', value: tomNum(value), unit: tomUnit(unit) }); }
    get value() { return tomData(this).value; } set value(v) { tomData(this).value = tomNum(v); }
    get unit() { return tomData(this).unit; }
}
class CSSMathValue extends CSSNumericValue {
    constructor(k) { if (k !== TOM) tomIllegal(); super(TOM); }
    get operator() { return tomData(this).k; }
}
class CSSNumericArray {
    constructor(k) { if (k !== TOM) tomIllegal(); }
    get length() { return tomData(this).length; }
    [Symbol.iterator]() { return tomData(this)[Symbol.iterator](); }
    forEach(f, t) { tomData(this).forEach((v, i) => f.call(t, v, i, this)); }
}
const tomArray = vals => new Proxy(tomInit(new CSSNumericArray(TOM), vals), {
    get(t, p, r) { if (typeof p === 'string' && /^\d+$/.test(p)) return vals[+p]; return Reflect.get(t, p, r); },
    has(t, p) { return (typeof p === 'string' && /^\d+$/.test(p) && +p < vals.length) || p in t; },
    set(t, p, v) { if (typeof p === 'string' && /^\d+$/.test(p)) return false; return Reflect.set(t, p, v); },
    ownKeys(t) { return [...vals.keys()].map(String).concat(Reflect.ownKeys(t)); },
    getOwnPropertyDescriptor(t, p) { if (typeof p === 'string' && /^\d+$/.test(p) && +p < vals.length) return { value: vals[+p], enumerable: true, configurable: true, writable: false }; return Reflect.getOwnPropertyDescriptor(t, p); },
});
const tomVariadic = (name, k) => class extends CSSMathValue {
    constructor(...vals) { super(TOM); if (!vals.length) throw new SyntaxError(`${name} requires at least one argument`); tomInit(this, { k, vals: vals.map(tomRect) }); tomTypeOf(this); }
    get values() { return tomArray(tomData(this).vals); }
};
const CSSMathSum = tomVariadic('CSSMathSum', 'sum'), CSSMathProduct = tomVariadic('CSSMathProduct', 'product'), CSSMathMin = tomVariadic('CSSMathMin', 'min'), CSSMathMax = tomVariadic('CSSMathMax', 'max');
for (const [C, n] of [[CSSMathSum, 'CSSMathSum'], [CSSMathProduct, 'CSSMathProduct'], [CSSMathMin, 'CSSMathMin'], [CSSMathMax, 'CSSMathMax']]) Object.defineProperty(C, 'name', { value: n });
class CSSMathNegate extends CSSMathValue {
    constructor(v) { super(TOM); tomInit(this, { k: 'negate', v: tomRect(v) }); }
    get value() { return tomData(this).v; }
}
class CSSMathInvert extends CSSMathValue {
    constructor(v) { super(TOM); tomInit(this, { k: 'invert', v: tomRect(v) }); }
    get value() { return tomData(this).v; }
}
class CSSMathClamp extends CSSMathValue {
    constructor(lo, v, hi) {
        super(TOM); if (arguments.length < 3) throw new TypeError('3 arguments required');
        const d = { k: 'clamp', lo: tomRect(lo), v: tomRect(v), hi: tomRect(hi) };
        if (!tomAddType(tomAddType(tomTypeOf(d.lo), tomTypeOf(d.v)) || {}, tomTypeOf(d.hi))) throw new TypeError('Incompatible types');
        tomInit(this, d);
    }
    get lower() { return tomData(this).lo; } get value() { return tomData(this).v; } get upper() { return tomData(this).hi; }
}
Object.defineProperty(CSSMathValue.prototype, 'operator', Object.getOwnPropertyDescriptor(CSSMathValue.prototype, 'operator'));
for (const [C, op] of [[CSSMathNegate, 'negate'], [CSSMathInvert, 'invert'], [CSSMathClamp, 'clamp']]) void op;

/* tokens of a numeric expression: num (value, unit), op, open (fn), close, comma, ws */
function tomTokens(s) {
    const out = []; let i = 0;
    while (i < s.length) {
        const c = s[i];
        if (/\s/.test(c)) { while (i < s.length && /\s/.test(s[i])) i++; out.push({ t: 'ws' }); continue; }
        const m = /^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/i.exec(s.slice(i));
        if (m && !(c === '+' || c === '-') || (m && (c === '+' || c === '-') && (!out.length || out[out.length - 1].t !== 'num' && out[out.length - 1].t !== 'close'))) {
            i += m[0].length; let u = '';
            if (s[i] === '%') { u = 'percent'; i++; } else { const um = /^[a-z]+/i.exec(s.slice(i)); if (um) { u = um[0]; i += u.length; } }
            out.push({ t: 'num', v: +m[0], u: u || 'number' }); continue;
        }
        const f = /^(calc|min|max|clamp)\(/i.exec(s.slice(i));
        if (f) { out.push({ t: 'open', fn: f[1].toLowerCase() }); i += f[0].length; continue; }
        if (c === '(') { out.push({ t: 'open', fn: '' }); i++; continue; }
        if (c === ')') { out.push({ t: 'close' }); i++; continue; }
        if (c === ',') { out.push({ t: 'comma' }); i++; continue; }
        if ('+-*/'.includes(c)) { out.push({ t: 'op', v: c }); i++; continue; }
        out.push({ t: 'bad' }); i++;
    }
    return out;
}
/* parses one atom (number or function) at the token cursor; top: the whole value must be a single atom */
function tomExprAtom(toks, get, set) {
    let i = get();
    const tk = toks[i];
    if (!tk) return null;
    if (tk.t === 'num') {
        let u; try { u = tomUnit(tk.u); } catch (e) { return null; }
        set(i + 1); return new CSSUnitValue(tk.v, u);
    }
    if (tk.t !== 'open') return null;
    i++;
    const ws = () => { while (toks[i] && toks[i].t === 'ws') i++; };
    const sum = () => {
        let terms = [prod()]; if (!terms[0]) return null;
        for (;;) {
            const save = i; ws(); const t = toks[i];
            if (t && t.t === 'op' && (t.v === '+' || t.v === '-') && toks[i - 1] && toks[i - 1].t === 'ws' && toks[i + 1] && toks[i + 1].t === 'ws') { i++; ws(); const p = prod(); if (!p) return null; terms.push(t.v === '-' ? p.negate() : p); }
            else { i = save; break; }
        }
        return terms.length === 1 ? terms[0] : tomCombine('sum', terms);
    };
    const prod = () => {
        ws(); let f = [unary()]; if (!f[0]) return null;
        for (;;) {
            const save = i; ws(); const t = toks[i];
            if (t && t.t === 'op' && (t.v === '*' || t.v === '/')) { i++; ws(); const u = unary(); if (!u) return null; f.push(t.v === '/' ? u.invert() : u); }
            else { i = save; break; }
        }
        return f.length === 1 ? f[0] : tomCombine('product', f);
    };
    const unary = () => { const r = tomExprAtom(toks, () => i, n => { i = n; }); return r; };
    const fn = tk.fn;
    const args = [];
    for (;;) { ws(); const a = sum(); if (!a) return null; args.push(a); ws(); if (toks[i] && toks[i].t === 'comma') { i++; continue; } break; }
    ws(); if (!toks[i] || toks[i].t !== 'close') return null;
    set(i + 1);
    if (fn === 'min' || fn === 'max') return args.length === 1 ? tomMath(fn, args) : tomMath(fn, args);
    if (fn === 'clamp') return args.length === 3 ? new CSSMathClamp(...args) : null;
    if (args.length !== 1) return null;
    const a = args[0];
    return fn === 'calc' && tomData(a).k === 'unit' ? tomMath('sum', [a]) : a;
}

class CSSKeywordValue extends CSSStyleValue {
    constructor(v) { super(TOM); v = String(v); if (!v) throw new TypeError('CSSKeywordValue does not support empty strings'); tomInit(this, { text: v }); }
    get value() { return tomData(this).text; } set value(v) { v = String(v); if (!v) throw new TypeError('CSSKeywordValue does not support empty strings'); tomData(this).text = v; }
}
class CSSVariableReferenceValue {
    constructor(variable, fallback = null) { variable = String(variable); if (!variable.startsWith('--')) throw new TypeError(`Invalid custom property name: ${variable}`); if (fallback !== null && !(fallback instanceof CSSUnparsedValue)) throw new TypeError('Fallback must be a CSSUnparsedValue'); tomInit(this, { variable, fallback }); }
    get variable() { return tomData(this).variable; } set variable(v) { v = String(v); if (!v.startsWith('--')) throw new TypeError(`Invalid custom property name: ${v}`); tomData(this).variable = v; }
    get fallback() { return tomData(this).fallback; }
}
class CSSUnparsedValue extends CSSStyleValue {
    constructor(members) {
        super(TOM);
        if (members == null || typeof members[Symbol.iterator] !== 'function') throw new TypeError('CSSUnparsedValue requires a sequence');
        const m = [...members].map(x => x instanceof CSSVariableReferenceValue ? x : String(x));
        tomInit(this, { text: null, m });
        return new Proxy(this, {
            get(t, p) { if (typeof p === 'string' && /^\d+$/.test(p)) return tomData(t).m[+p]; return Reflect.get(t, p, t); },
            set(t, p, v) {
                if (typeof p === 'string' && /^\d+$/.test(p)) { const a = tomData(t).m; if (+p > a.length) throw new RangeError('Index out of range'); a[+p] = v instanceof CSSVariableReferenceValue ? v : String(v); return true; }
                return Reflect.set(t, p, v, t);
            },
            has(t, p) { return (typeof p === 'string' && /^\d+$/.test(p) && +p < tomData(t).m.length) || p in t; },
        });
    }
    get length() { return tomData(this).m.length; }
    [Symbol.iterator]() { return tomData(this).m[Symbol.iterator](); }
    entries() { return tomData(this).m.entries(); } keys() { return tomData(this).m.keys(); } values() { return tomData(this).m.values(); }
    forEach(f, t) { tomData(this).m.forEach((v, i) => f.call(t, v, i, this)); }
    toString() { return tomData(this).m.map(x => x instanceof CSSVariableReferenceValue ? `var(${x.variable}${x.fallback ? ',' + x.fallback.toString() : ''})` : x).join(''); }
}
class CSSImageValue extends CSSStyleValue { constructor(k) { if (k !== TOM) tomIllegal(); super(TOM); } }

/* transforms */
class CSSTransformComponent {
    constructor(k) { if (k !== TOM) tomIllegal(); }
    get is2D() { return tomData(this).is2D; } set is2D(v) { tomData(this).is2D = !!v; }
    toMatrix() { return new DOMMatrix(tomTfStr(this, true)); }
    toString() { return tomTfStr(this, false); }
}
const tomLen = (v, what) => { v = tomRect(v); const t = tomTypeOf(v), k = tomKeys(t); if (!(k.length === 1 && (k[0] === 'length' || (what === 'lp' && k[0] === 'percent')) && t[k[0]] === 1) && !(what === 'lp' && t.percentHint === 'length')) throw new TypeError('Must be a length'); return v; };
const tomAng = v => { v = tomRect(v); const k = tomKeys(tomTypeOf(v)); if (!(k.length === 1 && k[0] === 'angle')) throw new TypeError('Must be an angle'); return v; };
const tomNumV = v => { v = tomRect(v); if (tomKeys(tomTypeOf(v)).length) throw new TypeError('Must be a number'); return v; };
const tomS = v => v.toString();
function tomTfStr(c, abs) {
    const d = tomData(c), s = abs ? (v => { try { return tomData(v).k === 'unit' ? tomS(v) : tomS(v); } catch (e) { return tomS(v); } }) : tomS;
    switch (d.t) {
        case 'translate': return d.is2D ? `translate(${s(d.x)}, ${s(d.y)})` : `translate3d(${s(d.x)}, ${s(d.y)}, ${s(d.z)})`;
        case 'rotate': return d.is2D ? `rotate(${s(d.a)})` : `rotate3d(${s(d.x)}, ${s(d.y)}, ${s(d.z)}, ${s(d.a)})`;
        case 'scale': return d.is2D ? `scale(${s(d.x)}, ${s(d.y)})` : `scale3d(${s(d.x)}, ${s(d.y)}, ${s(d.z)})`;
        case 'skew': return `skew(${s(d.ax)}, ${s(d.ay)})`;
        case 'skewX': return `skewX(${s(d.ax)})`;
        case 'skewY': return `skewY(${s(d.ay)})`;
        case 'perspective': return `perspective(${typeof d.l === 'string' ? d.l : s(d.l)})`;
        case 'matrix': return d.is2D ? (() => { const m = d.m; return `matrix(${[m.a, m.b, m.c, m.d, m.e, m.f].join(', ')})`; })() : `matrix3d(${['m11', 'm12', 'm13', 'm14', 'm21', 'm22', 'm23', 'm24', 'm31', 'm32', 'm33', 'm34', 'm41', 'm42', 'm43', 'm44'].map(k => d.m[k]).join(', ')})`;
    }
    return '';
}
const tomComp = (C, d) => { const o = Object.create(C.prototype); tomInit(o, d); return o; };
class CSSTranslate extends CSSTransformComponent {
    constructor(x, y, z) { super(TOM); if (arguments.length < 2) throw new TypeError('2 arguments required'); tomInit(this, { t: 'translate', x: tomLen(x, 'lp'), y: tomLen(y, 'lp'), z: z === undefined ? new CSSUnitValue(0, 'px') : tomLen(z), is2D: z === undefined }); }
    get x() { return tomData(this).x; } set x(v) { tomData(this).x = tomLen(v, 'lp'); }
    get y() { return tomData(this).y; } set y(v) { tomData(this).y = tomLen(v, 'lp'); }
    get z() { return tomData(this).z; } set z(v) { tomData(this).z = tomLen(v); }
}
class CSSRotate extends CSSTransformComponent {
    constructor(...a) {
        super(TOM);
        if (a.length === 1) tomInit(this, { t: 'rotate', x: new CSSUnitValue(0, 'number'), y: new CSSUnitValue(0, 'number'), z: new CSSUnitValue(1, 'number'), a: tomAng(a[0]), is2D: true });
        else if (a.length >= 4) tomInit(this, { t: 'rotate', x: tomNumV(a[0]), y: tomNumV(a[1]), z: tomNumV(a[2]), a: tomAng(a[3]), is2D: false });
        else throw new TypeError('Invalid arguments');
    }
    get x() { return tomData(this).x; } set x(v) { tomData(this).x = tomNumV(v); }
    get y() { return tomData(this).y; } set y(v) { tomData(this).y = tomNumV(v); }
    get z() { return tomData(this).z; } set z(v) { tomData(this).z = tomNumV(v); }
    get angle() { return tomData(this).a; } set angle(v) { tomData(this).a = tomAng(v); }
}
class CSSScale extends CSSTransformComponent {
    constructor(x, y, z) { super(TOM); if (arguments.length < 2) throw new TypeError('2 arguments required'); tomInit(this, { t: 'scale', x: tomNumV(x), y: tomNumV(y), z: z === undefined ? new CSSUnitValue(1, 'number') : tomNumV(z), is2D: z === undefined }); }
    get x() { return tomData(this).x; } set x(v) { tomData(this).x = tomNumV(v); }
    get y() { return tomData(this).y; } set y(v) { tomData(this).y = tomNumV(v); }
    get z() { return tomData(this).z; } set z(v) { tomData(this).z = tomNumV(v); }
}
class CSSSkew extends CSSTransformComponent {
    constructor(ax, ay) { super(TOM); if (arguments.length < 2) throw new TypeError('2 arguments required'); tomInit(this, { t: 'skew', ax: tomAng(ax), ay: tomAng(ay), is2D: true }); }
    get ax() { return tomData(this).ax; } set ax(v) { tomData(this).ax = tomAng(v); }
    get ay() { return tomData(this).ay; } set ay(v) { tomData(this).ay = tomAng(v); }
    get is2D() { return true; } set is2D(v) {}
}
class CSSSkewX extends CSSTransformComponent {
    constructor(ax) { super(TOM); if (!arguments.length) throw new TypeError('1 argument required'); tomInit(this, { t: 'skewX', ax: tomAng(ax), is2D: true }); }
    get ax() { return tomData(this).ax; } set ax(v) { tomData(this).ax = tomAng(v); }
    get is2D() { return true; } set is2D(v) {}
}
class CSSSkewY extends CSSTransformComponent {
    constructor(ay) { super(TOM); if (!arguments.length) throw new TypeError('1 argument required'); tomInit(this, { t: 'skewY', ay: tomAng(ay), is2D: true }); }
    get ay() { return tomData(this).ay; } set ay(v) { tomData(this).ay = tomAng(v); }
    get is2D() { return true; } set is2D(v) {}
}
class CSSPerspective extends CSSTransformComponent {
    constructor(l) { super(TOM); if (!arguments.length) throw new TypeError('1 argument required'); tomInit(this, { t: 'perspective', l: tomPersp(l), is2D: false }); }
    get length() { const l = tomData(this).l; return typeof l === 'string' ? new CSSKeywordValue(l) : l; } set length(v) { tomData(this).l = tomPersp(v); }
    get is2D() { return false; } set is2D(v) {}
}
const tomPersp = l => { if (l instanceof CSSKeywordValue) { if (l.value !== 'none') throw new TypeError('Invalid perspective'); return 'none'; } if (typeof l === 'string' && l === 'none') return 'none'; return tomLen(l); };
class CSSMatrixComponent extends CSSTransformComponent {
    constructor(m, opts) { super(TOM); if (!(m instanceof DOMMatrixReadOnly)) throw new TypeError('Must be a DOMMatrixReadOnly'); tomInit(this, { t: 'matrix', m: DOMMatrix.fromMatrix(m), is2D: opts && 'is2D' in opts ? !!opts.is2D : m.is2D }); }
    get matrix() { return tomData(this).m; } set matrix(v) { if (!(v instanceof DOMMatrixReadOnly)) throw new TypeError('Must be a DOMMatrixReadOnly'); tomData(this).m = DOMMatrix.fromMatrix(v); }
}
class CSSTransformValue extends CSSStyleValue {
    constructor(list) {
        super(TOM);
        if (list == null || typeof list[Symbol.iterator] !== 'function') throw new TypeError('CSSTransformValue requires a sequence');
        const l = [...list]; if (!l.length || l.some(c => !(c instanceof CSSTransformComponent))) throw new TypeError('Invalid transform components');
        tomInit(this, { tf: l });
        return new Proxy(this, {
            get(t, p) { if (typeof p === 'string' && /^\d+$/.test(p)) return tomData(t).tf[+p]; return Reflect.get(t, p, t); },
            set(t, p, v) { if (typeof p === 'string' && /^\d+$/.test(p)) { if (!(v instanceof CSSTransformComponent)) throw new TypeError('Invalid transform component'); const a = tomData(t).tf; if (+p > a.length) throw new RangeError('Index out of range'); a[+p] = v; return true; } return Reflect.set(t, p, v, t); },
            has(t, p) { return (typeof p === 'string' && /^\d+$/.test(p) && +p < tomData(t).tf.length) || p in t; },
        });
    }
    get length() { return tomData(this).tf.length; }
    get is2D() { return tomData(this).tf.every(c => c.is2D); }
    [Symbol.iterator]() { return tomData(this).tf[Symbol.iterator](); }
    entries() { return tomData(this).tf.entries(); } keys() { return tomData(this).tf.keys(); } values() { return tomData(this).tf.values(); }
    forEach(f, t) { tomData(this).tf.forEach((v, i) => f.call(t, v, i, this)); }
    toMatrix() { let m = new DOMMatrix(); for (const c of tomData(this).tf) m = m.multiply(c.toMatrix()); return m; }
    toString() { return tomData(this).tf.map(c => c.toString()).join(' '); }
}
function tomParseTransform(text) {
    const fns = [], re = /\s*([a-z0-9]+)\(([^()]*(?:\([^()]*\)[^()]*)*)\)\s*/giy; let m, end = 0;
    while ((m = re.exec(text))) { fns.push([m[1].toLowerCase(), m[2]]); end = re.lastIndex; }
    if (!fns.length || end !== text.length) return null;
    try {
        return new CSSTransformValue(fns.map(([f, a]) => {
            const args = a.split(',').map(s => s.trim()).filter(Boolean).map(s => (f === 'perspective' && s === 'none') ? 'none' : CSSNumericValue.parse(s));
            switch (f) {
                case 'translate': return new CSSTranslate(args[0], args[1] || new CSSUnitValue(0, 'px'));
                case 'translatex': return new CSSTranslate(args[0], new CSSUnitValue(0, 'px'));
                case 'translatey': return new CSSTranslate(new CSSUnitValue(0, 'px'), args[0]);
                case 'translatez': return new CSSTranslate(new CSSUnitValue(0, 'px'), new CSSUnitValue(0, 'px'), args[0]);
                case 'translate3d': return new CSSTranslate(...args);
                case 'rotate': case 'rotatez': return f === 'rotate' ? new CSSRotate(args[0]) : new CSSRotate(0, 0, 1, args[0]);
                case 'rotatex': return new CSSRotate(1, 0, 0, args[0]);
                case 'rotatey': return new CSSRotate(0, 1, 0, args[0]);
                case 'rotate3d': return new CSSRotate(...args);
                case 'scale': return new CSSScale(args[0], args[1] || args[0]);
                case 'scalex': return new CSSScale(args[0], 1);
                case 'scaley': return new CSSScale(1, args[0]);
                case 'scalez': return new CSSScale(1, 1, args[0]);
                case 'scale3d': return new CSSScale(...args);
                case 'skew': return new CSSSkew(args[0], args[1] || new CSSUnitValue(0, 'deg'));
                case 'skewx': return new CSSSkewX(args[0]);
                case 'skewy': return new CSSSkewY(args[0]);
                case 'perspective': return new CSSPerspective(args[0] === 'none' ? new CSSKeywordValue('none') : args[0]);
                case 'matrix': return new CSSMatrixComponent(new DOMMatrixReadOnly(args.map(x => x.value)));
                case 'matrix3d': return new CSSMatrixComponent(new DOMMatrixReadOnly(args.map(x => x.value)));
            }
            throw new TypeError('Unknown transform function');
        }));
    } catch (e) { return null; }
}

/* CSS colour values: channels are percents/numbers (hue: angles); a bare JS number means a fraction (hue: degrees) */
const tomColErr = () => new DOMException('Invalid color channel', 'SyntaxError');
function tomCh(v, kind) {
    if (kind === 'hwbhue' && !(v instanceof CSSNumericValue)) throw new TypeError("The provided value is not of type 'CSSNumericValue'.");
    if (kind === 'hwbhue') kind = 'hue';
    if (v === undefined) { if (kind === 'alpha') return new CSSUnitValue(100, 'percent'); throw tomColErr(); }
    if (typeof v === 'number') return kind === 'hue' ? new CSSUnitValue(v, 'deg') : new CSSUnitValue(v * 100, 'percent');
    if (!(v instanceof CSSNumericValue)) throw tomColErr();
    let k; try { k = tomKeys(tomTypeOf(v)); } catch (e) { throw tomColErr(); }
    const t = tomTypeOf(v);
    const ok = kind === 'hue' ? (k.length === 1 && k[0] === 'angle' && t.angle === 1) || (!k.length && v instanceof CSSUnitValue)
        : (k.length === 1 && k[0] === 'percent' && t.percent === 1) || (!k.length && kind !== 'alpha');
    if (!ok) throw tomColErr();
    return v;
}
class CSSColorValue extends CSSStyleValue {
    constructor(k) { super(TOM); if (k !== TOM) tomIllegal(); }
    static parse(text) {
        const s = String(text).trim(), low = s.toLowerCase(), m = /^(rgba?|hsla?|hwb)\(([\s\S]*)\)$/.exec(low);
        const num = a => a === 'none' ? new CSSKeywordValue('none') : a.u === '%' ? new CSSUnitValue(a.v, 'percent') : a.u === '' ? new CSSUnitValue(a.v, 'number') : new CSSUnitValue(a.v, a.u);
        if (m) {
            const a = colorArgs(m[2]); if (!a) throw tomColErr();
            const vals = a.filter(x => x !== ',' && x !== '/');
            if (vals.length < 3 || vals.length > 4) throw tomColErr();
            const alpha = vals[3] === undefined ? undefined : vals[3].u === '' ? new CSSUnitValue(vals[3].v * 100, 'percent') : num(vals[3]);
            if (m[1].startsWith('rgb')) return new CSSRGB(num(vals[0]), num(vals[1]), num(vals[2]), alpha);
            const h = vals[0].u === '' ? new CSSUnitValue(vals[0].v, 'deg') : num(vals[0]);
            const pc = x => x.u === '' ? new CSSUnitValue(x.v, 'percent') : num(x);
            return new (m[1] === 'hwb' ? CSSHWB : CSSHSL)(h, pc(vals[1]), pc(vals[2]), alpha);
        }
        const c = cssColor(s);
        if (!c || c.space !== 'srgb') throw tomColErr();
        return new CSSRGB(...c.c.map(x => new CSSUnitValue(Math.round(x * 255), 'number')), c.alpha === 1 ? undefined : new CSSUnitValue(c.alpha * 100, 'percent'));
    }
}
const tomColorClass = (name, fn, names) => {
    const kindOf = n => n === 'alpha' ? 'alpha' : n === 'h' ? (fn === 'hwb' ? 'hwbhue' : 'hue') : 'ch';
    const C = class extends CSSColorValue {
        constructor(...a) {
            super(TOM); if (a.length < 3) throw new TypeError(`3 arguments required`);
            const d = {}; names.forEach((n, i) => { d[n] = tomCh(a[i], kindOf(n)); }); tomInit(this, d);
        }
        toString() { const d = tomData(this), a = d.alpha; return `${fn}(${names.slice(0, 3).map(n => d[n].toString()).join(' ')}${a instanceof CSSUnitValue && a.unit === 'percent' && a.value === 100 ? '' : ' / ' + a}`.replace(/$/, ')'); }
    };
    Object.defineProperty(C, 'name', { value: name });
    for (const n of names) Object.defineProperty(C.prototype, n, { get() { return tomData(this)[n]; }, set(v) { tomData(this)[n] = tomCh(v, kindOf(n)); }, enumerable: true, configurable: true });
    return C;
};
const CSSRGB = tomColorClass('CSSRGB', 'rgb', ['r', 'g', 'b', 'alpha']), CSSHSL = tomColorClass('CSSHSL', 'hsl', ['h', 's', 'l', 'alpha']), CSSHWB = tomColorClass('CSSHWB', 'hwb', ['h', 'w', 'b', 'alpha']);
