# Restore candidate 226 source and Git history

Run this from the extracted archive directory. Git is the only required tool; the bundle contains its complete public ancestry and requires no network access.

```sh
git clone --branch gpt-6-astra-pro-builtin-rubywebterm-css-math-source226-20261030 PUBLIC-HISTORY.bundle lumen-source
git -C lumen-source rev-parse HEAD
git -C lumen-source rev-parse 'HEAD^{tree}'
```

Expected commit: `2287d7fc602954c85a51c36f45ab5faa2473decc`.

Expected tracked tree: `919defc65c7d85b993041ea2f1cfd560f0b8d35e`.

A fresh offline clone was checked against every tracked path, Git blob ID and executable mode before this archive was created. The three archive-only files PUBLIC-HISTORY.bundle, RESTORE-GIT.md and ARCHIVE-PROVENANCE.json are additive packaging metadata and are intentionally absent from that tracked tree. SOURCE-MANIFEST.json and EXPORT-QUALIFICATION.json map the reviewed exported source to the original working commit and state the validation limitations.
