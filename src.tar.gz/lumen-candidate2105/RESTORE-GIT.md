# Restore candidate 2105 source and Git history

Run this from the extracted archive directory. Git is the only required tool; the bundle contains its complete public ancestry and requires no network access.

```sh
git clone --branch gpt-6-astra-pro_builtin-agents_rubywebterm_linux-source2105-20261110 PUBLIC-HISTORY.bundle lumen-source
git -C lumen-source rev-parse HEAD
git -C lumen-source rev-parse 'HEAD^{tree}'
```

Expected commit: `f2ea72ff37b6e52b9eef1e08bf902979f6fbdccf`.

Expected tracked tree: `acb04c8f4ff3de8e92350356a076a75efa85a74b`.

A fresh offline clone was checked against every tracked path, Git blob ID and executable mode before this archive was created. The three archive-only files PUBLIC-HISTORY.bundle, RESTORE-GIT.md and ARCHIVE-PROVENANCE.json are additive packaging metadata and are intentionally absent from that tracked tree. SOURCE-MANIFEST.json and EXPORT-QUALIFICATION.json map the reviewed exported source to the original working commit and state the validation limitations.
