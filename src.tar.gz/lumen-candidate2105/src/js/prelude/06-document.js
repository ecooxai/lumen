const allColl = new WeakMap(), allMeta = new WeakMap();
const baseURICache = new WeakMap();
function documentBaseURI(doc) {
    const version = N.version(doc), url = N.docBase(doc), cached = baseURICache.get(doc);
    if (cached && cached.version === version && cached.url === url) return cached.value;
    const base = N.query(doc, 'base[href]', false);
    const parsed = base && N.urlParse(N.attr(base, 'href'), url);
    const value = parsed ? parsed[0] : url;
    baseURICache.set(doc, { version, url, value });
    return value;
}
const allNamed = (l, k) => { for (const e of l) if (e.id === k || (e.getAttribute('name') === k)) return e; return null; };
class HTMLAllCollection {
    constructor() { illegal(); }
    get length() { return allMeta.get(this)().length; }
    item(k) { if (k === undefined) return null; const l = allMeta.get(this)(); return /^\d+$/.test(String(k)) ? l[+k] ?? null : allNamed(l, String(k)); }
    namedItem(k) { return allNamed(allMeta.get(this)(), String(k)); }
    [Symbol.iterator]() { return allMeta.get(this)()[Symbol.iterator](); }
}
/* HTML image maps: a point over an <img usemap="#name"> hits the first <area> of that map containing it, measured
   from the image's content box; the image itself when none does */
function imageMapHit(el, x, y) {
    if (!el || N.ns(el) !== 0 || el.localName !== 'img') return el;
    const um = N.attr(el, 'usemap');
    const h = um ? um.indexOf('#') : -1;
    if (h < 0 || h === um.length - 1) return el;
    const name = um.slice(h + 1), root = el.getRootNode();
    let map = null;
    for (const m of root.querySelectorAll('map')) if (N.attr(m, 'id') === name || N.attr(m, 'name') === name) { map = m; break; }
    if (!map) return el;
    const r = el.getBoundingClientRect(), cs = getComputedStyle(el), px = k => parseFloat(cs.getPropertyValue(k)) || 0;
    const ox = x - r.left - px('border-left-width') - px('padding-left'), oy = y - r.top - px('border-top-width') - px('padding-top');
    for (const a of map.querySelectorAll('area')) {
        const sh = (N.attr(a, 'shape') || 'rect').toLowerCase(), c = (N.attr(a, 'coords') || '').split(/[\s,;]+/).filter(Boolean).map(v => parseFloat(v) || 0);
        let hit = false;
        if (sh === 'default') hit = true;
        else if (sh === 'circle' || sh === 'circ') hit = c.length >= 3 && c[2] > 0 && Math.hypot(ox - c[0], oy - c[1]) <= c[2];
        else if (sh === 'poly' || sh === 'polygon') {
            const n = c.length >> 1;
            if (n >= 3) for (let i = 0, j = n - 1; i < n; j = i++) { const xi = c[2 * i], yi = c[2 * i + 1], xj = c[2 * j], yj = c[2 * j + 1]; if ((yi > oy) !== (yj > oy) && ox < (xj - xi) * (oy - yi) / (yj - yi) + xi) hit = !hit; }
        } else if (sh === 'rect' || sh === 'rectangle') {
            if (c.length >= 4) { const [x1, x2] = c[0] < c[2] ? [c[0], c[2]] : [c[2], c[0]], [y1, y2] = c[1] < c[3] ? [c[1], c[3]] : [c[3], c[1]]; hit = ox >= x1 && ox < x2 && oy >= y1 && oy < y2; }
        }
        if (hit) return a;
    }
    return el;
}
/* Legacy document colors reflect the body attributes, including null-to-empty
   DOMString conversion, and do nothing when the document has no HTML body. */
const docColorGet = (doc, attr) => { const b = doc.body; return b && b.namespaceURI === NSURI[0] && b.localName === 'body' ? N.attr(b, attr) ?? '' : ''; };
const docColorSet = (doc, attr, value) => { if (typeof value === 'symbol') throw new TypeError('Cannot convert a Symbol value to a string'); value = value === null ? '' : String(value); const b = doc.body; if (b && b.namespaceURI === NSURI[0] && b.localName === 'body') reflectSetAttr(b, attr, value); };
class Document extends Node { constructor() { if (new.target === HTMLDocument) illegal(); const d = N.newXmlDoc(undefined, true); Object.setPrototypeOf(d, new.target.prototype); def(d, '__url', 'about:blank'); return d; } }
unscopable(Document, ['append', 'fullscreen', 'prepend', 'replaceChildren']);
class HTMLDocument extends Document {}
class XMLDocument extends Document { constructor() { illegal(); } }
methods(Document.prototype, ParentNode);
installHandlers(Document.prototype, false, EVENT_HANDLERS.concat(FS_HANDLERS, ['readystatechange', 'visibilitychange', 'pointerlockchange', 'pointerlockerror', 'freeze', 'resume']));
const findChild = (p, tag) => { if (!p) return null; for (let c = N.first(p); c; c = N.next(c)) if (N.type(c) === 1 && N.name(c) === tag) return c; return null; };
const documentRoot = doc => { for (let c = N.first(doc); c; c = N.next(c)) if (N.type(c) === 1) return c; return null; };
const documentBody = doc => {
    const root = documentRoot(doc);
    if (!root || N.ns(root) !== 0 || N.name(root) !== 'html') return null;
    for (let c = N.first(root); c; c = N.next(c))
        if (N.type(c) === 1 && N.ns(c) === 0 && (N.name(c) === 'body' || N.name(c) === 'frameset')) return c;
    return null;
};
/* Keep the DOM replacement algorithm independent of author property overrides. */
const replaceBodyChild = Node.prototype.replaceChild;
/* the document's live HTMLCollections (forms, images, ...): the same object each time, with named properties */
const docColl = (doc, sel) => cachedLive(doc, 'coll:' + sel, () => N.query(doc, sel, true).filter(e => N.ns(e) === 0), HTMLCollection.prototype);
methods(Document.prototype, {
    get all() { let o = allColl.get(this); if (!o) { const d = this, list = () => d.getElementsByTagName('*'); o = N.makeAll(function (k) { if (typeof k === 'number' || /^\d+$/.test(k)) return list()[+k] ?? undefined; return k === undefined ? undefined : allNamed(list(), String(k)) ?? undefined; }); Object.setPrototypeOf(o, HTMLAllCollection.prototype); allMeta.set(o, list); allColl.set(this, o); } return o; },
    get documentElement() { for (let c = N.first(this); c; c = N.next(c)) if (N.type(c) === 1) return c; return null; },
    /* HTMLDocument.dir reflects the HTML root's enumerated dir attribute. A
       Document without an HTML root has no attribute to reflect. */
    get dir() { const root = this.documentElement; return root && root.namespaceURI === 'http://www.w3.org/1999/xhtml' && root.localName === 'html' ? root.dir : ''; },
    set dir(v) { if (typeof v === 'symbol') throw new TypeError('Cannot convert a Symbol value to a string'); v = String(v); const root = this.documentElement; if (root && root.namespaceURI === 'http://www.w3.org/1999/xhtml' && root.localName === 'html') root.dir = v; },
    get fgColor() { return docColorGet(this, 'text'); }, set fgColor(v) { docColorSet(this, 'text', v); },
    get bgColor() { return docColorGet(this, 'bgcolor'); }, set bgColor(v) { docColorSet(this, 'bgcolor', v); },
    get linkColor() { return docColorGet(this, 'link'); }, set linkColor(v) { docColorSet(this, 'link', v); },
    get alinkColor() { return docColorGet(this, 'alink'); }, set alinkColor(v) { docColorSet(this, 'alink', v); },
    get vlinkColor() { return docColorGet(this, 'vlink'); }, set vlinkColor(v) { docColorSet(this, 'vlink', v); },
    get head() { return findChild(this.documentElement, 'head'); },
    get body() {
        if (!N.isNode(this) || N.type(this) !== 9) throw new TypeError('Illegal invocation');
        return documentBody(this);
    },
    set body(value) {
        if (!N.isNode(this) || N.type(this) !== 9) throw new TypeError('Illegal invocation');
        if (value != null && (!N.isNode(value) || N.type(value) !== 1 || N.ns(value) !== 0))
            throw new TypeError("Failed to set 'body' on 'Document': the value is not of type 'HTMLElement'.");
        if (value == null || (N.name(value) !== 'body' && N.name(value) !== 'frameset'))
            throw hre('The new body element must be an HTML body or frameset.');
        const old = documentBody(this);
        if (old === value) return;
        if (old) { replaceBodyChild.call(N.parent(old), value, old); return; }
        const root = documentRoot(this);
        if (!root) throw hre('The document has no document element.');
        insertNode(root, value, null);
    },
    get doctype() { for (let c = N.first(this); c; c = N.next(c)) if (N.type(c) === 10) return c; return null; },
    get title() { const t = N.query(this, 'title', false); return t ? N.text(t).replace(/\s+/g, ' ').trim() : ''; },
    set title(v) { let t = N.query(this, 'title', false); if (!t) { const h = this.head; if (!h) return; t = N.create('title', 0); insertNode(h, t, null); } t.textContent = v; },
    get URL() { return this.__url ?? N.url(this); }, get documentURI() { return this.__url ?? N.url(this); },
    get baseURI() { return documentBaseURI(this); },
    get location() { return this === document ? location : null; }, set location(v) { if (this === document) location.href = v; },
    get domain() { const r = N.urlParse(N.url(), null); return r ? r[5] : ''; }, set domain(v) {},
    get referrer() { return ''; },
    get cookie() { return N.cookie(); }, set cookie(v) { v = String(v); if (!/[\x00-\x08\x0a-\x1f\x7f]/.test(v)) N.setCookie(v); },
    get readyState() { return ['loading', 'interactive', 'complete'][N.readyState()]; },
    get characterSet() { return N.charset(this); }, get charset() { return N.charset(this); }, get inputEncoding() { return N.charset(this); }, get contentType() { return this.__ct ?? N.ctype(this) ?? (N.ns(this) === 3 ? 'application/xml' : 'text/html'); },
    get compatMode() { return N.quirks(this) ? 'BackCompat' : 'CSS1Compat'; },
    get visibilityState() { return N.hidden() ? 'hidden' : 'visible'; }, get hidden() { return N.hidden(); }, get webkitHidden() { return N.hidden(); }, get prerendering() { return false; },
    get defaultView() { return this === document ? G : null; }, get activeElement() { return N.active() || this.body; },
    get currentScript() { return N.currentScript(); }, get scrollingElement() { return this.documentElement; },
    get forms() { return docColl(this, 'form'); }, get images() { return docColl(this, 'img'); },
    get links() { return docColl(this, 'a[href],area[href]'); }, get scripts() { return docColl(this, 'script'); },
    get embeds() { return docColl(this, 'embed'); }, get plugins() { return docColl(this, 'embed'); },
    get anchors() { return docColl(this, 'a[name]'); }, get applets() { return docColl(this, ':not(*)'); },
    get styleSheets() { return scopeSheets(this); },
    get adoptedStyleSheets() { return adoptedGet(this); }, set adoptedStyleSheets(v) { adoptSheets(this, v); },
    get fonts() { return fontSet; }, get timeline() { if (!this.__tl) def(this, '__tl', new DocumentTimeline()); return this.__tl; }, get fullscreenElement() { return fsCurrent(this); }, get fullscreenEnabled() { return true; },
    get webkitFullscreenElement() { return fsCurrent(this); }, get webkitCurrentFullScreenElement() { return fsCurrent(this); }, get webkitIsFullScreen() { return !!fsCurrent(this); }, get webkitFullscreenEnabled() { return true; },
    get fullscreen() { return !!fsCurrent(this); }, set fullscreen(v) {}, set fullscreenElement(v) {}, set fullscreenEnabled(v) {},
    exitFullscreen() { return fsExit(); }, webkitExitFullscreen() { fsExit().catch(() => {}); }, webkitCancelFullScreen() { fsExit().catch(() => {}); }, get pictureInPictureEnabled() { return false; },
    get implementation() { if (this === document) return implementation; if (!this.__impl) def(this, '__impl', Object.create(DOMImplementation.prototype, { _doc: { value: this } })); return this.__impl; },
    createElement(tag, opts) {
        tag = String(tag); if (!validLocalName(tag)) throw new DOMException(`The tag name provided ('${tag}') is not a valid name.`, 'InvalidCharacterError');
        /* XML documents keep the case; only XHTML ones make HTML elements */
        const xml = N.ns(this) === 3, html = !xml || this.contentType === 'application/xhtml+xml', name = xml ? tag : asciiLower(tag);
        const el = ceCreateElement(name, html ? 0 : 3, this, ceIsOption(opts));
        if (N.name(el) !== name) def(el, '__ln', name);
        return el;
    },
    createElementNS(ns, q, opts) {
        let pfx, l; [ns, pfx, l] = nsExtract(ns, q, false);
        const n = NSURI.indexOf(ns), el = ceCreateElement(n === 1 || n === 2 ? asciiLower(l) : l, n < 0 ? 3 : n, this, ceIsOption(opts), pfx);
        if (N.name(el) !== l) def(el, '__ln', l);
        if (n < 0) def(el, '__nsu', ns);
        if (pfx !== null) def(el, '__pfx', pfx);
        if (n < 0 || pfx !== null || N.name(el) !== l) N.xname(el, n < 0 ? ns : null, pfx, N.name(el) !== l ? l : null);   /* clones keep them */
        return el;
    },
    createAttribute(n) {
        n = String(n); if (!validAttrName(n)) throw new DOMException(`Failed to execute 'createAttribute' on 'Document': The localName provided ('${n}') contains an invalid character.`, 'InvalidCharacterError');
        return mkAttr(null, null, null, N.ns(this) !== 3 ? asciiLower(n) : n, '', this);
    },
    createAttributeNS(ns, q) { const [u, p, l] = nsExtract(ns, q, true); return mkAttr(null, u, p, l, '', this); },
    createTextNode(s) { return N.textNode(String(s), this); }, createComment(s) { return N.comment(String(s), this); },
    createDocumentFragment() { return N.frag(this); },
    createCDATASection(d) { if (N.ns(this) !== 3) throw new DOMException('This operation is not supported for HTML documents.', 'NotSupportedError'); d = String(d); if (d.includes(']]>')) throw new DOMException("String cannot contain ']]>' since that is the end delimiter of a CData section.", 'InvalidCharacterError'); return N.cdata(d, this); },
    createProcessingInstruction(t, d) { t = String(t); d = String(d); if (!/^[A-Za-z_:\u00C0-\uFFFF][\w.:\-\u00B7\u00C0-\uFFFF]*$/.test(t)) throw new DOMException(`The target provided ('${t}') is not a valid name.`, 'InvalidCharacterError'); if (d.includes('?>')) throw new DOMException("The data provided ('" + d + "') contains '?>'.", 'InvalidCharacterError'); return N.pi(t, d, this); },
    createEvent(t) {
        const m = { event: Event, events: Event, htmlevents: Event, svgevents: Event, customevent: CustomEvent, uievent: UIEvent, uievents: UIEvent, mouseevent: MouseEvent, mouseevents: MouseEvent,
            keyboardevent: KeyboardEvent, focusevent: FocusEvent, messageevent: MessageEvent, beforeunloadevent: BeforeUnloadEvent, compositionevent: CompositionEvent,
            devicemotionevent: DeviceMotionEvent, deviceorientationevent: DeviceOrientationEvent, dragevent: DragEvent, hashchangeevent: HashChangeEvent, storageevent: StorageEvent,
            textevent: TextEvent, touchevent: TouchEvent };
        const C = m[asciiLower(String(t))]; if (!C) throw new DOMException(`The provided event type ('${t}') is invalid.`, 'NotSupportedError');
        if (C === BeforeUnloadEvent || C === TextEvent) { const e = Reflect.construct(Event, [''], C); markUninit(e); return e; }
        const e = new C(''); markUninit(e); return e;
    },
    createRange() { const r = new Range(); r._sc = r._ec = this; return r; },
    createTreeWalker(root, what = 0xFFFFFFFF, filter = null) { return mkTraversal(TreeWalker, root, what, filter); },
    createNodeIterator(root, what = 0xFFFFFFFF, filter = null) { return mkTraversal(NodeIterator, root, what, filter); },
    getElementById(id) { return N.byId(String(id), this); },
    getElementsByName(n) { return nodeList(N.query(this, `[name="${CSS.escape(String(n))}"]`, true)); },
    importNode(n, deep = undefined) { if (!N.isNode(n)) throw new TypeError('The imported value must be a Node.'); if (N.type(n) === 9 || (N.type(n) === 11 && N.host(n))) throw new DOMException('A document or shadow root cannot be imported.', 'NotSupportedError'); const r = N.clone(n, !!deep, this); ceUpgradeTree(r); return r; }, adoptNode(n) { if (!N.isNode(n)) throw new TypeError("Failed to execute 'adoptNode' on 'Document': parameter 1 is not of type 'Node'."); if (N.type(n) === 9) throw new DOMException('The node provided is a document, which may not be adopted.', 'NotSupportedError'); if (N.type(n) === 11 && N.host(n)) throw new DOMException('The node provided is a shadow root, which may not be adopted.', 'HierarchyRequestError'); if (N.parent(n)) removeNode(n); N.adopt(n, this); return n; },
    hasFocus() { return true; }, getAnimations() { return waGetAnims(t => N.doc(t) === this && t.isConnected); },
    elementFromPoint(x, y) { hitArgs(arguments, 'elementFromPoint', 'Document'); if (!this.documentElement || this !== document) return null; return hitRetarget(imageMapHit(N.hit(+x, +y), +x, +y), this); },
    caretPositionFromPoint(x, y, opts) {
        if (arguments.length < 2) throw new TypeError(`Failed to execute 'caretPositionFromPoint' on 'Document': 2 arguments required, but only ${arguments.length} present.`);
        x = +x; y = +y;
        if (!Number.isFinite(x) || !Number.isFinite(y)) throw new TypeError("Failed to execute 'caretPositionFromPoint' on 'Document': The provided double value is non-finite.");
        const r = caretAt(this, x, y);
        if (!r) return null;
        let [n, off] = r;
        const roots = opts && opts.shadowRoots ? Array.from(opts.shadowRoots) : [];
        for (let h; (h = N.parent(n)) && N.type(h) === 11 && N.host(h) && !roots.includes(h);) { const host = N.host(h), p = N.parent(host); off = p ? Array.prototype.indexOf.call(p.childNodes, host) : 0; n = p || host; }
        return mkCaretPos(n, off);
    },
    caretRangeFromPoint(x, y) {
        const r = caretAt(this, +x, +y);
        if (!r) return null;
        const rg = this.createRange(); rg.setStart(r[0], r[1]); rg.collapse(true); return rg;
    },
    elementsFromPoint(x, y) { hitArgs(arguments, 'elementsFromPoint', 'Document'); return hitsFrom(this, +x, +y); },
    getSelection() { return selection; },
    execCommand(cmd, ui, val) {
        if (!arguments.length) throw argErr('execCommand');
        cmd = String(cmd).toLowerCase();
        if (cmd === 'inserthtml') val = ttString(TrustedHTML, val === undefined ? '' : val, 'Document execCommand');
        const ed = n => { for (; n; n = n.parentNode) if (n.nodeType === 1) { const v = n.getAttribute('contenteditable'); if (v === '' || v === 'true' || v === 'plaintext-only') return n; if (v === 'false') return null; } return null; };
        const ae = this.activeElement, sel = this.getSelection();
        let t = sel && sel.anchorNode; if (t && t.nodeType !== 1) t = t.parentNode;
        if (cmd === 'copy' || cmd === 'cut') {
            const dt = new DataTransfer(), ev = new ClipboardEvent(cmd, { clipboardData: dt, bubbles: true, cancelable: true, composed: true });
            (t || ae || this.body || this.documentElement).dispatchEvent(ev);
            const fld = ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA') ? ae : null;
            N.clipSet(ev.defaultPrevented ? dt.getData('text/plain') : fld ? String(fld.value).slice(fld.selectionStart, fld.selectionEnd) : String(sel || ''));
            return true;
        }
        if (!ed(t) && ae && ed(ae)) t = ae;
        if (!ed(t) && (cmd === 'inserttext' || cmd === 'inserthtml') && ae && (isHtmlEl(ae, 'input') || isHtmlEl(ae, 'textarea')))
            return this === document && execControlInsert(ae, cmd, val);
        if (this !== document) return false;
        const E = editing();
        val = val === undefined ? '' : `${val}`;
        const hist = cmd === 'undo' ? 'historyUndo' : cmd === 'redo' ? 'historyRedo' : null;
        if (!hist && (!E.supported(cmd) || !E.enabled(cmd))) return false;
        const host = editHostOf(sel), type = hist || EXEC_INPUT[cmd];
        let ok = false;
        try { ok = E.exec(cmd, !!ui, val, undefined); } catch (e) { ok = false; }
        if ((ok || EXEC_COLOR.has(cmd)) && host && type !== undefined)
            dispatch(host, new InputEvent('input', { inputType: type, data: execData(cmd, val), bubbles: true, composed: true }), true);
        return ok;
    },
    queryCommandEnabled(c) { if (!arguments.length) throw argErr('queryCommandEnabled'); return this === document && editQuery(E => E.enabled(String(c)), false); },
    queryCommandIndeterm(c) { if (!arguments.length) throw argErr('queryCommandIndeterm'); return this === document && editQuery(E => E.indeterm(String(c)), false); },
    queryCommandState(c) { if (!arguments.length) throw argErr('queryCommandState'); return this === document && editQuery(E => E.state(String(c)), false); },
    queryCommandSupported(c) {
        if (!arguments.length) throw argErr('queryCommandSupported');
        c = String(c).toLowerCase();
        return /^(copy|cut|paste|undo|redo)$/.test(c) || editing().supported(c);
    },
    queryCommandValue(c) { if (!arguments.length) throw argErr('queryCommandValue'); return this === document ? String(editQuery(E => E.value(String(c)), '')) : ''; },
    get designMode() { return designModes.get(this) || 'off'; },
    set designMode(v) { const s = String(v).toLowerCase(); if (s === 'on' || s === 'off') designModes.set(this, s); },
    open(a, b, c) {
        if (arguments.length > 2) return G.open(a, b, c);
        if (N.ns(this) === 3) throw new DOMException("Failed to execute 'open' on 'Document': Only HTML documents support open().", 'InvalidStateError');
        if (this !== document) return this;
        ceParserMarkupGuard(this);
        if (N.parserWritePoint()) return this;   /* an active parser script has a nonzero nesting level */
        resetOpenedDocumentEvents(this);
        N.docOpen();
        while (this.firstChild) this.removeChild(this.firstChild);
        docOpened.set(this, {});
        return this;
    },
    close() {
        if (this !== document) return;
        ceParserMarkupGuard(this);
        if (!docOpened.has(this)) return;
        docOpened.delete(this);
        N.docClose();
    },
    write(...s) { docWriteTo(this, ttWriteText(s, false)); }, writeln(...s) { docWriteTo(this, ttWriteText(s, true)); },
});
/* Script-created documents keep one live tokenizer across writes. An implicit
   open closes in a later task unless the script closes or replaces it first. */
const docOpened = new WeakMap(), designModes = new WeakMap();
const openedOwnDescriptor = Object.getOwnPropertyDescriptor;
const openedMapValues = Function.prototype.call.bind(SMap.prototype.values);
const openedMapClear = Function.prototype.call.bind(SMap.prototype.clear);
function resetOpenedDocumentEvents(doc) {
    const nodes = [G, doc];
    for (let i = 1; i < nodes.length; i++) {
        const node = nodes[i];
        for (let child = N.first(node); child; child = N.next(child)) apush(nodes, child);
        if (N.type(node) === 1) { const shadow = N.shadowOf(node); if (shadow) apush(nodes, shadow); }
    }
    for (let i = 0; i < nodes.length; i++) {
        const target = nodes[i], descriptor = openedOwnDescriptor(target, '__ls');
        const listeners = descriptor && descriptor.value;
        if (listeners instanceof SMap) {
            for (const records of openedMapValues(listeners))
                for (let j = 0; j < records.length; j++) records[j].removed = true;
            openedMapClear(listeners);
        }
        const realm = N.realmOf(target);
        if (realm && realm !== REALM) realm.resetOpenedHandlers(target);
        else resetOpenedHandlers(target);
    }
}

/* Text-control commands use the existing selection splice, not the contenteditable engine.
   maxlength limits UTF-16 code units; a truncation must not create half a surrogate pair. */
function execControlInsert(el, cmd, value) {
    const multiline = isHtmlEl(el, 'textarea');
    if (!multiline && !SEL_TYPES.test(inType(el))) return false;
    if (ctlDisabled(el) || N.attr(el, 'readonly') != null) return false;
    let text = cmd === 'inserthtml' ? execControlHTMLText(value, multiline) : (value === undefined ? '' : `${value}`);
    text = text.replace(/\r\n?/g, '\n');
    if (!multiline) text = text.replace(/\n/g, ' ');
    const before = el.value, [start, end] = selGet(el), max = el.maxLength;
    if (Number.isFinite(max) && max >= 0) {
        let take = Math.min(text.length, Math.max(0, max - (before.length - (end - start))));
        if (take && take < text.length && /[\uD800-\uDBFF]/.test(text[take - 1]) && /[\uDC00-\uDFFF]/.test(text[take])) take--;
        text = text.slice(0, take);
    }
    if (!text && start === end) return true;
    textSelection.setRangeText.call(el, text, start, end, 'end');
    const caret = Math.min(start + text.length, el.value.length);
    selSet(el, caret, caret, 'forward', true);
    const htmlArea = multiline && cmd === 'inserthtml';
    dispatch(el, new InputEvent('input', { inputType: htmlArea ? '' : 'insertText', data: htmlArea ? null : text, bubbles: true, composed: true }), true);
    return true;
}
/* A detached fragment is never inserted into the live document. parseFrag marks scripts
   started. Single-line controls retain inert text; textarea insertion keeps ordinary
   block/line boundaries. Full CSS-dependent rich-paste layout is outside this path. */
function execControlHTMLText(html, multiline) {
    const fragment = N.parseFrag(N.create('div', 0), html);
    let text = '', pending = 0;
    const flush = () => { if (text && pending) text += '\n'.repeat(pending); pending = 0; };
    const blocks = /^(address|article|aside|blockquote|dd|div|dl|dt|fieldset|figcaption|figure|footer|form|h[1-6]|header|hgroup|hr|li|main|nav|ol|p|pre|section|table|ul)$/;
    const walk = parent => {
        for (let node = N.first(parent); node; node = N.next(node)) {
            const type = N.type(node);
            if (type === 3 || type === 4) { const data = N.text(node); if (data) { flush(); text += data; } continue; }
            if (type !== 1) continue;
            const tag = N.ns(node) === 0 ? N.name(node) : '';
            if (tag === 'template') continue;
            if (multiline && (tag === 'script' || tag === 'style' || N.attr(node, 'hidden') != null)) continue;
            if (multiline) {
                const display = parseDecls(N.attr(node, 'style') || '').get('display');
                if (display && display[0].trim().toLowerCase() === 'none') continue;
            }
            if (tag === 'br') { flush(); text += '\n'; continue; }
            const block = multiline && blocks.test(tag);
            if (block) { flush(); if (text && !text.endsWith('\n')) text += '\n'; }
            walk(node);
            if (block) pending = Math.max(pending, tag === 'p' ? 2 : 1);
        }
    };
    if (fragment) walk(fragment);
    return text;
}
/* the editing commands, compiled on the document's first editing call with the prelude's own globals */
let editEngine = null;
function editing() {
    if (editEngine) return editEngine;
    ttInternal++;
    try { editEngine = new Function('document', 'getSelection', 'getComputedStyle', 'Node', N.lazySrc('editing'))(document, () => selection, getComputedStyle, Node); }
    finally { ttInternal--; }
    return editEngine;
}
/* a queryCommand*() answer; the specification's implementation throws strings on states it does not handle */
function editQuery(f, none) { try { return f(editing()); } catch (e) { return none; } }
/* the DOM position nearest viewport point (x, y): the text node and offset, else the element there and 0 */
const caretAt = (doc, x, y) => { const r = N.caret(x, y); if (r && N.doc(r[0]) === doc) return r; const e = N.hit(x, y); return e && N.doc(e) === doc ? [e, 0] : null; };
class CaretPosition {
    constructor() { illegal('CaretPosition'); }
    get offsetNode() { return cpPriv(this).n; } get offset() { return cpPriv(this).o; }
    getClientRect() { const { n, o } = cpPriv(this), r = new Range(); r.setStart(n, o); r.collapse(true); return r.getBoundingClientRect(); }
}
const cpData = new WeakMap(), cpPriv = o => { const d = cpData.get(o); if (!d) throw new TypeError('Illegal invocation'); return d; };
const mkCaretPos = (n, o) => { const c = Object.create(CaretPosition.prototype); cpData.set(c, { n, o }); return c; };
const argErr = m => new TypeError(`Failed to execute '${m}' on 'Document': 1 argument required, but only 0 present.`);
/* the editing host of the selection's start, before a command runs: where its input event goes */
function editHostOf(sel) {
    let n = sel && sel.rangeCount ? sel.getRangeAt(0).startContainer : null, host = null;
    for (; n && N.type(n) !== 9; n = N.parent(n)) if (N.type(n) === 1) {
        const s = ceState(n);
        if (s === 'false') break;
        if (s) host = n;
    }
    return host || (document.designMode === 'on' ? document.body : null);
}
/* execCommand()'s input event types (Input Events Level 2); commands missing here fire none */
const EXEC_INPUT = { inserttext: 'insertText', delete: 'deleteContentBackward', forwarddelete: 'deleteContentForward', insertparagraph: 'insertParagraph',
    insertlinebreak: 'insertLineBreak', insertorderedlist: 'insertOrderedList', insertunorderedlist: 'insertUnorderedList', inserthorizontalrule: 'insertHorizontalRule',
    inserthtml: 'insertHTML', insertimage: 'insertImage', createlink: 'insertLink', unlink: '', bold: 'formatBold', italic: 'formatItalic', underline: 'formatUnderline',
    strikethrough: 'formatStrikeThrough', superscript: 'formatSuperscript', subscript: 'formatSubscript', backcolor: 'formatBackColor', hilitecolor: 'formatBackColor',
    forecolor: 'formatFontColor', fontname: 'formatFontName', fontsize: 'formatFontSize', justifycenter: 'formatJustifyCenter', justifyfull: 'formatJustifyFull',
    justifyleft: 'formatJustifyLeft', justifyright: 'formatJustifyRight', removeformat: 'formatRemove', indent: 'formatIndent', outdent: 'formatOutdent', formatblock: 'formatBlock' };
const EXEC_COLOR = new SSet(['backcolor', 'hilitecolor', 'forecolor']);
/* the input event's data: the text, URL or font name as given, a color as its computed value */
function execData(cmd, val) {
    if (cmd === 'inserttext' || cmd === 'createlink' || cmd === 'fontname') return val;
    if (!EXEC_COLOR.has(cmd)) return null;
    const k = val.trim().toLowerCase();
    if (k === 'inherit' || k === 'initial' || k === 'reset' || k === 'currentcolor') return k;
    if (!N.cssSupports(`(color: ${val})`)) return val;
    const sp = document.createElement('span');
    sp.style.color = val;
    (document.body || document.documentElement).appendChild(sp);
    const c = getComputedStyle(sp).color;
    sp.remove();
    return c;
}
function docWriteTo(doc, html) {
    if (N.ns(doc) === 3) throw new DOMException("Failed to execute 'write' on 'Document': Only HTML documents support write().", 'InvalidStateError');
    if (doc !== document) return;
    ceParserMarkupGuard(doc);
    if (docOpened.has(doc) || N.docStreamWritePoint()) { N.docWrite(html); return; }
    if (N.ignoreWrites()) return;
    if (!N.parserWritePoint()) {
        doc.open();
        const opened = docOpened.get(doc);
        N.docWrite(html);
        setTimeout(() => { if (docOpened.get(doc) === opened) doc.close(); });
        return;
    }
    docWrite(html);
}
/* Each script's writes follow one another: insert before what followed the script at its first write. */
const docWriteRef = new WeakMap();
function docWrite(html) {
    const s = N.parserScript(), parent = s ? N.parent(s) : document.body;
    if (!parent) return;
    let ref = s ? N.next(s) : null;
    if (s) {
        if (docWriteRef.has(s)) { const r = docWriteRef.get(s); ref = r && N.parent(r) === parent ? r : null; }
        else docWriteRef.set(s, ref);
    }
    const f = N.parseFrag(parent, html, !!s);
    if (ttReq) ttSlotsFrom(f);
    insertNode(parent, f, ref);
    N.runWritten();
}
class DOMImplementation { constructor(key = undefined) { illegal(); } }
methods(DOMImplementation.prototype, { hasFeature() { return true; }, createHTMLDocument(t = undefined) { if (typeof t === 'symbol') throw new TypeError('Cannot convert a Symbol value to a string'); const d = N.newDoc(t === undefined ? null : String(t)); Object.setPrototypeOf(d, HTMLDocument.prototype); def(d, '__url', 'about:blank'); return d; }, createDocumentType(n, p, s) { n = String(n); if (/[\t\n\f\r >\x00]/.test(n)) throw new DOMException(`The qualified name provided ('${n}') contains the invalid name-start character.`, 'InvalidCharacterError'); return N.doctype(n, String(p), String(s), this._doc || document); },
    createDocument(ns, q, dt = null) {
        if (arguments.length < 2) throw new TypeError('2 arguments required');
        if (typeof ns === 'symbol') throw new TypeError('Cannot convert a Symbol value to a string');
        ns = ns == null ? null : String(ns); if (ns === '') ns = null;
        if (typeof q === 'symbol') throw new TypeError('Cannot convert a Symbol value to a string');
        q = q === null ? '' : String(q);
        if (dt !== null && (!N.isNode(dt) || N.type(dt) !== 10)) throw new TypeError('doctype is not a DocumentType');
        const d = N.newXmlDoc(ns === NSURI[0] ? 'application/xhtml+xml' : ns === NSURI[1] ? 'image/svg+xml' : 'application/xml');
        def(d, '__url', 'about:blank');
        const el = q ? Document.prototype.createElementNS.call(d, ns, q) : null;
        if (dt !== null) insertNode(d, dt, null);
        if (el) insertNode(d, el, null);
        return d;
    } });
const implementation = Object.create(DOMImplementation.prototype, { _doc: { get() { return document; } } });
/* a DOMImplementation from another (same-origin) realm makes its nodes and documents in that realm */
for (const k of ['createHTMLDocument', 'createDocumentType', 'createDocument']) {
    const f = DOMImplementation.prototype[k];
    Object.defineProperty(DOMImplementation.prototype, k, { value: { [k](...args) {
        const P = this !== null && typeof this === 'object' ? Object.getPrototypeOf(this) : null;
        if (P && P !== DOMImplementation.prototype && !DOMImplementation.prototype.isPrototypeOf(this) && typeof P[k] === 'function' && P[k] !== DOMImplementation.prototype[k]) return P[k].apply(this, args);
        return f.apply(this, args);
    } }[k], writable: true, configurable: true });
    Object.defineProperty(DOMImplementation.prototype[k], 'length', { value: f.length });
}

/* The Fullscreen API. The browser hides its own bars and gives the page the whole window; the element
   is :fullscreen, which the UA sheet stretches over the viewport. One element at a time; Back (or the
   browser otherwise) leaves through __lumenFullscreenExit. */
let fsEl = null;
function fsFire(el, type) {
    const t = el && el.isConnected ? el : document;
    for (const n of [type, 'webkit' + type]) t.dispatchEvent(new Event(n, { bubbles: true, composed: true }));
}
function fsRequest(el) {
    /* a promise-returning operation on a receiver that is not an Element rejects, as WebIDL's do */
    if (!N.isNode(el) || el.nodeType !== 1) return Promise.reject(new TypeError("Failed to execute 'requestFullscreen' on 'Element': Illegal invocation"));
    return new Promise((resolve, reject) => setTimeout(() => {
        if (!el.isConnected) {
            fsFire(el, 'fullscreenerror');
            reject(new TypeError("Failed to execute 'requestFullscreen' on 'Element': Element not connected"));
            return;
        }
        if (fsEl === el) { resolve(); return; }
        if (fsEl) N.fullscreen(fsEl, false, true);
        fsEl = el; N.fullscreen(el, true, true);
        fsAfterResize(() => { fsFire(el, 'fullscreenchange'); resolve(); });
    }, 0));
}
function fsExit() {
    if (!fsEl) return Promise.reject(new TypeError("Failed to execute 'exitFullscreen' on 'Document': Document not active"));
    const el = fsEl; fsEl = null; N.fullscreen(el, false, false);
    return new Promise(resolve => fsAfterResize(() => { fsFire(el, 'fullscreenchange'); resolve(); }));
}
/* As in Chrome, fullscreenchange follows the window's resize: pages measure the new viewport in it.
   The browser's bars go away in steps, so it waits for the resizes to settle (or a moment without one). */
let fsQueue = [], fsTimer = 0, fsDeadline = 0;
function fsAfterResize(fn) {
    fsQueue.push(fn);
    if (!fsTimer) { fsDeadline = N.now() + 1000; fsTimer = setTimeout(fsFlush, 600); }
}
function fsResized() {
    if (!fsTimer) return;
    clearTimeout(fsTimer);
    fsTimer = setTimeout(fsFlush, Math.max(0, Math.min(150, fsDeadline - N.now())));
}
function fsFlush() {
    fsTimer = 0;
    const q = fsQueue; fsQueue = [];
    for (const fn of q) fn();
}
/* the fullscreen element as doc sees it: a shadow tree's element shows as its host */
function fsCurrent(doc) {
    if (fsEl && !fsEl.isConnected) { fsExit().catch(() => {}); return null; }
    let e = fsEl;
    while (e && e.getRootNode() !== doc) { const r = e.getRootNode(); e = r && r.host || null; }
    return e;
}
Object.defineProperty(globalThis, '__lumenFullscreenExit', { value: () => { if (fsEl) fsExit().catch(() => {}); } });

/* hit testing seen from a document or shadow root: the spec's "retarget" of the hit element against that root */
const shadowIncAncestor = (a, b) => { for (let n = b; n; n = N.parent(n) || (N.type(n) === 11 ? N.host(n) : null)) if (n === a) return true; return false; };
function hitArgs(a, m, i) {
    if (a.length < 2) throw new TypeError(`Failed to execute '${m}' on '${i}': 2 arguments required, but only ${a.length} present.`);
    for (const k of [0, 1]) if (!Number.isFinite(+a[k])) throw new TypeError(`Failed to execute '${m}' on '${i}': The provided double value is non-finite.`);
}
function hitRetarget(e, root) {
    while (e) {
        const r = rootOf(e);
        if (N.type(r) !== 11 || !N.host(r) || shadowIncAncestor(r, root)) return e;
        e = N.host(r);
    }
    return null;
}
function hitsFrom(root, x, y) {
    const r = [];
    for (let e = N.hit(x, y); e; e = N.parent(e) || (N.type(e) === 11 ? N.host(e) : null)) {
        if (N.type(e) !== 1) continue;
        const t = hitRetarget(e, root);
        if (t && N.type(t) === 1 && r[r.length - 1] !== t) r.push(t);
    }
    return r;
}
methods(ShadowRoot.prototype, {
    elementFromPoint(x, y) { hitArgs(arguments, 'elementFromPoint', 'ShadowRoot'); return hitRetarget(N.hit(+x, +y), this); },
    elementsFromPoint(x, y) { hitArgs(arguments, 'elementsFromPoint', 'ShadowRoot'); return hitsFrom(this, +x, +y); },
});
