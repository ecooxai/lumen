#ifndef LUMEN_LAYOUT_H
#define LUMEN_LAYOUT_H
#include "../css/css.h"
#include "../text/font.h"
#include "affine.h"

typedef struct ArenaChunk ArenaChunk;
typedef struct Arena { ArenaChunk *head; size_t total; } Arena;
void *arena_alloc(Arena *a, size_t n);
void arena_reset(Arena *a);

enum BoxKind { BX_BLOCK, BX_INLINE, BX_TEXT, BX_ATOMIC, BX_BR };
enum Fmt { FMT_FLOW, FMT_INLINE, FMT_FLEX, FMT_GRID, FMT_TABLE, FMT_REPLACED };
enum { CTL_NONE, CTL_TEXT, CTL_CHECK, CTL_RADIO, CTL_BUTTON, CTL_SELECT, CTL_TEXTAREA, CTL_RANGE };

typedef struct TextFrag { struct Box *box; float x, y, w, h, base; int g0, g1; } TextFrag;
typedef struct Line { float y, h, base; int f0, nf; } Line;
typedef struct IRect { float x, y, w, h; bool first, last; int line; } IRect;

/* Owned by one layout box; sizes are final CSS pixels in logical track order. */
typedef struct GridUsedTracks {
    float *size[2];
    /* Views into the second half of each owned size allocation. Collapsed
       auto-fit tracks also collapse adjoining gutters; no extra owner. */
    float *gap_after[2];
    float offset[2], gap[2];  /* final content alignment and distributed gutters */
    int count[2], explicit_start[2], explicit_count[2], template_count[2];
} GridUsedTracks;

typedef struct Box {
    uint8_t kind, fmt, ctl;
    bool anon, abs, fixed, floated, bfc, scroller, placeholder, collapse_top, has_baseline, intr_ok, has_abs, is_marker;
    Node *node; ComputedStyle *st;
    struct Box *parent, *first, *last, *next, *prev;
    float x, y, w, h;           /* border box, document coordinates */
    float m[4], b[4], p[4];     /* top right bottom left */
    float eff_mb;
    char *text; int text_len; int *tsrc; Font *font; ShapedRun sh; bool shaped; struct ShapeEntry *shape_ref;   /* sh is shared with the shaping cache */
    TextFrag *frags; int nfrags, fcap;
    Line *lines; int nlines, lcap;
    IRect *ir; int nir, ircap;
    float baseline;
    GridUsedTracks *grid_used;
    float imin, imax;
    float scroll_w, scroll_h;
    int list_index;
    float sx, sy;
    struct Box *cb, *abs_next, *abs_head;
    uint8_t anchor_ok;   /* bit i: inset i (top right bottom left) resolved from anchor() */
    float mk[8]; int8_t mmode; bool memo; int alo, ahi; unsigned astamp; int dcalls;   /* inputs of the last layout_box, reused when called again with the same ones */
    uint64_t ink_gen; float ink0, ink1; bool defer_in;   /* paint culling: vertical extent of the normal-flow paint, and whether it holds boxes painted later (stacking); valid while doc_box_generation() + 1 == ink_gen */
    /* Private intrinsic block probes; arena-owned, one layout_run only. */
    const ComputedStyle *content_height_style;
    struct ContentHeightMemo *content_height_memo;
} Box;

/* The parentless synthetic document box is the viewport fallback. A fixed
 * descendant of an actual element containing block keeps that element's
 * transforms, scrolling and clips; only the fallback uses viewport state. */
static inline bool box_fixed_to_viewport(const Box *b) {
    return b && b->fixed && (!b->cb || !b->cb->parent);
}

/* Shared by viewport geometry, inverse hit testing, and the paint group.
 * Coordinates remain in the box tree's document frame. Sticky translation and
 * scrolling are separate operations outside this CSS transform. */
static inline Affine2D box_transform_matrix(const Box *b) {
    const ComputedStyle *s = b ? b->st : NULL;
    /* Anonymous layout wrappers may share their owner's complete style.
       Their element applies this transform once. Real pseudo boxes retain
       an element node and remain transform owners despite anon=true. */
    if (!s || !s->has_transform || !b->node || b->node->type != NODE_ELEMENT) return affine_identity();
    double ox = (double)b->x + s->transform_origin[0].px + (double)s->transform_origin[0].pct * b->w / 100;
    double oy = (double)b->y + s->transform_origin[1].px + (double)s->transform_origin[1].pct * b->h / 100;
    Affine2D m = {s->transform[0], s->transform[1], s->transform[2], s->transform[3],
        s->transform[4] + (double)s->translate_pending[0].pct * b->w / 100,
        s->transform[5] + (double)s->translate_pending[1].pct * b->h / 100};
    return affine_conjugate_translation(m, ox, oy);
}

typedef struct FRect { float x, y, w, h; uint8_t side; } FRect;
typedef struct FloatCtx { FRect *v; int n, cap; } FloatCtx;

typedef struct Layout {
    Arena arena;
    Box *root;
    Document *doc;
    float vw, vh, dpr;
    float doc_w, doc_h;
    int nboxes;
    bool measure_only; /* transient float preflight: no absolute registration or memo reuse */
    float inl_cbh;   /* containing-block height handed to layout_inline (floats/atomics resolve % heights against it) */
    double ms;
    struct Box **alog; int nalog, calog;   /* every add_abs of this run, so a reused subtree can re-register its abs boxes */
} Layout;

extern bool (*layout_image_size_hook)(Node *n, float *w, float *h);
Layout *layout_new(void);
void layout_free(Layout *L);
void layout_run(Layout *L, Document *d, float vw, float vh);
uint64_t layout_generation(void); /* changes after any completed document layout */
Box *layout_hit(Layout *layout, float x, float y, float scroll_x, float scroll_y);   /* document coordinates */
void box_sticky_offset(const Box *b, float scroll_x, float scroll_y, float *dx, float *dy);
/* Unscrolled native sticky constraint; NULL owner denotes the viewport. */
bool box_sticky_constraint_rect(const Box *b, const Box **port,
                                float *x, float *y, float *w, float *h);
Font *style_font(const ComputedStyle *s);
float style_line_height(const ComputedStyle *s, Font *f);
bool layout_contents_hidden(const Box *box);
/* Stored element offsets survive skipped contents and a temporarily absent
 * scroll container. Only the owner's effective offsets enter geometry. */
static inline bool box_scroll_active(const Box *b) {
    if (!b || !b->scroller || !b->node || layout_contents_hidden(b)) return false;
    /* scroller also marks clipping boxes. A visible/clip pair has no scroll
       container, so retained offsets and setters must remain inactive.
       Preserve the already-computed overflow pair and viewport propagation. */
    const ComputedStyle *s = b->st;
    return !s || (s->overflow_x != OV_VISIBLE && s->overflow_x != OV_CLIP) ||
                 (s->overflow_y != OV_VISIBLE && s->overflow_y != OV_CLIP);
}
static inline float box_scroll_left(const Box *b) { return box_scroll_active(b) ? b->node->scroll_x : 0; }
static inline float box_scroll_top(const Box *b) { return box_scroll_active(b) ? b->node->scroll_y : 0; }
/* column-reverse scrollers start at the end: scrollTop 0 is the bottom, negative scrolls up */
static inline bool box_within(const Box *x, const Box *a) { for (; x; x = x->parent) if (x == a) return true; return false; }
static inline bool box_scroll_from_end(const Box *b) { return b->st && (b->st->display == D_FLEX || b->st->display == D_INLINE_FLEX) && b->st->flex_direction == FD_COLUMN_REVERSE; }
static inline float box_scroll_y(const Box *b) { return box_scroll_active(b) ? b->node->scroll_y + (box_scroll_from_end(b) ? LMAX(0, b->scroll_h - b->h) : 0) : 0; }
void layout_dump(Box *b, int depth, int maxdepth);

/* internal */
enum { SZ_FILL, SZ_SHRINK, SZ_FORCED };
Box *build_box_tree(Layout *L, Document *d);
void compute_mbp(Box *b, float cbw);
/* Size containment affects intrinsic measurement, never descendant painting. */
bool layout_size_contained(const Box *box, bool horizontal);
bool layout_has_skipped_ancestor(const Box *box);
float layout_contained_inner_size(const Box *box, bool horizontal);
/* Anonymous/inline wrappers do not establish the percentage containing block. */
bool layout_percentage_wrapper(const Box *box);
const Box *layout_percentage_cb(const Box *box);
/* Final border-box stretch size; only an indefinite basis returns -1.
   Available space can be negative after absolute insets: subtract margins
   before flooring the inner size. Callers must not apply box-sizing again. */
float layout_stretch_border_size(const Box *box, const Box *percentage_cb,
                                bool horizontal, float available, bool definite);
void layout_box(Layout *L, Box *b, float x, float y, float cbw, float cbh, FloatCtx *fc, int mode, float fw, float fh);
float layout_inline(Layout *L, Box *b, float x0, float y0, float W, FloatCtx *fc);
float layout_flow(Layout *L, Box *b, float cx, float cy, float cw, float cbh, FloatCtx *fc);
float layout_flex(Layout *L, Box *b, float cx, float cy, float cw, float chdef);
float layout_grid(Layout *L, Box *b, float cx, float cy, float cw, float chdef);
void grid_absolute_containing_block(const Box *cb, const Box *a, float *x, float *y, float *w, float *h);
bool grid_intrinsic_explicit(Layout *L, Box *b, float *mn, float *mx);
float grid_item_auto_min(Layout *L, Box *c, float maxlen);   /* contribution to a minmax(auto, maxlen) column */
float layout_table(Layout *L, Box *b, float cx, float cy, float cw, float chdef);
void table_intrinsic(Layout *L, Box *b, float *mn, float *mx);
void intrinsic(Layout *L, Box *b, float *mn, float *mx);
void intrinsic_with_basis(Layout *L, Box *b, float cbw, float *mn, float *mx);
void intrinsic_outer(Layout *L, Box *b, float *mn, float *mx);
void intrinsic_content_width(Layout *L, Box *b, float cbw, float *mn, float *mx);
bool layout_width_constraint(Box *b, Length value, bool minimum, float cbw,
        float bp, float available, bool definite, float intrinsic_min,
        float intrinsic_max, float *out);
/* These measurements and the available size are already border-box values. */
static inline bool intrinsic_width_keyword(Length l) { return l.kind == LK_MIN_CONTENT || l.kind == LK_MAX_CONTENT || l.kind == LK_FIT_CONTENT; }
static inline float intrinsic_width_size(Length l, float mn, float mx, float available) {
    return l.kind == LK_MIN_CONTENT ? mn : l.kind == LK_MAX_CONTENT ? mx : LMIN(mx, LMAX(mn, available));
}
/* fw/fh are resolved border-box sizes from flex/grid, or -1 when unforced. */
void replaced_size(Layout *L, Box *b, float cbw, float cbh, float fw, float fh, float *w, float *h);
void box_translate(Box *b, float dx, float dy);
bool layout_move(Layout *L, Node *n, const Length old[4]);
void add_abs(Layout *L, Box *c);
void text_ensure_shaped(Box *t);
void text_release_shaped(Box *t);
void text_shape_cache_sweep(void);   /* after a layout pass: free shaped runs no box used recently */
void text_shape_cache_stats(unsigned *hits, unsigned *misses, size_t *entries); /* resets the counters */
void fc_avail(FloatCtx *fc, float y, float h, float x0, float x1, float *l, float *r);
void fc_place(FloatCtx *fc, Box *b, float y, float x0, float x1);
float fc_clear(FloatCtx *fc, int side);
float fc_bottom(FloatCtx *fc);
static inline float collapse2(float a, float b) { if (a >= 0 && b >= 0) return LMAX(a, b); if (a < 0 && b < 0) return LMIN(a, b); return a + b; }
static inline float res(Length l, float ref) {
    if (l.kind != LK_LEN) return 0;
    return len_resolve(l, ref > 0 ? ref : 0);
}
static inline bool len_def(Length l, float ref) { return l.kind == LK_LEN && (!len_has_pct(l) || ref >= 0); }
static inline float hbp(const Box *b) { return b->b[1] + b->b[3] + b->p[1] + b->p[3]; }
static inline float vbp(const Box *b) { return b->b[0] + b->b[2] + b->p[0] + b->p[2]; }
static inline bool in_flow(const Box *b) { return !b->abs && !b->floated; }
#endif
