/* Display list construction: CSS painting order over the box tree */
#include "paint.h"
#include <math.h>

Image *(*paint_image_hook)(Node *n);
Image *(*paint_url_image_hook)(const char *url);

typedef struct {
    DisplayList *dl; Layout *L;
    const Node *canvas_color_owner; /* already painted once over the canvas */
    float dx, dy;               /* doc -> viewport translation */
    float sx, sy;               /* page scroll */
    bool clip; float cx, cy, cw, ch;
    int order;
    bool fixed, sticky;         /* sticky: fixed only as a repaint region, inside a sticky box that moves with the page */
    Box *sb; const void *outer;   /* innermost scroller and the state outside it */
    const Box *mv, *mv_out;       /* scroller painted items move with, and the one outside it (for sticky boxes) */
    bool affine_source;          /* retain source ink that an ancestor transform can bring into view */
    bool cull; uint64_t gen;      /* skip normal-flow subtrees outside the viewport (box_ink extents of visual generation gen) */
} PB;

typedef struct { Box *b; PB state; int order; } Deferred;
typedef VEC(Deferred) DefVec;

static DItem *emit(PB *p, uint8_t op) { DItem it; memset(&it, 0, sizeof it); it.op = op; it.alpha = 1; it.fixed = p->fixed; it.sticky = p->sticky; it.mv = p->mv; vec_push(p->dl->items, it); return &p->dl->items.v[p->dl->items.n - 1]; }
static bool visible(PB *p, float x, float y, float w, float h) {
    if (p->affine_source) return true;
    if (x > p->dl->vw || y > p->dl->vh || x + w < 0 || y + h < 0) return false;
    if (p->clip && (x > p->cx + p->cw || y > p->cy + p->ch || x + w < p->cx || y + h < p->cy)) return false;
    return true;
}
static bool rounded(const ComputedStyle *s) {
    const Length *vertical = s->border_radius_y ? s->border_radius_y : s->border_radius;
    for (int i = 0; i < 4; i++)
        if (s->border_radius[i].px || s->border_radius[i].pct || s->border_radius[i].mm ||
            vertical[i].px || vertical[i].pct || vertical[i].mm) return true;
    return false;
}
static void radii(const Box *b, float w, float h, unsigned corners, float r[4], float ry[4]) {
    css_used_border_radii(b->st, w, h, corners, r, ry);
}

/* mask-image is approximated as the background colour shown through the mask's alpha */
typedef struct { Image *src; Color c; Image *out; } Tint;
static Tint tints[128]; static int tint_i; static Image *tint_grave[128]; static int tint_grave_i;
static Image *tinted(Image *src, Color c) {
    for (int i = 0; i < 128; i++) if (tints[i].src == src && tints[i].c == c) return tints[i].out;
    Tint *t = &tints[tint_i]; tint_i = (tint_i + 1) % 128;
    if (t->out) {
        if (tint_grave[tint_grave_i]) image_unref(tint_grave[tint_grave_i]);
        tint_grave[tint_grave_i] = t->out; tint_grave_i = (tint_grave_i + 1) % 128; image_unref(t->src);
    }
    size_t n = (size_t)src->w * (size_t)src->h;
    Image *o = xcalloc(1, sizeof *o); o->w = src->w; o->h = src->h; o->refs = 1; o->scale = src->scale; o->px = xmalloc(n * 4);
    uint32_t ca = COLOR_A(c), cr = COLOR_R(c), cg = COLOR_G(c), cb = COLOR_B(c);
    for (size_t i = 0; i < n; i++) { uint32_t a = (src->px[i] >> 24) * ca / 255; o->px[i] = a << 24 | (cr * a / 255) << 16 | (cg * a / 255) << 8 | cb * a / 255; }
    src->refs++; t->src = src; t->c = c; t->out = o;
    return o;
}

typedef struct BgArea { float x, y, w, h, r[4], ry[4]; } BgArea;
static BgArea background_area(const Box *b, float x, float y, float w, float h,
                              int kind, const float outer_r[4], const float outer_ry[4], bool l_edge, bool r_edge) {
    float in[4] = {0};
    if (kind != BG_BORDER_BOX) for (int i = 0; i < 4; i++) {
        if ((i == 3 && !l_edge) || (i == 1 && !r_edge)) continue;
        in[i] = b->b[i] + (kind == BG_CONTENT_BOX ? b->p[i] : 0);
    }
    BgArea a = {.x = x + in[3], .y = y + in[0],
        .w = LMAX(0, w - in[1] - in[3]), .h = LMAX(0, h - in[0] - in[2])};
    rounded_radii_inset(outer_r, outer_ry, in, a.r, a.ry);
    return a;
}
/* Background position percentages use (positioning area - image size), which
 * may be negative. Layout's indefinite-size resolver must not be used here. */
static float background_length(Length l, float reference) {
    if (l.kind != LK_LEN) return 0;
    return len_resolve(l, reference);
}
static void paint_background_source(PB *p, const ComputedStyle *s, const BgArea *area,
                                    const BgArea *clip_area, Image *im, Gradient *grad) {
    if (clip_area->w <= 0 || clip_area->h <= 0 || !isfinite(area->w) || !isfinite(area->h)) return;
    float iw = im ? image_css_w(im) : area->w, ih = im ? image_css_h(im) : area->h;
    if ((im && (iw <= 0 || ih <= 0)) || !isfinite(iw) || !isfinite(ih)) return;
    bool auto_x = s->bg_size_kind == BGS_AUTO || (s->bg_size_kind == BGS_LEN && s->bg_size[0].kind != LK_LEN);
    bool auto_y = s->bg_size_kind == BGS_AUTO || (s->bg_size_kind == BGS_LEN && s->bg_size[1].kind != LK_LEN);
    if (s->bg_size_kind == BGS_COVER || s->bg_size_kind == BGS_CONTAIN) {
        if (im) { float scale = s->bg_size_kind == BGS_COVER ? LMAX(area->w / iw, area->h / ih) : LMIN(area->w / iw, area->h / ih); iw *= scale; ih *= scale; }
        else { iw = area->w; ih = area->h; }
    } else if (s->bg_size_kind == BGS_LEN) {
        float w = auto_x ? -1 : LMAX(0, background_length(s->bg_size[0], area->w));
        float h = auto_y ? -1 : LMAX(0, background_length(s->bg_size[1], area->h));
        if (w >= 0 && h >= 0) { iw = w; ih = h; }
        else if (w >= 0) { ih = im ? ih * w / iw : area->h; iw = w; }
        else if (h >= 0) { iw = im ? iw * h / ih : area->w; ih = h; }
    }
    if (iw <= 0 || ih <= 0 || !isfinite(iw) || !isfinite(ih)) return;
    int rx = s->bg_repeat & 3, ry = (s->bg_repeat >> 2) & 3;
    float original_w = iw, original_h = ih;
    if (rx == BGR_ROUND) iw = (float)(area->w / fmax(1, floor((double)area->w / iw + .5)));
    if (ry == BGR_ROUND) ih = (float)(area->h / fmax(1, floor((double)area->h / ih + .5)));
    if (rx == BGR_ROUND && ry != BGR_ROUND && auto_y) ih = original_h * iw / original_w;
    if (ry == BGR_ROUND && rx != BGR_ROUND && auto_x) iw = original_w * ih / original_h;
    if (iw <= 0 || ih <= 0 || !isfinite(iw) || !isfinite(ih)) return;
    double ox = (double)area->x + background_length(s->bg_pos[0], area->w - iw);
    double oy = (double)area->y + background_length(s->bg_pos[1], area->h - ih);
    float step_x = rx == BGR_NO_REPEAT ? 0 : iw, step_y = ry == BGR_NO_REPEAT ? 0 : ih;
    if (rx == BGR_SPACE) {
        double count = floor((double)area->w / iw);
        if (count < 2) step_x = 0;
        else { ox = area->x; step_x = (float)((area->w - iw) / (count - 1)); }
    }
    if (ry == BGR_SPACE) {
        double count = floor((double)area->h / ih);
        if (count < 2) step_y = 0;
        else { oy = area->y; step_y = (float)((area->h - ih) / (count - 1)); }
    }
    if (!isfinite(ox) || !isfinite(oy) || !isfinite(step_x) || !isfinite(step_y)) return;
    /* Reduce the phase once, without a subtraction loop or integer tile count. */
    if (step_x > 0) ox = clip_area->x + fmod(ox - clip_area->x, step_x);
    if (step_y > 0) oy = clip_area->y + fmod(oy - clip_area->y, step_y);
    float x = clip_area->x, y = clip_area->y, right = x + clip_area->w, bottom = y + clip_area->h;
    if (step_x <= 0) { x = LMAX(x, (float)ox); right = LMIN(right, (float)(ox + iw)); }
    if (step_y <= 0) { y = LMAX(y, (float)oy); bottom = LMIN(bottom, (float)(oy + ih)); }
    if (right <= x || bottom <= y || !visible(p, x, y, right - x, bottom - y)) return;
    DItem *it = emit(p, im ? DO_IMAGE : DO_GRADIENT); it->x = x; it->y = y; it->w = right - x; it->h = bottom - y; it->img = im; it->grad = grad;
    ditem_set_radii(it, clip_area->r, clip_area->ry);
    it->tile = (BackgroundTile){(float)(ox - x), (float)(oy - y), iw, ih, step_x, step_y,
                               clip_area->x - x, clip_area->y - y, clip_area->w, clip_area->h};
}

/* Generic mask-repeat values are retained even though masks use the existing
 * background-colour approximation. Change only the initial/repeat operation;
 * explicit no-repeat and other authored modes keep their previous path. */
static bool mask_default_repeat(const ComputedStyle *s) {
    const char *value = custom_get(s->gen_n, "mask-repeat");
    if (!value || !*value) return true;
    char a[16], b[16], extra[2];
    int n = sscanf(value, "%15s %15s %1s", a, b, extra);
    return (n == 1 && str_ieq(a, "repeat")) ||
           (n == 2 && str_ieq(a, "repeat") && str_ieq(b, "repeat"));
}

static void paint_rect_deco(PB *p, Box *b, float x, float y, float w, float h, bool l_edge, bool r_edge) {
    const ComputedStyle *s = b->st;
    if (!visible(p, x - 64, y - 64, w + 128, h + 128)) return;
    float r[4], ry[4];
    /* Sliced inline fragments have no curve on an absent start/end edge. */
    unsigned corners = (l_edge ? 9u : 0u) | (r_edge ? 6u : 0u);
    radii(b, w, h, corners, r, ry);
    if (s->mask_image) {
        Image *mk = paint_url_image_hook ? paint_url_image_hook(s->mask_image) : NULL;
        if (!mk || !mk->w || !mk->h || !COLOR_A(s->bg_color)) return;
        float iw = image_css_w(mk), ih = image_css_h(mk), ox = x, oy = y;
        if (s->mask_fit) { float k = s->mask_fit == 1 ? LMIN(w / iw, h / ih) : LMAX(w / iw, h / ih); iw *= k; ih *= k; ox += (w - iw) / 2; oy += (h - ih) / 2; }
        DItem *c = emit(p, DO_PUSH_CLIP); c->x = x; c->y = y; c->w = w; c->h = h; ditem_set_radii(c, r, ry);
        DItem *it = emit(p, DO_IMAGE); it->x = ox; it->y = oy; it->w = iw; it->h = ih; it->img = tinted(mk, s->bg_color);
        if (!s->mask_fit && mask_default_repeat(s)) {
            /* Tile at intrinsic CSS size through the existing image lattice,
               without allocating a display item for each repeated image. */
            it->x = x; it->y = y; it->w = w; it->h = h;
            it->tile = (BackgroundTile){0, 0, iw, ih, iw, ih, 0, 0, w, h};
        }
        emit(p, DO_POP_CLIP);
        return;
    }
    if (s->has_shadow && !s->box_shadow.inset && COLOR_A(s->box_shadow.color)) {
        DItem *it = emit(p, DO_SHADOW); it->x = x + s->box_shadow.x; it->y = y + s->box_shadow.y; it->w = w; it->h = h;
        ditem_set_radii(it, r, ry); it->color = s->box_shadow.color; it->blur = s->box_shadow.blur; it->spread = s->box_shadow.spread;
        it->ox = s->box_shadow.x; it->oy = s->box_shadow.y;
    }
    BgArea bg_clip = background_area(b, x, y, w, h, s->bg_clip, r, ry, l_edge, r_edge);
    BgArea bg_origin = background_area(b, x, y, w, h, s->bg_origin, r, ry, l_edge, r_edge);
    BgArea color_clip = background_area(b, x, y, w, h, s->bg_color_clip, r, ry, l_edge, r_edge);
    if ((!p->canvas_color_owner || b->node != p->canvas_color_owner) && COLOR_A(s->bg_color) && color_clip.w > 0 && color_clip.h > 0) {
        Color c = s->bg_color;
        /* backdrop-filter: blur() isn't rendered; blurred content behind a translucent surface reads as
           nearly flat, so approximate it by cutting the remaining transparency to a quarter. A strong blur
           (YouTube's frosted masthead, 48 px) leaves no shapes at all: a mostly opaque surface is drawn
           opaque, since faint sharp text behind it reads as stale pixels */
        if (s->backdrop_blur > 0 && COLOR_A(c) < 255)
            c = (c & 0xffffff) | (Color)(s->backdrop_blur >= 16 && COLOR_A(c) >= 128 ? 255 : 255 - (255 - COLOR_A(c)) / 4) << 24;
        DItem *it = emit(p, DO_RECT); it->x = color_clip.x; it->y = color_clip.y; it->w = color_clip.w; it->h = color_clip.h; ditem_set_radii(it, color_clip.r, color_clip.ry); it->color = c;
    }
    if (s->bg_gradient) paint_background_source(p, s, &bg_origin, &bg_clip, NULL, s->bg_gradient);
    if (s->bg_image && paint_url_image_hook) {
        Image *im = paint_url_image_hook(s->bg_image);
        if (im && im->w && im->h) paint_background_source(p, s, &bg_origin, &bg_clip, im, NULL);
    }
    float bw[4]; bool any = false;
    for (int i = 0; i < 4; i++) { bw[i] = b->b[i]; if ((i == 3 && !l_edge) || (i == 1 && !r_edge)) bw[i] = 0; if (bw[i] > 0 && s->border_style[i] > BS_HIDDEN && COLOR_A(s->border_color[i])) any = true; else bw[i] = 0; }
    if (any) { DItem *it = emit(p, DO_BORDER); it->x = x; it->y = y; it->w = w; it->h = h; ditem_set_radii(it, r, ry); memcpy(it->bw, bw, sizeof bw); memcpy(it->bc, s->border_color, sizeof it->bc); memcpy(it->bs, s->border_style, 4); }
    if (s->outline_style > BS_HIDDEN && s->outline_width > 0 && COLOR_A(s->outline_color)) {
        float o = s->outline_offset + s->outline_width;
        DItem *it = emit(p, DO_BORDER); it->x = x - o; it->y = y - o; it->w = w + 2 * o; it->h = h + 2 * o;
        /* the outline follows the box's rounded corners, grown by its offset and width */
        float outline_x[4], outline_y[4];
        for (int i = 0; i < 4; i++) {
            it->bw[i] = s->outline_width; it->bc[i] = s->outline_color; it->bs[i] = s->outline_style;
            outline_x[i] = r[i] > 0 ? LMAX(0, r[i] + o) : 0;
            outline_y[i] = ry[i] > 0 ? LMAX(0, ry[i] + o) : 0;
        }
        rounded_square_corners(outline_x, outline_y); ditem_set_radii(it, outline_x, outline_y);
    }
}

static void emit_glyphs(PB *p, Box *t, TextFrag *f, float ox, float oy, Color col) {
    DItem *it = emit(p, DO_TEXT);
    int n = f->g1 - f->g0;
    it->g = arena_alloc(&p->dl->arena, sizeof(DGlyph) * (size_t)n); it->ng = 0;
    float x0 = t->sh.g[f->g0].x;
    for (int i = f->g0; i < f->g1; i++) {
        GlyphPos *g = &t->sh.g[i];
        char ch = t->text[g->cluster];
        if (ch == ' ' || ch == '\n') continue;
        DGlyph *d = &it->g[it->ng++]; d->gid = g->gid; d->font = g->font; d->x = f->x + (g->x - x0) + p->dx + ox; d->y = f->base + g->y + p->dy + oy;
    }
    it->color = col; it->x = f->x + p->dx + ox; it->y = f->y + p->dy + oy; it->w = f->w; it->h = f->h;
}

static void paint_text_frag(PB *p, TextFrag *f) {
    Box *t = f->box; const ComputedStyle *s = t->st;
    if (s->visibility != VIS_VISIBLE || f->g1 <= f->g0) return;
    if (!visible(p, f->x + p->dx, f->y + p->dy, f->w, f->h)) return;
    Color col = s->color;
    Box *blk = t->parent; while (blk && blk->kind == BX_INLINE) blk = blk->parent;
    if (blk && blk->placeholder) col = RGBA(117, 117, 117, COLOR_A(col));
    int ss, se, edge = 0;
    bool sel = tsel_range(t, &ss, &se) ? (edge = tsel_edge(t), true) : ctl_range(t, &ss, &se) ? (edge = 3, true) : false;
    if (sel) {
        float x0 = t->sh.g[f->g0].x, a = -1, e = -1;
        for (int i = f->g0; i < f->g1; i++) {
            int c = (int)t->sh.g[i].cluster;
            if (c >= ss && c < se) { float gx = t->sh.g[i].x - x0; if (a < 0) a = gx; e = gx + t->sh.g[i].adv; }
        }
        if (a >= 0 && e > a) { DItem *it = emit(p, DO_RECT); it->x = f->x + a + p->dx; it->y = f->y + p->dy; it->w = e - a; it->h = f->h; it->color = RGBA(179, 215, 255, 255); }
        if (edge) {   /* touch handles sit under the first and last selected glyphs */
            for (int i = f->g0; i < f->g1; i++) {
                int c = (int)t->sh.g[i].cluster; float gx = f->x + t->sh.g[i].x - x0 + p->dx;
                if (c < ss || c >= se) continue;
                TselCaret *k = &g_tsel_caret[0];
                if ((edge & 1) && (!k->ok || c < k->cluster)) *k = (TselCaret){ true, gx, f->y + p->dy, f->h, c };
                k = &g_tsel_caret[1];
                if ((edge & 2) && (!k->ok || c >= k->cluster)) *k = (TselCaret){ true, gx + t->sh.g[i].adv, f->y + p->dy, f->h, c };
            }
        }
    }
    if (s->has_text_shadow && COLOR_A(s->text_shadow.color)) emit_glyphs(p, t, f, s->text_shadow.x, s->text_shadow.y, s->text_shadow.color);
    emit_glyphs(p, t, f, 0, 0, col);
    /* text-decoration may come from an ancestor inline */
    uint8_t deco = s->text_decoration; Color dc = s->color;
    for (Box *a = t->parent; a && !deco; a = a->parent) { if (a->st && a->st->text_decoration) { deco = a->st->text_decoration; dc = a->st->color; } if (a->kind != BX_INLINE) break; }
    if (deco && t->font) {
        float th = LMAX(1, t->font->underline_thick);
        float x = f->x + p->dx, w = f->w;
        if (deco & TD_UNDERLINE) { DItem *it = emit(p, DO_LINE); it->x = x; it->y = f->base + p->dy + t->font->underline_pos;   /* underline_pos: distance below the baseline */ it->w = w; it->h = th; it->color = dc; }
        if (deco & TD_LINE_THROUGH) { DItem *it = emit(p, DO_LINE); it->x = x; it->y = f->base + p->dy - t->font->x_height / 2; it->w = w; it->h = th; it->color = dc; }
        if (deco & TD_OVERLINE) { DItem *it = emit(p, DO_LINE); it->x = x; it->y = f->y + p->dy; it->w = w; it->h = th; it->color = dc; }
    }
}

static void paint_marker(PB *p, Box *b) {
    const ComputedStyle *s = b->st, *ms = s->marker ? s->marker : s;
    if (s->list_style == LST_NONE) return;
    const Box *lb = b;
    while (lb && !lb->nlines) {
        const Box *c = lb->first;
        while (c && (c->abs || c->floated || c->kind == BX_TEXT || c->kind == BX_BR || c->kind == BX_INLINE)) c = c->next;
        lb = c;
    }
    if (!lb) return;
    Font *f = style_font(ms);
    float base = lb->lines[0].base + p->dy, x = b->x + p->dx;
    if (s->list_style == LST_DISC || s->list_style == LST_CIRCLE || s->list_style == LST_SQUARE) {
        float d = LMAX(4, ms->font_size * 0.33f), cy = base - (f ? f->x_height / 2 : d / 2);
        DItem *it = emit(p, s->list_style == LST_CIRCLE ? DO_BORDER : DO_RECT);
        it->x = x - d - ms->font_size * 0.5f; it->y = cy - d / 2; it->w = d; it->h = d; it->color = ms->color;
        if (s->list_style != LST_SQUARE) for (int i = 0; i < 4; i++) it->r[i] = d / 2;
        if (it->op == DO_BORDER) for (int i = 0; i < 4; i++) { it->bw[i] = 1; it->bc[i] = ms->color; it->bs[i] = BS_SOLID; }
        return;
    }
    char buf[32]; int n = b->list_index;
    if (s->list_style == LST_LOWER_ALPHA || s->list_style == LST_UPPER_ALPHA) snprintf(buf, sizeof buf, "%c.", (s->list_style == LST_LOWER_ALPHA ? 'a' : 'A') + (n - 1) % 26);
    else if (s->list_style == LST_LOWER_ROMAN || s->list_style == LST_UPPER_ROMAN) {
        static const char *R[] = { "m","cm","d","cd","c","xc","l","xl","x","ix","v","iv","i" }; static const int V[] = { 1000,900,500,400,100,90,50,40,10,9,5,4,1 };
        int k = 0; for (int i = 0; i < 13 && k < 24; i++) while (n >= V[i] && k < 24) { for (const char *c = R[i]; *c; c++) buf[k++] = s->list_style == LST_UPPER_ROMAN ? (char)(*c - 32) : *c; n -= V[i]; }
        buf[k++] = '.'; buf[k] = 0;
    } else snprintf(buf, sizeof buf, "%d.", n);
    ShapedRun r; text_shape(f, buf, strlen(buf), 0, &r);
    DItem *it = emit(p, DO_TEXT); it->g = arena_alloc(&p->dl->arena, sizeof(DGlyph) * (size_t)LMAX(1, r.n)); it->color = ms->color;
    float x0 = x - r.width - ms->font_size * 0.4f;
    for (int i = 0; i < r.n; i++) { DGlyph *d = &it->g[it->ng++]; d->gid = r.g[i].gid; d->font = r.g[i].font; d->x = x0 + r.g[i].x; d->y = base + r.g[i].y; }
    shaped_free(&r);
}

static void paint_replaced(PB *p, Box *b) {
    float x = b->x + p->dx + b->b[3] + b->p[3], y = b->y + p->dy + b->b[0] + b->p[0], w = b->w - hbp(b), h = b->h - vbp(b);
    if (!visible(p, x, y, w, h)) return;
    if (b->ctl == CTL_CHECK || b->ctl == CTL_RADIO) {
        bool on = b->node && (b->node->checked_override ? b->node->checked_override > 0 : node_has_attr(b->node, "checked"));
        DItem *it = emit(p, on ? DO_RECT : DO_BORDER); it->x = x; it->y = y; it->w = w; it->h = h;
        float rr = b->ctl == CTL_RADIO ? w / 2 : 2; for (int i = 0; i < 4; i++) { it->r[i] = rr; it->bw[i] = 1; it->bc[i] = RGBA(118, 118, 118, 255); it->bs[i] = BS_SOLID; }
        it->color = RGBA(0, 117, 255, 255);
        if (on) { DItem *d = emit(p, DO_RECT); float k = b->ctl == CTL_RADIO ? w * 0.3f : w * 0.25f; d->x = x + k; d->y = y + k; d->w = w - 2 * k; d->h = h - 2 * k; d->color = RGBA(255, 255, 255, 255); for (int i = 0; i < 4; i++) d->r[i] = b->ctl == CTL_RADIO ? d->w / 2 : 1; }
        return;
    }
    if (b->ctl == CTL_RANGE) { DItem *t = emit(p, DO_RECT); t->x = x; t->y = y + h / 2 - 2; t->w = w; t->h = 4; t->color = RGBA(0, 117, 255, 255); for (int i = 0; i < 4; i++) t->r[i] = 2; DItem *k = emit(p, DO_RECT); k->x = x + w / 2 - 8; k->y = y; k->w = 16; k->h = 16; k->color = RGBA(0, 117, 255, 255); for (int i = 0; i < 4; i++) k->r[i] = 8; return; }
    Image *im = b->node && b->node->ns == NS_SVG ? svg_image(b->node, w, h, 2) : paint_image_hook && b->node ? paint_image_hook(b->node) : NULL;
    if (!im || !im->w || !im->h) return;
    float dw = w, dh = h, dx = x, dy = y;
    int of = b->st->object_fit;
    if (of == OF_CONTAIN || of == OF_COVER || of == OF_SCALE_DOWN || of == OF_NONE) {
        float k = of == OF_NONE ? 1 : of == OF_COVER ? LMAX(w / im->w, h / im->h) : LMIN(w / im->w, h / im->h);
        if (of == OF_SCALE_DOWN) k = LMIN(k, 1);
        dw = im->w * k; dh = im->h * k; dx = x + (w - dw) / 2; dy = y + (h - dh) / 2;
    }
    bool needclip = dw > w + 0.5f || dh > h + 0.5f || rounded(b->st);
    if (needclip) {
        float outer_x[4], outer_y[4]; radii(b, b->w, b->h, 15u, outer_x, outer_y);
        BgArea area = background_area(b, b->x + p->dx, b->y + p->dy, b->w, b->h,
            BG_CONTENT_BOX, outer_x, outer_y, true, true);
        DItem *c = emit(p, DO_PUSH_CLIP); c->x = x; c->y = y; c->w = w; c->h = h;
        ditem_set_radii(c, area.r, area.ry);
    }
    DItem *it = emit(p, DO_IMAGE); it->x = dx; it->y = dy; it->w = dw; it->h = dh; it->img = im;
    if (needclip) emit(p, DO_POP_CLIP);
}

/* Text boxes share their parent's complete style for shaping, but they do
 * not own its positioning/layer phase. Pseudo boxes retain their originating
 * element node and remain real owners; node-null wrappers stay in flow. */
static bool paint_element_owner(const Box *b) { return b && b->st && b->node && b->node->type == NODE_ELEMENT; }
static bool positioned(const Box *b) { return paint_element_owner(b) && (b->st->position != P_STATIC || (!b->st->z_auto && b->parent && b->parent->st && (b->parent->fmt == FMT_FLEX || b->parent->fmt == FMT_GRID))); }
static bool makes_layer(const Box *b) { return paint_element_owner(b) && (b->st->opacity < 1 || b->st->has_transform || b->st->isolation || b->st->position != P_STATIC || layout_contents_hidden(b)); }
static bool makes_context(const Box *b) {
    if (!paint_element_owner(b)) return false;
    const ComputedStyle *s = b->st;
    return layout_contents_hidden(b) || s->opacity < 1 || s->has_transform || s->isolation ||
           s->position == P_FIXED || s->position == P_STICKY ||
           (positioned(b) && !s->z_auto);
}
static int stack_level(const Box *b) { return positioned(b) && !b->st->z_auto ? b->st->z_index : 0; }

static void paint_stacking(PB *p, Box *b, bool context);
static void paint_flow(PB *p, Box *b);

/* Off-screen culling. box_ink() keeps, per box, the vertical extent of what paint_block_content
   paints for it (its box, normal-flow children, floats, line content; a clipping scroller only its
   box) and whether that walk would collect boxes painted later in stacking order (positioned or
   layered ones), which must still be found. A subtree without those whose extent, widened by the
   64 px decoration margin paint_rect_deco allows, misses the viewport or clip is skipped whole.
   The extents hold until the next layout or restyle (doc_box_generation; scrolling keeps them). */
static void box_ink(Box *b, uint64_t gen);
static void ink_inline(Box *ib, uint64_t gen, float *y0, float *y1, bool *defer) {
    for (Box *c = ib->first; c; c = c->next) {
        if (positioned(c) || makes_layer(c) || c->abs) { *defer = true; continue; }
        if (c->kind != BX_INLINE) continue;
        for (int i = 0; i < c->nir; i++) { *y0 = LMIN(*y0, c->ir[i].y); *y1 = LMAX(*y1, c->ir[i].y + c->ir[i].h); }
        ink_inline(c, gen, y0, y1, defer);
    }
}
static void ink_add(Box *c, uint64_t gen, float *y0, float *y1, bool *defer) {
    box_ink(c, gen); *y0 = LMIN(*y0, c->ink0); *y1 = LMAX(*y1, c->ink1); *defer |= c->defer_in;
}
static void box_ink(Box *b, uint64_t gen) {
    if (b->ink_gen == gen) return;
    float y0 = b->y, y1 = b->y + b->h, c0 = y0, c1 = y1; bool defer = false;
    if (b->fmt != FMT_REPLACED && !layout_contents_hidden(b)) {
        const ComputedStyle *s = b->st;
        bool clips = b->scroller && b->node && (s->overflow_x != OV_VISIBLE || s->overflow_y != OV_VISIBLE);
        for (Box *c = b->first; c; c = c->next) {   /* as paint_flow: block children and floats */
            if (c->kind == BX_TEXT || c->kind == BX_BR || c->kind == BX_INLINE) continue;
            if (positioned(c) || makes_layer(c)) { defer = true; continue; }
            if (c->kind == BX_ATOMIC && !c->floated) continue;
            ink_add(c, gen, &c0, &c1, &defer);
        }
        if (b->nfrags) {
            ink_inline(b, gen, &c0, &c1, &defer);
            for (int i = 0; i < b->nfrags; i++) {
                TextFrag *f = &b->frags[i]; Box *fb = f->box;
                if (fb->kind == BX_TEXT) { c0 = LMIN(c0, f->y); c1 = LMAX(c1, f->y + f->h); }
                else if (positioned(fb) || makes_layer(fb)) defer = true;
                else if (!fb->floated) ink_add(fb, gen, &c0, &c1, &defer);
            }
        }
        if (!clips) { y0 = c0; y1 = c1; }
    }
    b->ink0 = y0; b->ink1 = y1; b->defer_in = defer; b->ink_gen = gen;
}
static bool culled(PB *p, Box *c) {
    if (!p->cull || p->affine_source) return false;
    box_ink(c, p->gen);
    if (c->defer_in) return false;
    float y0 = c->ink0 + p->dy - 64, y1 = c->ink1 + p->dy + 64;
    if (y1 < 0 || y0 > p->dl->vh) return true;
    return p->clip && (y1 < p->cy || y0 > p->cy + p->ch);
}

static void paint_inline_decos(PB *p, Box *ib) {
    for (Box *c = ib->first; c; c = c->next) {
        if (c->kind != BX_INLINE || positioned(c) || makes_layer(c)) continue;
        if (c->st->visibility == VIS_VISIBLE) for (int i = 0; i < c->nir; i++) { IRect *r = &c->ir[i]; if (r->w > 0) paint_rect_deco(p, c, r->x + p->dx, r->y + p->dy, r->w, r->h, r->first, r->last); }
        paint_inline_decos(p, c);
    }
}
/* A fragment belongs to the nearest deferred inline/atomic owner, not to
 * every block fragment list that happens to reference it. */
static bool fragment_in_flow(const Box *box, const Box *owner) {
    for (const Box *c = box; c && c != owner; c = c->parent)
        if (positioned(c) || makes_layer(c)) return false;
    return true;
}

bool dl_caret_on;
bool dl_cull = true;

static void paint_caret(PB *p, Box *b) {
    const ComputedStyle *s = b->st;
    float x = b->x + b->b[3] + b->p[3], y = b->y + b->b[0] + b->p[0], h = s->font_size * 1.2f;
    float ch = b->h - b->b[0] - b->b[2] - b->p[0] - b->p[2];
    TextFrag *last = b->nfrags ? &b->frags[b->nfrags - 1] : NULL;
    for (Box *c = b->first; c; c = c->next) if (c->nfrags) last = &c->frags[c->nfrags - 1];
    const Document *d = b->node->doc;
    if (d && b->node == d->csel_n) {   /* at the selection focus; a range shows as a highlight instead */
        float cx, cy, cht;
        if (d->csel[0] != d->csel[1]) return;
        if (ctl_caret(b, d->csel[1], &cx, &cy, &cht)) { DItem *it = emit(p, DO_RECT); it->x = cx + p->dx; it->y = cy + p->dy; it->w = 1; it->h = cht; it->color = s->color; return; }
    }
    if (last) { y = last->y; h = last->h; if (!b->placeholder) x = last->x + last->w; }
    else if (b->ctl == CTL_TEXT && ch > h) y += (ch - h) / 2;
    DItem *it = emit(p, DO_RECT); it->x = x + p->dx; it->y = y + p->dy; it->w = 1; it->h = h; it->color = s->color;
}

static void last_frag_in(Box *b, TextFrag **out, const Box **blk) {
    for (int i = b->nfrags - 1; i >= 0; i--) if (b->frags[i].box->node) { *out = &b->frags[i]; *blk = b; break; }
    for (Box *c = b->first; c; c = c->next) if (!c->abs && c->kind != BX_TEXT && c->kind != BX_INLINE) last_frag_in(c, out, blk);
}

/* contenteditable host: caret after the last text, else at the start of its first (empty) block */
typedef struct { const Node *n; int o; TextFrag *f; float x; bool exact; } CaretAt;
static void caret_find(Box *b, CaretAt *k) {
    for (int i = 0; i < b->nfrags && !k->exact; i++) {
        TextFrag *f = &b->frags[i]; const Box *t = f->box;
        if (t->node != k->n || f->g0 >= f->g1) continue;
        int lo = (int)t->sh.g[f->g0].cluster, hi = f->g1 < t->sh.n ? (int)t->sh.g[f->g1].cluster : t->text_len;
        if (k->o < lo || k->o > hi) continue;
        float x = f->x + f->w;
        for (int g = f->g0; g < f->g1; g++) if ((int)t->sh.g[g].cluster >= k->o) { x = f->x + t->sh.g[g].x - t->sh.g[f->g0].x; break; }
        k->f = f; k->x = x; k->exact = k->o < hi;
    }
    for (Box *c = b->first; c && !k->exact; c = c->next) if (!c->abs) caret_find(c, k);
}

/* contenteditable host: caret at the selection focus, else after the last text, else at the start of its first (empty) block */
static void paint_edit_caret(PB *p, Box *b) {
    TextFrag *f = NULL; const Box *fb = NULL;
    const ComputedStyle *s = b->st;
    float x, y, h;
    const Document *d = b->node->doc; const Box *eb = NULL;
    if (d && d->sel[0] && node_within(d->sel[0], b->node)) {
        if (d->sel[0] != d->sel[1] || d->selo[0] != d->selo[1]) return;   /* a range is shown as a highlight */
        Node *tn; int to;
        if (tsel_dom_point(d->sel[0], d->selo[0], false, &tn, &to)) {
            CaretAt k = { tn, to, NULL, 0, false }; caret_find(b, &k);
            if (k.f) { DItem *it = emit(p, DO_RECT); it->x = k.x + p->dx; it->y = k.f->y + p->dy; it->w = 1; it->h = k.f->h; s = k.f->box->st;
                it->color = COLOR_A(s->caret_color) ? s->caret_color : s->color; return; }
        } else if (d->sel[0]->type == NODE_ELEMENT && d->sel[0]->box) eb = d->sel[0]->box;
    }
    if (!eb) last_frag_in(b, &f, &fb);
    if (f) { x = f->x + f->w; y = f->y; h = f->h; s = f->box->st; }
    else {
        const Box *c = eb ? eb : b; while (c->first && !c->first->abs && c->first->kind == BX_BLOCK) c = c->first;
        s = c->st; h = s->font_size * 1.2f;
        x = c->x + c->b[3] + c->p[3]; y = c->y + c->b[0] + c->p[0];
        float ch = c->h - c->b[0] - c->b[2] - c->p[0] - c->p[2]; if (ch > h) y += (ch - h) / 2;
    }
    DItem *it = emit(p, DO_RECT); it->x = x + p->dx; it->y = y + p->dy; it->w = 1; it->h = h; it->color = COLOR_A(s->caret_color) ? s->caret_color : s->color;
}
static bool is_edit_host(const Node *n) {
    const char *ce = n && n->type == NODE_ELEMENT ? node_attr((Node *)n, "contenteditable") : NULL;
    return ce && strcmp(ce, "false");
}

static void paint_own_deco(PB *p, Box *b) {
    if (b->st->visibility != VIS_VISIBLE || !b->node || b->node == p->L->doc->html) return;
    if (b->kind == BX_INLINE) {
        for (int i = 0; i < b->nir; i++) { IRect *r = &b->ir[i]; if (r->w > 0) paint_rect_deco(p, b, r->x + p->dx, r->y + p->dy, r->w, r->h, r->first, r->last); }
    } else paint_rect_deco(p, b, b->x + p->dx, b->y + p->dy, b->w, b->h, true, true);
}
/* A context's decoration is emitted before its negative descendants; ordinary
 * flow boxes emit their decoration together with their content. */
static void paint_block_content(PB *p, Box *b, bool decorate) {
    const ComputedStyle *s = b->st;
    bool vis = s->visibility == VIS_VISIBLE;
    if (decorate) paint_own_deco(p, b);
    if (layout_contents_hidden(b)) return; /* owner decoration stays; all contents, including replaced pixels, are hidden */
    if (b->fmt == FMT_REPLACED) { if (vis) paint_replaced(p, b); return; }
    bool clips = b->scroller && b->node && (s->overflow_x != OV_VISIBLE || s->overflow_y != OV_VISIBLE);
    PB saved = *p;
    if (clips) {
        float x = b->x + p->dx + b->b[3], y = b->y + p->dy + b->b[0], w = b->w - b->b[1] - b->b[3], h = b->h - b->b[0] - b->b[2];
        DItem *c = emit(p, DO_PUSH_CLIP); c->x = x; c->y = y; c->w = w; c->h = h; c->sc = b;
        if (rounded(s)) {   /* overflow clips to the padding box's rounded corners */
            float outer_x[4], outer_y[4], inner_x[4], inner_y[4];
            radii(b, b->w, b->h, 15u, outer_x, outer_y);
            rounded_radii_inset(outer_x, outer_y, b->b, inner_x, inner_y);
            ditem_set_radii(c, inner_x, inner_y);
        }
        if (p->clip) { float x1 = LMIN(x + w, p->cx + p->cw), y1 = LMIN(y + h, p->cy + p->ch); x = LMAX(x, p->cx); y = LMAX(y, p->cy); w = LMAX(0, x1 - x); h = LMAX(0, y1 - y); }
        p->clip = true; p->cx = x; p->cy = y; p->cw = w; p->ch = h;
        p->dx -= box_scroll_left(b); p->dy -= box_scroll_y(b);
        p->sb = b; p->outer = &saved; p->mv_out = p->mv; p->mv = b;
    }
    if (s->display == D_LIST_ITEM && vis) paint_marker(p, b);
    paint_flow(p, b);
    if (vis && dl_caret_on && (b->ctl == CTL_TEXT || b->ctl == CTL_TEXTAREA) && b->node && (b->node->flags & NF_FOCUS)) paint_caret(p, b);
    else if (vis && dl_caret_on && b->node && (b->node->flags & NF_FOCUS) && is_edit_host(b->node)) paint_edit_caret(p, b);
    if (clips) { int order = p->order; *p = saved; p->order = order; emit(p, DO_POP_CLIP); }
}

static void paint_flow(PB *p, Box *b) {
    /* Positioned and layered descendants were collected before any flow paint. */
    for (Box *c = b->first; c; c = c->next) {
        if (c->kind == BX_TEXT || c->kind == BX_BR || c->kind == BX_INLINE) continue;
        if (positioned(c) || makes_layer(c) || c->floated || c->kind == BX_ATOMIC || culled(p, c)) continue;
        paint_block_content(p, c, true);
    }
    for (Box *c = b->first; c; c = c->next)
        if (c->floated && !positioned(c) && !makes_layer(c) && !culled(p, c)) paint_block_content(p, c, true);
    if (b->nfrags) {
        paint_inline_decos(p, b);
        for (int i = 0; i < b->nfrags; i++) {
            TextFrag *f = &b->frags[i];
            if (!fragment_in_flow(f->box, b)) continue;
            if (f->box->kind == BX_TEXT) paint_text_frag(p, f);
            else if (!f->box->floated && !culled(p, f->box)) paint_block_content(p, f->box, true);
        }
    }
}

/* Collect membership in the nearest real stacking context. Relative/absolute
 * z-index:auto boxes remain zero-level paint entries, while their descendants
 * can participate in this same context. Scroller snapshots live in the display
 * list's frame arena: deferred state never retains a pointer to this call stack. */
static void collect_context(PB *p, Box *b, DefVec *defs) {
    if (b->fmt == FMT_REPLACED || layout_contents_hidden(b) || culled(p, b)) return;
    PB saved = *p;
    const ComputedStyle *s = b->st;
    bool clips = b->scroller && b->node && (s->overflow_x != OV_VISIBLE || s->overflow_y != OV_VISIBLE);
    if (clips) {
        float x = b->x + p->dx + b->b[3], y = b->y + p->dy + b->b[0];
        float w = b->w - b->b[1] - b->b[3], h = b->h - b->b[0] - b->b[2];
        if (p->clip) { float x1 = LMIN(x + w, p->cx + p->cw), y1 = LMIN(y + h, p->cy + p->ch); x = LMAX(x, p->cx); y = LMAX(y, p->cy); w = LMAX(0, x1 - x); h = LMAX(0, y1 - y); }
        PB *outer = arena_alloc(&p->dl->arena, sizeof *outer); *outer = saved;
        p->clip = true; p->cx = x; p->cy = y; p->cw = w; p->ch = h;
        p->dx -= box_scroll_left(b); p->dy -= box_scroll_y(b);
        p->sb = b; p->outer = outer; p->mv_out = p->mv; p->mv = b;
    }
    for (Box *c = b->first; c; c = c->next) {
        if (c->kind == BX_TEXT || c->kind == BX_BR) continue;
        if (positioned(c) || makes_layer(c)) {
            const PB *q = p;
            if (c->abs) while (q->sb && !box_within(c->cb, q->sb)) q = q->outer;
            Deferred d = { .b = c, .state = *q, .order = p->order++ };
            vec_push(*defs, d);
            if (!makes_context(c)) {
                PB child = *q; child.order = p->order;
                collect_context(&child, c, defs);
                p->order = child.order;
            }
        } else collect_context(p, c, defs);
    }
    int order = p->order; *p = saved; p->order = order;
}

static int def_cmp(const void *a, const void *b) {
    const Deferred *x = a, *y = b;
    int zx = stack_level(x->b), zy = stack_level(y->b);
    if (zx != zy) return zx < zy ? -1 : 1;
    return x->order - y->order;
}

/* Find the already-active scroller prefix using the existing snapshot chains.
 * A false clip is an affine boundary: its inherited contours are outside that
 * group's coordinate system. No extra state or ancestor allocation is needed. */
static unsigned deferred_clip_depth(const PB *state) {
    unsigned depth = 0;
    for (; state && state->clip && state->sb && state->outer; state = state->outer) depth++;
    return depth;
}
static const Box *deferred_active_clip_prefix(const PB *state, const PB *active) {
    if (!state->clip || !active->clip || !state->sb || !active->sb) return NULL;
    if (state->sb == active->sb) return state->sb;
    unsigned a = deferred_clip_depth(state), b = deferred_clip_depth(active);
    while (a > b) { state = state->outer; a--; }
    while (b > a) { active = active->outer; b--; }
    while (a--) {
        if (state->sb == active->sb) return state->sb;
        state = state->outer; active = active->outer;
    }
    return NULL;
}
/* Deferred descendants keep an aggregate rectangular clip. Re-emit only the
 * rounded padding contours between their state and the active common prefix;
 * contexts must not duplicate contours already enclosing their paint. */
static unsigned paint_deferred_rounded_clips(PB *p, const PB *state, const Box *active) {
    if (!state || !state->clip || !state->sb || !state->outer || state->sb == active) return 0;
    const PB *outer = state->outer;
    unsigned count = paint_deferred_rounded_clips(p, outer, active);
    const Box *b = state->sb;
    if (!b->node || !rounded(b->st)) return count;
    float x[4], y[4], ix[4], iy[4];
    radii(b, b->w, b->h, 15u, x, y);
    rounded_radii_inset(x, y, b->b, ix, iy);
    if (!(ix[0] || ix[1] || ix[2] || ix[3])) return count;
    DItem *c = emit(p, DO_PUSH_CLIP);
    c->x = b->x + outer->dx + b->b[3];
    c->y = b->y + outer->dy + b->b[0];
    c->w = b->w - b->b[1] - b->b[3];
    c->h = b->h - b->b[0] - b->b[2];
    c->sc = b; c->mv = outer->mv;
    c->fixed = outer->fixed; c->sticky = outer->sticky;
    ditem_set_radii(c, ix, iy);
    return count + 1;
}

static void paint_deferred(PB *p, Deferred *d) {
    PB saved = *p;
    *p = d->state; p->order = saved.order;
    if (box_fixed_to_viewport(d->b)) {
        p->dx = -0.0f; p->dy = 0; p->clip = false; p->fixed = true; p->sticky = false;
        p->mv = p->mv_out = NULL; p->sb = NULL; p->outer = NULL;
    } else if (d->b->abs && d->b->cb == p->L->root) p->clip = false;
    bool clipped = p->clip;
    if (clipped) { DItem *c = emit(p, DO_PUSH_CLIP); c->x = p->cx; c->y = p->cy; c->w = p->cw; c->h = p->ch; }
    const Box *active = clipped ? deferred_active_clip_prefix(p, &saved) : NULL;
    unsigned rounded_clips = clipped ? paint_deferred_rounded_clips(p, p, active) : 0;
    paint_stacking(p, d->b, makes_context(d->b));
    for (unsigned i = 0; i < rounded_clips; i++) emit(p, DO_POP_CLIP);
    if (clipped) emit(p, DO_POP_CLIP);
    int order = p->order; *p = saved; p->order = order;
}

/* Keep ordinary scale text as actual primitives: uniform text uses a resized
 * face, while nonuniform glyphs carry one real affine source item. This path
 * is deliberately limited to a complete, simple text/rectangle group. Clip,
 * opacity, nesting, moving/fixed content and every other paint operation keep
 * the general group compositor. Preflight and stage before changing items. */
static bool paint_flat_scale(PB *p, int start, Affine2D matrix) {
    if (matrix.b || matrix.c || !(matrix.a > 0) || !(matrix.d > 0)) return false;
    int count = p->dl->items.n - start;
    bool uniform = matrix.a == matrix.d, text = false;
    for (int i = start; i < p->dl->items.n; i++) {
        const DItem *it = &p->dl->items.v[i];
        if ((it->op != DO_RECT && it->op != DO_TEXT) || it->transform ||
            it->fixed || it->sticky || it->mv || it->sc) return false;
        if (it->op == DO_RECT) {
            if (it->r[0] || it->r[1] || it->r[2] || it->r[3] || it->tile.w || it->tile.h) return false;
        } else {
            if (!it->g || it->ng <= 0) return false;
            text = true;
            for (int k = 0; k < it->ng; k++) {
                const DGlyph *g = &it->g[k];
                AffinePoint point = affine_point(matrix, g->x, g->y);
                if (!isfinite(point.x) || !isfinite(point.y) || fabs(point.x) > FLT_MAX || fabs(point.y) > FLT_MAX) return false;
                if (uniform && g->font) {
                    double size = (double)g->font->size * matrix.a;
                    /* Larger/tiny faces remain bounded by the inverse-window
                       compositor instead of creating a huge cached font. */
                    if (!(size >= .25 && size <= 512)) return false;
                }
            }
        }
        double source[4] = {it->x, it->y, (double)it->x + it->w, (double)it->y + it->h}, bounds[4];
        if (!affine_bounds(matrix, source, bounds)) return false;
        for (int k = 0; k < 4; k++) if (fabs(bounds[k]) > FLT_MAX) return false;
        if (bounds[2] - bounds[0] > FLT_MAX || bounds[3] - bounds[1] > FLT_MAX) return false;
    }
    if (!text) return false; /* Preserve rectangle-only adaptive group paths. */
    DItem *staged = arena_alloc(&p->dl->arena, (size_t)count * sizeof *staged);
    memcpy(staged, p->dl->items.v + start, (size_t)count * sizeof *staged);
    for (int i = 0; i < count; i++) {
        DItem *it = &staged[i];
        if (it->op == DO_TEXT && !uniform) {
            DTransform *source = arena_alloc(&p->dl->arena, sizeof *source);
            memset(source, 0, sizeof *source); source->matrix = matrix; source->count = 1;
            source->items = arena_alloc(&p->dl->arena, sizeof *source->items);
            source->items[0] = *it;
            it->transform = source;
            /* Glyphs are the immutable source of this actual draw command.
               Ink/damage/raster use the same payload before the opcode. */
            continue;
        }
        if (it->op == DO_TEXT) {
            DGlyph *glyphs = arena_alloc(&p->dl->arena, (size_t)it->ng * sizeof *glyphs);
            memcpy(glyphs, it->g, (size_t)it->ng * sizeof *glyphs); it->g = glyphs;
            Font *from = NULL, *to = NULL;
            for (int k = 0; k < it->ng; k++) {
                DGlyph *g = &glyphs[k]; AffinePoint point = affine_point(matrix, g->x, g->y);
                g->x = (float)point.x; g->y = (float)point.y;
                if (g->font && g->font != from) {
                    from = g->font; to = font_resized(from, (float)(round((double)from->size * matrix.a * 4) / 4));
                    if (!to) return false;
                }
                if (g->font) g->font = to;
            }
            it->precise_text_ink = true;
        }
        AffinePoint point = affine_point(matrix, it->x, it->y);
        it->x = (float)point.x; it->y = (float)point.y;
        it->w = (float)((double)it->w * matrix.a); it->h = (float)((double)it->h * matrix.d);
    }
    memcpy(p->dl->items.v + start, staged, (size_t)count * sizeof *staged);
    return true;
}

/* Collapse a complete subtree into one paint group. No bitmap is allocated
 * here; the rasterizer later inverse-maps only actual destination damage. */
static void paint_affine_group(PB *p, int start, Affine2D matrix) {
    int count = p->dl->items.n - start;
    if (!count) return;
    Affine2D inverse;
    if (!affine_inverse(matrix, &inverse)) { p->dl->items.n = start; return; }
    if (paint_flat_scale(p, start, matrix)) return;
    bool fixed_child = false; int depth = 0, maximum = 0;
    for (int i = start; i < p->dl->items.n; i++) {
        const DItem *it = &p->dl->items.v[i];
        fixed_child |= it->fixed;
        if (it->op == DO_PUSH_LAYER) { depth++; maximum = LMAX(maximum, depth); }
        else if (it->op == DO_POP_LAYER && depth) depth--;
    }
    DTransform *group = arena_alloc(&p->dl->arena, sizeof *group);
    memset(group, 0, sizeof *group); group->matrix = matrix;
    group->count = count; group->opacity_depth = LMIN(maximum, 16);
    group->items = arena_alloc(&p->dl->arena, (size_t)count * sizeof *group->items);
    memcpy(group->items, p->dl->items.v + start, (size_t)count * sizeof *group->items);
    p->dl->items.n = start;
    DItem *item = emit(p, DO_TRANSFORM); item->transform = group;
    /* Keep even currently empty glyph groups: a different actual canvas
       scale can have ink. dl_prepare_ink fills the cache after construction. */
    /* A sticky/fixed child can move within the atomic group. Conservatively
       damage its whole transformed ink instead of pretending it scrolls as a
       single ordinary rectangle. A real fixed outer group remains fixed. */
    if (fixed_child && !item->fixed) { item->fixed = true; item->sticky = true; }
}

static void paint_stacking(PB *p, Box *b, bool context) {
    const ComputedStyle *s = b->st;
    if (s->opacity <= 0.001f) return;
    Affine2D matrix = box_transform_matrix(b);
    if (!affine_finite(matrix)) return;
    bool affine = s->has_transform && (matrix.a != 1 || matrix.b != 0 || matrix.c != 0 || matrix.d != 1);
    float tx = affine ? 0 : affine_float(matrix.e), ty = affine ? 0 : affine_float(matrix.f);
    float sticky_x, sticky_y; box_sticky_offset(b, p->sx, p->sy, &sticky_x, &sticky_y);
    tx += sticky_x; ty += sticky_y;
    bool was_fixed = p->fixed, was_sticky = p->sticky; const Box *was_mv = p->mv;
    if (s->position == P_STICKY) {   /* include in scroll damage; it stays put with the page only while stuck to the viewport */
        bool still = (was_fixed && !was_sticky) || ((sticky_x || sticky_y) && !p->mv);
        p->fixed = true; p->sticky = !still; p->mv = p->mv_out;
    }
    p->dx += tx; p->dy += ty;
    bool old_affine_source = p->affine_source, old_clip = p->clip;
    if (affine) {
        /* Child commands use the already translated document frame. CSS's
           matrix must be conjugated into that same frame exactly once. */
        matrix = affine_conjugate_translation(matrix, p->dx, p->dy);
        p->affine_source = true;
        p->clip = false; /* inherited clip was emitted by paint_deferred */
    }
    int i0 = p->dl->items.n;
    bool layer = s->opacity < 0.999f;
    if (layer) { DItem *l = emit(p, DO_PUSH_LAYER); l->alpha = s->opacity; }
    DefVec defs = {0};
    if (context) collect_context(p, b, &defs);
    if (defs.n > 1) qsort(defs.v, (size_t)defs.n, sizeof(Deferred), def_cmp);
    paint_own_deco(p, b);
    int first_nonnegative = 0;
    while (first_nonnegative < defs.n && stack_level(defs.v[first_nonnegative].b) < 0)
        paint_deferred(p, &defs.v[first_nonnegative++]);
    if (b->kind == BX_INLINE) {
        paint_inline_decos(p, b);
        /* Inline owners share their block's fragment list, but nested deferred
         * owners paint their own fragments in their context phase. */
        Box *blk = b->parent; while (blk && blk->kind == BX_INLINE) blk = blk->parent;
        if (blk) for (int i = 0; i < blk->nfrags; i++) {
            TextFrag *f = &blk->frags[i]; Box *o = f->box;
            while (o && o != b && o != blk) o = o->parent;
            if (o == b && fragment_in_flow(f->box, b)) {
                if (f->box->kind == BX_TEXT) paint_text_frag(p, f);
                else if (!f->box->floated) paint_block_content(p, f->box, true);
            }
        }
    } else paint_block_content(p, b, false);
    for (int i = first_nonnegative; i < defs.n; i++) paint_deferred(p, &defs.v[i]);
    vec_free(defs);
    if (layer) emit(p, DO_POP_LAYER);
    if (affine) paint_affine_group(p, i0, matrix);
    p->affine_source = old_affine_source; p->clip = old_clip;
    p->dx -= tx; p->dy -= ty;
    p->fixed = was_fixed; p->sticky = was_sticky; p->mv = was_mv;
}

static void prepare_affine_ink(DItem *item, float scale) {
    DTransform *group = item->transform;
    if (!group) {
        if (item->op == DO_TEXT && item->precise_text_ink) {
            double ink[4];
            if (paint_item_bounds(item, scale, ink)) {
                item->x = affine_float(ink[0]); item->y = affine_float(ink[1]);
                item->w = affine_float(ink[2] - ink[0]); item->h = affine_float(ink[3] - ink[1]);
            } else item->x = item->y = item->w = item->h = 0;
        }
        return;
    }
    for (int i = 0; i < group->count; i++) prepare_affine_ink(&group->items[i], scale);
    double source[4], bounds[4];
    group->ink_valid = paint_transform_ink(group, scale, source, bounds);
    group->ink_scale = scale;
    memcpy(group->source, source, sizeof source); memcpy(group->bounds, bounds, sizeof bounds);
    item->x = affine_float(bounds[0]); item->y = affine_float(bounds[1]);
    item->w = affine_float(bounds[2] - bounds[0]); item->h = affine_float(bounds[3] - bounds[1]);
}

void dl_prepare_ink(DisplayList *dl, float scale) {
    if (!(scale > 0) || !isfinite(scale)) scale = 1;
    for (int i = 0; i < dl->items.n; i++) prepare_affine_ink(&dl->items.v[i], scale);
    dl->fixed.count = 0;
    for (int i = dl->fixed_first; i < dl->items.n; i++) {
        const DItem *it = &dl->items.v[i]; double ink[4];
        if (!it->fixed || !paint_item_bounds(it, scale, ink)) continue;
        float bounds[4]; for (int k = 0; k < 4; k++) bounds[k] = affine_float(ink[k]);
        paint_fixed_add(&dl->fixed, bounds);
    }
}

void dl_clear(DisplayList *dl) { dl->items.n = 0; dl->fixed.count = 0; dl->fixed_first = 0; arena_reset(&dl->arena); }

void dl_build(DisplayList *dl, Layout *L, float scroll_x, float scroll_y, float vw, float vh) {
    dl_clear(dl); dl->vw = vw; dl->vh = vh;
    if (L == g_tsel.L || (L->doc && L->doc->csel_n)) memset(g_tsel_caret, 0, sizeof g_tsel_caret);
    if (!L->root) return;
    tsel_prepare(L);
    PB p; memset(&p, 0, sizeof p); p.dl = dl; p.L = L; p.dx = -scroll_x; p.dy = -scroll_y; p.sx = scroll_x; p.sy = scroll_y;
    p.cull = dl_cull; p.gen = doc_box_generation() + 1;
    /* canvas background propagates from html, else body */
    Node *html = L->doc->html, *body = L->doc->body;
    Color bg = 0;
    if (html && html->style && COLOR_A(html->style->bg_color)) bg = html->style->bg_color;
    else if (body && body->style && COLOR_A(body->style->bg_color)) { bg = body->style->bg_color; p.canvas_color_owner = body; }
    /* the canvas fills the viewport wherever the page is scrolled: fixed for scroll signatures, not a fixed region */
    if (bg) { DItem *it = emit(&p, DO_RECT); it->x = 0; it->y = 0; it->w = vw; it->h = vh; it->color = bg; it->fixed = true; }
    for (Box *c = L->root->first; c; c = c->next) paint_stacking(&p, c, true);
    dl->fixed_first = bg ? 1 : 0;
    dl_prepare_ink(dl, L->dpr);
}
