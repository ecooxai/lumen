# Restore candidate 214 source and Git history

Run this from the extracted archive directory. Git is the only required tool; the bundle contains its complete public ancestry and requires no network access.

```sh
git clone --branch gpt-6-astra-pro-builtin-integration-source214-20261030 PUBLIC-HISTORY.bundle lumen-source
git -C lumen-source rev-parse HEAD
git -C lumen-source rev-parse 'HEAD^{tree}'
```

Expected commit: `5c0e775cfad2084ab5b8107837fe98275d54b35e`.

Expected tracked tree: `09082da1bc88eaabd0622b12f9488d7df528a60f`.

A fresh offline clone was checked against every tracked path, Git blob ID and executable mode before this archive was created. The three archive-only files PUBLIC-HISTORY.bundle, RESTORE-GIT.md and ARCHIVE-PROVENANCE.json are additive packaging metadata and are intentionally absent from that tracked tree. SOURCE-MANIFEST.json and EXPORT-QUALIFICATION.json map the reviewed exported source to the original working commit and state the validation limitations.
