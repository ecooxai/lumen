const timeRanges = (r) => ({ length: r.length, start(i) { return r[i][0]; }, end(i) { return r[i][1]; } });
const mediaEls = new SSet();
const mediaFire = (el, t) => el.dispatchEvent(new Event(t));
const mediaLater = (el, t) => setTimeout(() => mediaFire(el, t), 0);
const mediaRanges = (flat) => { const r = []; for (let i = 0; i + 1 < flat.length; i += 2) r.push([flat[i], flat[i + 1]]); return new TimeRanges(r); };
function mediaPoll() {
    for (const el of mediaEls) {
        if (!el.__mp) { mediaEls.delete(el); continue; }
        const s = N.mediaState(el.__mp); if (!s) continue;
        const [ready, , ended, seeking, waiting, error, time, duration, w, h, msg] = s;
        const o = el.__st || { ready: 0, ended: false, seeking: false, waiting: false, error: false, duration: NaN, w: 0, h: 0, tu: -1 };
        const n = { ready, ended, seeking, waiting, error, duration, w, h, tu: o.tu };
        def(el, '__st', n);
        const playing = el.__paused === false;
        if (error && !o.error) { def(el, '__err', new MediaError(msg === 'network error' ? 2 : 3, msg || '')); mediaFire(el, 'error'); continue; }
        if (!(Number.isNaN(duration) && Number.isNaN(o.duration)) && duration !== o.duration) mediaFire(el, 'durationchange');
        if (ready >= 1 && o.ready < 1) mediaFire(el, 'loadedmetadata');
        if ((w !== o.w || h !== o.h) && ready >= 1) mediaFire(el, 'resize');
        if (ready >= 2 && o.ready < 2) mediaFire(el, 'loadeddata');
        if (ready >= 3 && o.ready < 3) { mediaFire(el, 'canplay'); if (playing) mediaFire(el, 'playing'); }
        if (ready >= 4 && o.ready < 4) mediaFire(el, 'canplaythrough');
        if (waiting && !o.waiting) mediaFire(el, 'waiting');
        if (!waiting && o.waiting && playing) mediaFire(el, 'playing');
        if (!seeking && o.seeking) { n.tu = time; mediaFire(el, 'timeupdate'); mediaFire(el, 'seeked'); }
        if (playing && !seeking && Math.abs(time - n.tu) >= 0.25) { n.tu = time; mediaFire(el, 'timeupdate'); }
        if (ended && !o.ended) {
            if (el.loop) { N.mediaSeek(el.__mp, 0); N.mediaPlay(el.__mp); continue; }
            def(el, '__paused', true); mediaFire(el, 'timeupdate'); mediaFire(el, 'pause'); mediaFire(el, 'ended');
        }
    }
    if (!mediaEls.size) N.mediaPump(null);
    for (const el of mediaEls) if (el.__paused === false) return true;
    return false;
}
function mediaDetach(el) {
    const frames = videoFrameStates.get(el);
    if (frames && el.__mp) { const q = N.videoQuality(el); frames.offset += q[0] - q[1]; }
    if (el.__mp) { N.mediaFree(el.__mp); def(el, '__mp', 0); }
    mediaEls.delete(el);
    if (!mediaEls.size) N.mediaPump(null);
    def(el, '__st', null); def(el, '__err', null); def(el, '__src', '');
}
function mediaAttach(el, src) {
    const id = N.mediaNew(el); def(el, '__mp', id);
    mediaEls.add(el); N.mediaPump(mediaPoll);
    N.mediaVolume(id, el.volume, el.muted);
    if (src instanceof MediaSource) { def(el, '__src', ''); src._attach(el, id); }
    else {
        const ms = objectURLs.get(src);
        def(el, '__src', src);
        /* local files only for Lumen's own pages and file: pages, as in Chrome */
        if (ms instanceof MediaSource) ms._attach(el, id);
        else if (ms instanceof Blob) N.mediaOpenBytes(id, ms._buf);   /* the native side cannot fetch a Blob's URL */
        else if (/^file:/i.test(src) && !/^(file|lumen):$/.test(location.protocol)) N.mediaOpen(id, 'about:blank');
        else N.mediaOpen(id, src);
    }
    mediaLater(el, 'loadstart');
}
mk('HTMLMediaElement', HTMLElement, [], p => {
    reflectStr(p, 'crossOrigin', 'preload'); reflectBool(p, 'autoplay', 'loop', 'controls', 'playsInline', 'defaultMuted');
    const st = (el) => el.__mp ? N.mediaState(el.__mp) : null;
    /* a MediaStream (getUserMedia, WebRTC) plays live: its audio tracks go to the output while the element plays (07s-rtc-native.js) */
    const live = (el) => el.__so instanceof MediaStream;
    methods(p, {
        get src() { const v = N.attr(this, 'src'); return v == null ? '' : new URL(v, document.baseURI).href; },
        set src(v) { N.setAttr(this, 'src', String(v)); this.load(); },
        get currentSrc() { return this.__src || ''; },
        get paused() { return this.__paused !== false; },
        get ended() { const s = st(this); return !!(s && s[2]); },
        get seeking() { const s = st(this); return !!(s && s[3]); },
        get readyState() { const s = st(this); if (live(this) && !s) return 4; return s ? s[0] : 0; },
        get networkState() { const s = st(this); return s ? (s[0] >= 4 ? 1 : 2) : (N.attr(this, 'src') != null ? 3 : 0); },
        get error() { return this.__err || null; },
        get duration() { if (live(this)) return Infinity; const s = st(this); return s ? s[7] : NaN; },
        get currentTime() { const s = st(this); return s ? s[6] : (this.__ct || 0); },
        set currentTime(v) {
            v = +v || 0;
            if (!this.__mp) { def(this, '__ct', v); return; }
            N.mediaSeek(this.__mp, v); if (this.__st) this.__st.seeking = true;
            mediaFire(this, 'seeking');
        },
        fastSeek(t) { this.currentTime = t; },
        get volume() { return this.__vol ?? 1; },
        set volume(v) { v = +v; if (!(v >= 0 && v <= 1)) throw new DOMException('volume out of range', 'IndexSizeError'); def(this, '__vol', v); if (this.__mp) N.mediaVolume(this.__mp, v, this.muted); if (live(this)) mediaStreamPlay(this, this.__paused === false); mediaLater(this, 'volumechange'); },
        get muted() { return this.__muted ?? N.attr(this, 'muted') != null; },
        set muted(v) { def(this, '__muted', !!v); if (this.__mp) N.mediaVolume(this.__mp, this.volume, !!v); if (live(this)) mediaStreamPlay(this, this.__paused === false); mediaLater(this, 'volumechange'); },
        get playbackRate() { return this.__rate ?? 1; }, set playbackRate(v) { def(this, '__rate', +v); mediaLater(this, 'ratechange'); },
        get defaultPlaybackRate() { return 1; }, set defaultPlaybackRate(v) {}, get preservesPitch() { return true; }, set preservesPitch(v) {},
        get buffered() { return this.__mp ? mediaRanges(N.mediaBuffered(this.__mp, -1)) : new TimeRanges([]); },
        get played() { return new TimeRanges([]); },
        get seekable() { const d = this.duration; return new TimeRanges(d > 0 && Number.isFinite(d) ? [[0, d]] : []); },
        get textTracks() { return this.__tt || def(this, '__tt', Object.assign([], { addEventListener() {}, removeEventListener() {}, getTrackById() { return null; } })) || this.__tt; },
        get audioTracks() { return Object.assign([], { addEventListener() {}, removeEventListener() {}, getTrackById() { return null; } }); },
        get videoTracks() { return Object.assign([], { addEventListener() {}, removeEventListener() {}, getTrackById() { return null; } }); },
        get srcObject() { return this.__so ?? null; },
        set srcObject(v) {
            if (live(this)) mediaStreamPlay(this, false);
            def(this, '__so', v ?? null); mediaDetach(this); def(this, '__paused', true);
            if (v instanceof MediaSource) mediaAttach(this, v);
            else if (live(this)) {
                /* a native live source (camera, screen) is shown by a live player, whose state fires the load events */
                const vt = this.localName === 'video' && v.getVideoTracks().find(t => t._.hub && t._.hub.src > 0);
                if (vt) {
                    const id = N.mediaNew(this); def(this, '__mp', id); mediaEls.add(this); N.mediaPump(mediaPoll);
                    N.mediaLive(id, vt._.hub.src); mediaLater(this, 'loadstart');
                } else for (const t of ['loadstart', 'durationchange', 'loadedmetadata', 'loadeddata', 'canplay', 'canplaythrough']) mediaLater(this, t);
                if (this.autoplay) this.play();
            }
        },
        load() {
            const was = !!this.__mp;
            mediaDetach(this);
            if (was || this.__paused === false) { def(this, '__paused', true); mediaLater(this, 'emptied'); }
            let src = N.attr(this, 'src');
            if (src == null) { const s = this.querySelector('source[src]'); src = s && s.getAttribute('src'); }
            if (src == null || src === '') return;
            mediaAttach(this, new URL(src, document.baseURI).href);
            if (this.__ct) { N.mediaSeek(this.__mp, this.__ct); def(this, '__ct', 0); }
        },
        play() {
            if (live(this)) {
                if (this.__paused !== false) { def(this, '__paused', false); mediaLater(this, 'play'); if (!this.__mp || this.readyState >= 3) mediaLater(this, 'playing'); }
                if (this.__mp) N.mediaPlay(this.__mp);
                mediaStreamPlay(this, true);
                return Promise.resolve();
            }
            if (!this.__mp) this.load();
            if (!this.__mp) return Promise.reject(new DOMException('The element has no supported sources.', 'NotSupportedError'));
            if (this.__err) return Promise.reject(new DOMException(this.__err.message || 'playback error', 'NotSupportedError'));
            if (this.__paused !== false) { def(this, '__paused', false); mediaLater(this, 'play'); if (this.readyState >= 3) mediaLater(this, 'playing'); }
            N.mediaPlay(this.__mp);
            return Promise.resolve();
        },
        pause() {
            if (this.__mp) N.mediaPause(this.__mp);
            if (live(this)) mediaStreamPlay(this, false);
            if (this.__paused === false) { def(this, '__paused', true); mediaLater(this, 'timeupdate'); mediaLater(this, 'pause'); }
        },
        canPlayType(t) { return ['', 'maybe', 'probably'][N.mediaCanPlay(String(t), false)] || ''; },
        addTextTrack() { return { mode: 'disabled', cues: [], addCue() {}, removeCue() {} }; }, setSinkId() { return Promise.resolve(); },
    });
});
Object.assign(H.HTMLMediaElement, { NETWORK_EMPTY: 0, NETWORK_IDLE: 1, NETWORK_LOADING: 2, NETWORK_NO_SOURCE: 3, HAVE_NOTHING: 0, HAVE_METADATA: 1, HAVE_CURRENT_DATA: 2, HAVE_FUTURE_DATA: 3, HAVE_ENOUGH_DATA: 4 });
// A pending callback keeps its element alive, but completed registrations do
// not. The native pump runs before RAF, only after a new presentation (or arm).
const videoFrameStates = new WeakMap(), videoFramePending = new SSet();
let videoFrameId = 0;
function videoFramePoll(now) {
    const frames = [];
    for (const el of videoFramePending) {
        const state = videoFrameStates.get(el), frame = N.videoFrameInfo(el, state.last);
        if (!frame) continue;
        state.last = frame[0];
        frames.push({el, state, frame, callbacks:Array.from(state.callbacks)});
    }
    for (const {el, state, frame, callbacks} of frames) {
        const metadata = {presentationTime:frame[2], expectedDisplayTime:Math.max(now,frame[2]),
            width:frame[3], height:frame[4], mediaTime:frame[1], presentedFrames:state.offset+frame[5]};
        for (const [id, fn] of callbacks) {
            if (!state.callbacks.delete(id)) continue; // canceled by an earlier callback
            try { fn(now, metadata); } catch (e) { report(e); }
        }
        if (!state.callbacks.size) videoFramePending.delete(el);
    }
    if (!videoFramePending.size) N.videoFramePump(null);
}
mk('HTMLVideoElement', H.HTMLMediaElement, ['video'], p => {
    reflectUrl(p, 'poster'); reflectInt(p, 0, 'width', 'height');
    methods(p, {
        get videoWidth() { return this.__mp ? N.mediaState(this.__mp)[8] : 0; },
        get videoHeight() { return this.__mp ? N.mediaState(this.__mp)[9] : 0; },
        getVideoPlaybackQuality() {
            const q = N.videoQuality(this), result = {};
            for (const [key,value] of [['totalVideoFrames',q[0]],['droppedVideoFrames',q[1]],['creationTime',N.now()]])
                Object.defineProperty(result, key, {value,enumerable:true});
            return result;
        },
        requestVideoFrameCallback(fn) {
            const current = N.videoFrameInfo(this, 0); // native video-element brand check
            if (typeof fn !== 'function') throw new TypeError('Callback must be a function');
            let state = videoFrameStates.get(this);
            if (!state) { state = {last:0, offset:0, callbacks:new SMap()}; videoFrameStates.set(this,state); }
            // A registration after an idle gap must not receive an old frame.
            if (!state.callbacks.size && current) state.last = current[0];
            const id = videoFrameId = ((videoFrameId + 1) >>> 0) || 1;
            state.callbacks.set(id,fn); videoFramePending.add(this);
            N.videoFramePump(videoFramePoll);
            return id;
        },
        cancelVideoFrameCallback(id) {
            N.videoFrameInfo(this, 0);
            const state = videoFrameStates.get(this);
            if (state) { state.callbacks.delete(Number(id) >>> 0); if (!state.callbacks.size) videoFramePending.delete(this); }
            if (!videoFramePending.size) N.videoFramePump(null);
        }
    });
});
mk('HTMLAudioElement', H.HTMLMediaElement, ['audio']);
function Image(w, h) { const e = document.createElement('img'); if (w !== undefined) e.width = w; if (h !== undefined) e.height = h; return e; }
Image.prototype = H.HTMLImageElement.prototype;
function Audio(src) { const e = document.createElement('audio'); if (src !== undefined) e.src = src; return e; }
Audio.prototype = H.HTMLAudioElement.prototype;
function Option(text = '', value, ds, sel) { const o = document.createElement('option'); o.text = text; if (value !== undefined) o.value = value; if (ds) o.setAttribute('selected', ''); if (sel) o.selected = true; return o; }
Option.prototype = H.HTMLOptionElement.prototype;
function urlParts(p, attr) {
    const get = (el) => { const v = N.attr(el, attr); if (v == null) return null; const r = N.urlParse(v, document.baseURI, docEnc(el)); return r ? new URL(r[0]) : null; };
    acc(p, attr, function () { const u = get(this); return u ? u.href : (N.attr(this, attr) ?? ''); }, function (v) { this.setAttribute(attr, v); });
    // HTMLHyperlinkElementUtils: an unparsable URL reads as protocol ':' and '' elsewhere, and its setters do nothing
    for (const k of ['protocol', 'host', 'hostname', 'port', 'pathname', 'search', 'hash', 'username', 'password']) acc(p, k, function () { const u = get(this); return u ? u[k] : k === 'protocol' ? ':' : ''; }, function (v) { const u = get(this); if (u) { u[k] = v; this.setAttribute(attr, u.href); } });
    acc(p, 'origin', function () { const u = get(this); return u ? u.origin : ''; });
    def(p, 'toString', function () { return this[attr]; });
}
const PLAIN = new SSet('abbr address article aside b bdi bdo cite code dd dfn dt em figcaption figure footer header hgroup i kbd main mark nav noscript rp rt ruby s samp search section small strong sub summary sup u var wbr center nobr big tt acronym strike font marquee'.split(' '));
function protoFor(type, tag, ns) {
    switch (type) {
    case 1:
        if (ns === 3) return Element.prototype;
        if (ns === 1) return svgProto(tag);
        if (ns === 2) return MathMLElement.prototype;
        if (TAGS[tag]) return TAGS[tag].prototype;
        return PLAIN.has(tag) || tag.includes('-') ? HTMLElement.prototype : H.HTMLUnknownElement.prototype;
    case 3: return Text.prototype;
    case 4: return CDATASection.prototype;
    case 8: return Comment.prototype;
    case 7: return ProcessingInstruction.prototype;
    case 9: return tag === '#document' ? Document.prototype : ns === 3 ? XMLDocument.prototype : HTMLDocument.prototype;
    case 10: return DocumentType.prototype;
    case 11: return tag === '#shadow' ? ShadowRoot.prototype : DocumentFragment.prototype;
    }
    return Node.prototype;
}

const registry = { byName: new SMap(), byCtor: new SMap(), waiting: new SMap() };
const validCEName = (n) => /^[a-z][^\0\t\n\f\r />A-Z]*$/.test(n) && n.includes('-') && !/^(annotation-xml|color-profile|font-face|font-face-src|font-face-format|font-face-name|missing-glyph)$/.test(n);
const ceFailed = new WeakSet(), ceUpgrading = new WeakSet(), ceParserCounters = new WeakMap();
let ceReactionQueue = null;
function ceReaction(el, callback, args) {
    if (typeof callback !== 'function') return;
    if (ceReactionQueue) { ceReactionQueue.push({el, callback, args}); return; }
    try { callback.apply(el, args); } catch (e) { report(e); }
}
function ceInvoke(queue) {
    const previous = ceReactionQueue;
    ceReactionQueue = null;
    try {
        for (let i = 0; i < queue.length; ++i) {
            const r = queue[i];
            if (!ceFailed.has(r.el)) ceReaction(r.el, r.callback, r.args);
        }
    } finally { ceReactionQueue = previous; }
}
function ceDefinition(name, is) {
    const autonomous = registry.byName.get(name);
    if (autonomous && autonomous.ext === undefined) return autonomous;
    const customized = is === null ? undefined : registry.byName.get(is);
    return customized && customized.ext === name ? customized : undefined;
}
function ceConstruct(nt, active) {
    if (nt === active) illegal();
    const d = registry.byCtor.get(nt);
    if (!d) illegal();
    const expected = d.ext === undefined ? HTMLElement : TAGS[d.ext] || HTMLElement;
    if (active !== expected) throw new TypeError('The custom element does not extend the interface for its local name.');
    /* Registration and interface checks precede the observable prototype get. */
    let prototype = nt.prototype;
    if (prototype === null || (typeof prototype !== 'object' && typeof prototype !== 'function')) prototype = active.prototype;
    if (d.stack.length) {
        const entry = d.stack[d.stack.length - 1];
        if (entry.constructed) throw new TypeError('The custom element has already been constructed.');
        entry.constructed = true;
        Object.setPrototypeOf(entry.element, prototype);
        return entry.element;
    }
    const el = N.create(d.ext === undefined ? d.name : d.ext, 0);
    if (d.ext !== undefined) N.ceIs(el, d.name);
    Object.setPrototypeOf(el, prototype);
    def(el, '__ce', d);
    return el;
}
function ceUpgradeTree(root) {
    if (!registry.byName.size) return;
    const t = N.type(root);
    if (t !== 1 && t !== 11) return;
    for (const el of N.ceScan(root)) if (!el.__ce) ceUpgrade(el);
}
function ceParserMarkupGuard(doc) {
    if (ceParserCounters.get(doc)) throw new DOMException('Dynamic markup insertion is unavailable while a parser-created custom element is being constructed.', 'InvalidStateError');
}
function ceUpgrade(el, forceRegistry = false) {
    if (el.__ce || ceFailed.has(el) || N.type(el) !== 1 || N.ns(el) !== 0) return;
    if (!forceRegistry && N.ownerDoc(el) !== document) return;
    const d = ceDefinition(N.name(el), N.ceIs(el)); if (!d) return;
    const queue = [], previous = ceReactionQueue;
    ceReactionQueue = queue;
    def(el, '__ce', d);
    if (d.observed.length) {
        const attributes = N.attrs(el);
        for (let i = 0; i < attributes.length; i += 2)
            if (d.observed.includes(attributes[i])) ceReaction(el, d.attributeChanged, [attributes[i], null, attributes[i + 1], null]);
    }
    if (N.connected(el)) ceReaction(el, d.connected, []);
    const entry = {element:el, constructed:false};
    d.stack.push(entry); ceUpgrading.add(el);
    try {
        if (new d.ctor() !== el) throw new TypeError('A custom element upgrade must return the element being upgraded.');
    } catch (e) {
        ceFailed.add(el); queue.length = 0; report(e);
    } finally {
        ceUpgrading.delete(el); d.stack.pop(); ceReactionQueue = previous;
    }
    if (ceFailed.has(el)) return;
    ceInvoke(queue);
}
/* A creation dictionary's is member is creation state, never a content
   attribute. The legacy string overload is intentionally ignored. */
function ceIsOption(options) {
    if (options === null || (typeof options !== 'object' && typeof options !== 'function')) return null;
    const value = options.is;
    if (value === undefined) return null;
    if (typeof value === 'symbol') throw new TypeError('Cannot convert a Symbol value to a string');
    return String(value);
}
function ceCreateElement(name, namespace, doc, is = null, prefix = null) {
    const d = namespace === 0 && doc === document ? ceDefinition(name, is) : undefined;
    let el;
    if (d && d.ext === undefined) {
        try {
            el = new d.ctor();
            if (!N.isNode(el) || N.type(el) !== 1 || N.ns(el) !== 0)
                throw new TypeError('A custom element constructor must return an HTMLElement.');
            if (N.attrs(el).length || N.first(el) || N.parent(el) || N.ownerDoc(el) !== doc || N.name(el) !== name)
                throw new DOMException('The constructed custom element has unexpected attributes, children, parent, document, or local name.', 'NotSupportedError');
            N.ceIs(el, null);
        } catch (e) {
            report(e);
            el = N.create(name, 0, doc);
            Object.setPrototypeOf(el, H.HTMLUnknownElement.prototype);
            ceFailed.add(el);
        }
        /* Fresh autonomous construction starts with a null prefix. Apply the
           requested prefix only to the successfully returned/fallback node. */
        N.xname(el, null, prefix, null);
        if (prefix !== null || el.__pfx !== undefined) def(el, '__pfx', prefix);
        return el;
    }
    el = N.create(name, namespace, doc);
    if (is !== null) N.ceIs(el, is);
    if (namespace === 0 && prefix !== null) { N.xname(el, null, prefix, null); def(el, '__pfx', prefix); }
    if (d) ceUpgrade(el);
    return el;
}
/* Called only from the suspended native document parser. The provisional C
   node remains private until this constructor and attribute-reaction phase
   finishes; a constructor's returned element can replace that provisional node. */
function ceParserCreate(name, is, doc, attributes) {
    if (doc !== document) return null;
    const d = ceDefinition(name, is); if (!d) return null;
    const depth = ceParserCounters.get(doc) || 0;
    ceParserCounters.set(doc, depth + 1);
    const previous = ceReactionQueue, queue = [];
    ceReactionQueue = queue;
    let el;
    try {
        el = ceCreateElement(name, 0, doc, is);
        for (let i = 0; i < attributes.length; ++i) attrSetQ(el, attributes[i][0], attributes[i][1]);
        ceReactionQueue = previous;
        ceInvoke(queue);
        return el;
    } finally {
        ceReactionQueue = previous;
        if (depth) ceParserCounters.set(doc, depth); else ceParserCounters.delete(doc);
    }
}
function ceParserInserted(el, parent, previousSibling, nextSibling) {
    if (liveRanges.size) rangeInserted(parent, idxOf(el), 1);
    notify('childList', parent, {addedNodes:[el], previousSibling, nextSibling});
    ceConnected(el, true);
}
function ceConnected(root, connected, moved) {
    if (!registry.byName.size) return;
    const t = N.type(root); if (t !== 1 && t !== 11) return;
    for (const el of N.ceScan(root)) {
        if (ceFailed.has(el) || ceUpgrading.has(el)) continue;
        if (!el.__ce) { if (!moved && N.connected(el)) ceUpgrade(el); continue; }
        if (!moved && connected !== N.connected(el)) continue;
        ceReaction(el, connected ? el.__ce.connected : el.__ce.disconnected, []);
    }
}
function ceMoved(root) {
    if (!registry.byName.size) return;
    const t = N.type(root); if (t !== 1 && t !== 11) return;
    for (const el of N.ceScan(root)) {
        if (!el.__ce || ceFailed.has(el)) continue;
        const run = cb => { if (typeof cb === 'function') { try { cb.call(el); } catch (e) { report(e); } } };
        if (typeof el.connectedMoveCallback === 'function') run(el.connectedMoveCallback);
        else { run(el.disconnectedCallback); run(el.connectedCallback); }
    }
}
function ceAttr(el, name, old, v, ns = null) {
    if (name === 'type' && ns === null && old !== v && oprOf.has(el)) oprDisconnectAll(el);
    if (ns === null && N.ns(el) === 0) { formAttr(el, name, old, v); if (name === 'popover') popAttrChanged(el, old, v); }
    const d = el.__ce; if (!d || ceFailed.has(el) || !d.observed.includes(name)) return;
    ceReaction(el, d.attributeChanged, [name, old, v, ns]);
}
class CustomElementRegistry {
    define(name, ctor, opts) {
        name = String(name);
        if (typeof ctor !== 'function') throw new TypeError("Failed to execute 'define': The provided value is not a constructor");
        if (!validCEName(name)) throw new DOMException(`"${name}" is not a valid custom element name`, 'SyntaxError');
        if (registry.byName.has(name)) throw new DOMException(`the name "${name}" has already been used with this registry`, 'NotSupportedError');
        if (registry.byCtor.has(ctor)) throw new DOMException('this constructor has already been used with this registry', 'NotSupportedError');
        const prototype = ctor.prototype;
        if (prototype === null || (typeof prototype !== 'object' && typeof prototype !== 'function')) throw new TypeError('The custom element constructor must have an object prototype.');
        const connected = prototype.connectedCallback, disconnected = prototype.disconnectedCallback, attributeChanged = prototype.attributeChangedCallback;
        for (const callback of [connected, disconnected, attributeChanged])
            if (callback !== undefined && typeof callback !== 'function') throw new TypeError('A custom element lifecycle callback must be a function.');
        const oa = attributeChanged === undefined ? undefined : ctor.observedAttributes;
        const extension = opts == null ? undefined : opts.extends;
        const ext = extension === undefined ? undefined : String(extension);
        if (ext !== undefined && (validCEName(ext) || (!TAGS[ext] && !PLAIN.has(ext))))
            throw new DOMException('The extended element must be a supported built-in HTML element.', 'NotSupportedError');
        const d = { name, ctor, observed: oa ? [...oa].map(String) : [], ext, stack:[], connected, disconnected, attributeChanged };
        registry.byName.set(name, d); registry.byCtor.set(ctor, d);
        for (const el of N.query(document, CSS.escape(ext === undefined ? name : ext), true)) ceUpgrade(el);
        const w = registry.waiting.get(name); if (w) { registry.waiting.delete(name); w.resolve(ctor); }
    }
    get(name) { const d = registry.byName.get(String(name)); return d ? d.ctor : undefined; }
    getName(ctor) { const d = registry.byCtor.get(ctor); return d ? d.name : null; }
    whenDefined(name) {
        name = String(name);
        if (!validCEName(name)) return Promise.reject(new DOMException(`"${name}" is not a valid custom element name`, 'SyntaxError'));
        if (registry.byName.has(name)) return Promise.resolve(registry.byName.get(name).ctor);
        let w = registry.waiting.get(name);
        if (!w) { let resolve; const promise = new Promise(r => resolve = r); w = { promise, resolve }; registry.waiting.set(name, w); }
        return w.promise;
    }
    upgrade(root) { for (const el of N.ceScan(root)) ceUpgrade(el, true); }
}
