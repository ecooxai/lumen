# Restore candidate 200 source and Git history

Run this from the extracted archive directory. Git is the only required tool; the bundle contains its complete public ancestry and requires no network access.

```sh
git clone --branch gpt-6-astra-release-ops-linux-nonurl-source-20261029 PUBLIC-HISTORY.bundle lumen-source
git -C lumen-source rev-parse HEAD
git -C lumen-source rev-parse 'HEAD^{tree}'
```

Expected commit: `3b9a6a5fff8b925067a560367cccc00fb8098d67`.

Expected tracked tree: `2e627c25a6a420d1496932c3bbb5a4c84d56d9c7`.

A fresh offline clone was checked against every tracked path, Git blob ID and executable mode before this archive was created. The three archive-only files PUBLIC-HISTORY.bundle, RESTORE-GIT.md and ARCHIVE-PROVENANCE.json are additive packaging metadata and are intentionally absent from that tracked tree. SOURCE-MANIFEST.json and EXPORT-QUALIFICATION.json map the reviewed exported source to the original working commit and state the validation limitations.
