# Restore candidate 205 source and Git history

Run this from the extracted archive directory. Git is the only required tool; the bundle contains its complete public ancestry and requires no network access.

```sh
git clone --branch gpt-6-astra-pro-builtin-integration-source205-20261030 PUBLIC-HISTORY.bundle lumen-source
git -C lumen-source rev-parse HEAD
git -C lumen-source rev-parse 'HEAD^{tree}'
```

Expected commit: `0742c66b2c9b077c68006c9cb1b4413e281c328d`.

Expected tracked tree: `5411322738f6b57eebe0d921ee38114652c58e66`.

A fresh offline clone was checked against every tracked path, Git blob ID and executable mode before this archive was created. The three archive-only files PUBLIC-HISTORY.bundle, RESTORE-GIT.md and ARCHIVE-PROVENANCE.json are additive packaging metadata and are intentionally absent from that tracked tree. SOURCE-MANIFEST.json and EXPORT-QUALIFICATION.json map the reviewed exported source to the original working commit and state the validation limitations.
