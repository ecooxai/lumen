from pathlib import Path
from datetime import datetime,timezone
import base64,hashlib,json,os,stat,subprocess,tempfile,time,urllib.request,zipfile
root=Path.cwd();out=root/'out/10292019r-official-chrome';manifest=json.loads((out/'known-good-versions-with-downloads.json').read_text());version=next(v for v in manifest['versions']if v['version']=='156.0.8078.47');url=next(d['url']for d in version['downloads']['chrome']if d['platform']=='linux64');expected='https://storage.googleapis.com/chrome-for-testing-public/156.0.8078.47/linux64/chrome-linux64.zip';assert url==expected
start=time.monotonic();record={'startedUTC':datetime.now(timezone.utc).isoformat(),'manifestSHA256':hashlib.sha256((out/'known-good-versions-with-downloads.json').read_bytes()).hexdigest(),'url':url,'version':version['version'],'revision':version['revision']};archive=out/'chrome-linux64.zip';temporary=out/'chrome-linux64.zip.download';sha=hashlib.sha256();md5=hashlib.md5();size=0
if archive.exists()or temporary.exists():raise RuntimeError('Preserve existing download')
with urllib.request.urlopen(url,timeout=30)as response,temporary.open('xb')as stream:
 record.update(finalURL=response.url,status=response.status,declaredBytes=response.headers.get('Content-Length'),generation=response.headers.get('x-goog-generation'),etag=response.headers.get('ETag'))
 google_hash=response.headers.get('x-goog-hash','')
 for item in google_hash.split(','):
  key,sep,value=item.strip().partition('=')
  if sep and key=='md5':record['publisherMD5Hex']=base64.b64decode(value).hex()
 while block:=response.read(1024*1024):stream.write(block);sha.update(block);md5.update(block);size+=len(block)
 stream.flush();os.fsync(stream.fileno())
if record['finalURL']!=expected or record['status']!=200 or record['declaredBytes']and int(record['declaredBytes'])!=size:raise RuntimeError('Unexpected official object response')
if record.get('publisherMD5Hex')and md5.hexdigest()!=record['publisherMD5Hex']:raise RuntimeError('Google object MD5 mismatch')
os.replace(temporary,archive);record.update(archiveBytes=size,archiveSHA256=sha.hexdigest(),archiveMD5Hex=md5.hexdigest());extract=out/'verified-exact-156';extract.mkdir(exist_ok=False)
with zipfile.ZipFile(archive)as package:
 if package.testzip()is not None:raise RuntimeError('ZIP CRC failure')
 for info in package.infolist():
  target=(extract/info.filename).resolve()
  if not target.is_relative_to(extract.resolve())or stat.S_ISLNK(info.external_attr>>16):raise RuntimeError('Unsafe package member')
 package.extractall(extract)
 for info in package.infolist():
  target=extract/info.filename
  if target.is_file():target.chmod((info.external_attr>>16)&0o777 or 0o644)
binary=extract/'chrome-linux64/chrome';record.update(binary=str(binary),binaryBytes=binary.stat().st_size,binarySHA256=hashlib.sha256(binary.read_bytes()).hexdigest(),reportedVersion=subprocess.check_output([str(binary),'--version'],text=True).strip(),finishedUTC=datetime.now(timezone.utc).isoformat(),seconds=time.monotonic()-start,allZipMembersCRCPassed=True)
(out/'official-exact-recovery.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k]for k in ['version','revision','archiveBytes','archiveSHA256','binaryBytes','binarySHA256','reportedVersion','seconds','allZipMembersCRCPassed']}),flush=True)
