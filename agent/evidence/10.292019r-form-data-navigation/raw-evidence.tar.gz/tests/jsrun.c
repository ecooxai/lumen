/* Headless JS harness: load a page, run its classic scripts and event loop for N ms */
#include <limits.h>
#include <stdlib.h>
#include <unistd.h>
#include "../src/paint/paint.h"
#include "../src/net/net.h"
#include "../src/base/url.h"
#include "../src/js/js.h"
#include "../src/js/jsglue.h"
#include "../src/media/media.h"

static void vp(void *ud, float *w, float *h, float *sx, float *sy, float *dpr) {
    (void)ud; *w = 1280; *h = 800; *sx = *sy = 0; *dpr = 1;
}

static StyleEngine *g_se;
static uint64_t g_seen;
static void jsrun_sync(void *ud, Document *d, bool layout) {
    (void)ud; (void)layout;
    if (!g_se || g_se->doc != d || d->dom_version == g_seen) return;
    g_seen = d->dom_version;
    for (Node *n = d->node.first; n; n = node_next_in_tree(n, &d->node)) {
        if (n->type != NODE_ELEMENT || n->ns != NS_HTML || n->tag != A_style) continue;
        style_engine_remove_owner(g_se, n);
        char *t = node_text_content(n); StyleSheet *s = css_parse_sheet(t, strlen(t), d->url, 1, &g_se->media); s->owner = n; style_engine_add_sheet(g_se, s); free(t);
    }
    style_recalc(g_se, &d->node, true);
}
int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: jsrun URL|FILE [ms]\n"); return 2; }
    double ms = argc > 2 ? atof(argv[2]) : 1000;
    dom_init(); net_init(4); font_init(); js_global_init(argv[0]);
    char url[PATH_MAX + 16];
    char abs[PATH_MAX];
    if (strstr(argv[1], "://")) snprintf(url, sizeof url, "%s", argv[1]);
    else if (realpath(argv[1], abs)) snprintf(url, sizeof url, "file://%s", abs);
    else { fprintf(stderr, "jsrun: cannot resolve %s\n", argv[1]); return 1; }
    NetRequest *rq = net_request_new("GET", url);
    NetResponse *r = net_fetch_sync(rq);
    net_request_free(rq);
    if (!r || r->status == 0) { fprintf(stderr, "jsrun: fetch failed: %s\n", r && r->error ? r->error : "?"); return 1; }
    Document *d = doc_new(r->url ? r->url : url);
    /* Preserve the actual response policy container before the response is
     * released, as the native browser does. Repeated CSP fields intersect. */
    for (size_t i = 0; i < r->headers.n; ++i)
        if (str_ieq(r->headers.v[i].name, "content-security-policy"))
            d->csp = csp_append(d->csp, r->headers.v[i].value);
    const char *permissions = headers_get(&r->headers, "permissions-policy");
    if (permissions) d->permissions_policy = xstrdup(permissions);
    /* Match the browser's response-byte boundary, including transport
     * charset and exactly one BOM. html_parse() accepts Unicode strings. */
    if (!html_parse_bytes(d, r->body ? r->body : "", r->body ? r->body_len : 0,
                          headers_get(&r->headers, "content-type"))) {
        fprintf(stderr, "jsrun: HTML decoding exceeded its byte contract\n");
        net_response_free(r);
        doc_free(d);
        net_shutdown();
        return 1;
    }
    net_response_free(r);
    StyleEngine *se = style_engine_new(d); se->media.vw = 1280; se->media.vh = 800;
    for (Node *n = d->node.first; n; n = node_next_in_tree(n, &d->node)) {
        if (n->type != NODE_ELEMENT || n->ns != NS_HTML) continue;
        const char *rel = node_attr(n, "rel");
        if (n->tag == A_style) {
            char *t = node_text_content(n); StyleSheet *s = css_parse_sheet(t, strlen(t), d->url, 1, &se->media); s->owner = n; style_engine_add_sheet(se, s); free(t);
        } else if (n->tag == A_link && rel && strstr(rel, "stylesheet") && node_attr(n, "href")) {
            char *u = url_join(d->url, node_attr(n, "href"));
            NetRequest *crq = u ? net_request_new("GET", u) : NULL;
            NetResponse *cr = crq ? net_fetch_sync(crq) : NULL;
            net_request_free(crq);
            if (cr && cr->status == 200) { StyleSheet *s = css_parse_sheet(cr->body, cr->body_len, cr->url, 1, &se->media); s->owner = n; style_engine_add_sheet(se, s); }
            if (cr) net_response_free(cr);
            free(u);
        }
    }
    style_recalc(se, &d->node, true);
    uint64_t seen_ver = d->dom_version;
    JsHost h = {0};
    h.viewport = vp;
    g_se = se; g_seen = d->dom_version; h.sync = jsrun_sync;
    double t0 = now_ms();
    JsCtx *js = js_new(d, &h);
    double t1 = now_ms();
    if (getenv("JSRUN_PRE")) js_eval(js, getenv("JSRUN_PRE"), "jsrun:pre");
    int nscripts = 0;
    for (int pass = 0; pass < 2; pass++) for (Node *n = d->node.first; n; n = node_next_in_tree(n, &d->node)) {   /* modules are deferred */
        if (n->type != NODE_ELEMENT || n->tag != A_script || n->ns != NS_HTML || (n->flags & NF_SCRIPT_STARTED)) continue;
        bool mod = jsg_module_script(n);
        if (mod != (pass == 1) || (!mod && !jsg_classic_script(n))) continue;
        nscripts++;
        const char *src = node_attr(n, "src");
        if (mod) {
            char *t = src ? NULL : node_text_content(n), *u = src ? url_join(d->url, src) : NULL;
            js_run_module(js, n, t ? t : (src ? NULL : ""), t ? strlen(t) : 0, u ? u : d->url);
            free(t); free(u);
        } else if (src) {
            char *u = url_join(d->url, src);
            NetRequest *srq = u ? net_request_new("GET", u) : NULL;
            NetResponse *sr = srq ? net_fetch_sync(srq) : NULL;
            net_request_free(srq);
            if (sr && sr->status >= 200 && sr->status < 300) js_run_script(js, n, sr->body ? sr->body : "", sr->body_len, u);
            else { n->flags |= NF_SCRIPT_STARTED; js_dispatch(js, n, "error", "Event", false, false, 0, 0, 0, NULL); }
            if (sr) net_response_free(sr);
            free(u);
        } else {
            char *t = node_text_content(n);
            js_run_script(js, n, t, strlen(t), d->url);
            free(t);
        }
    }
    js_set_ready_state(js, 1);
    js_dispatch(js, &d->node, "DOMContentLoaded", "Event", true, false, 0, 0, 0, NULL);
    js_complete_document(js);
    double t2 = now_ms();
    double end = t2 + ms;
    const char *until = getenv("JSRUN_UNTIL_ATTR");   /* stop early once <html> carries this attribute */
    while (now_ms() < end) {
        if (until && d->html && node_attr(d->html, until)) break;
        net_poll();
        media_tick();
        js_tick(js);
        if (d->dom_version != seen_ver) { seen_ver = d->dom_version; style_recalc(se, &d->node, false); }
        double dl = js_next_deadline(js) - now_ms();
        if (dl > 5) dl = 5;
        if (dl > 5) dl = 5;
        if (dl > 0) usleep((useconds_t)(dl * 1000));
    }
    fprintf(stderr, "jsrun: context %.1fms, %d scripts %.1fms, dom_version %llu\n", t1 - t0, nscripts, t2 - t1, (unsigned long long)d->dom_version);
    if (getenv("JSRUN_DUMP") && d->body) { char *s = node_serialize(d->body, true); puts(s); free(s); }
    if (getenv("JSRUN_POST")) js_eval(js, getenv("JSRUN_POST"), "jsrun:post");
    js_free(js);
    style_engine_free(se);
    doc_free(d);
    return 0;
}
